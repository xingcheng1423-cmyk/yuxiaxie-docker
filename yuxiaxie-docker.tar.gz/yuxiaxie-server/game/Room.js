const config = require('../config');
const logger = require('../utils/logger');

// 游戏状态枚举
const GameState = {
  WAITING: 'WAITING',
  PREPARING: 'PREPARING',
  GRABBING: 'GRABBING',
  BETTING: 'BETTING',
  SHAKING: 'SHAKING',
  OPENING: 'OPENING',
  SETTLING: 'SETTLING'
};

class Room {
  constructor(roomConfig) {
    this.id = roomConfig.id;
    this.name = roomConfig.name;
    this.minBet = roomConfig.min_bet || roomConfig.minBet;
    this.maxBet = roomConfig.max_bet || roomConfig.maxBet;
    this.minEnter = roomConfig.min_enter || roomConfig.minEnter;
    this.maxSeats = roomConfig.seats || 8;
    this.botCount = roomConfig.bot_count || roomConfig.botCount || 3;
    this.commissionRate = parseFloat(roomConfig.commission_rate || roomConfig.commissionRate || 0.05);

    // 座位：index => { userId, userName, userImage, diamond, ready, isBot }
    this.seats = {};
    // 当前游戏状态
    this.state = GameState.WAITING;
    // 当前局号
    this.roundNo = 0;
    // 庄家座位号
    this.bankerSeat = -1;
    // 庄家用户ID
    this.bankerId = null;
    // 系统庄标记
    this.isSystemBanker = false;
    // 抢庄列表 [seatIndex]
    this.grabList = [];
    // 下注记录 [{userId, seatIndex, amount, target}]
    this.bets = [];
    // 骰子结果 [animal1, animal2, animal3]
    this.diceResult = [];
    // 当前倒计时定时器
    this.timer = null;
    // 倒计时剩余秒数
    this.countdown = 0;
    // 所有连接的WebSocket客户端 Map<userId, ws>
    this.clients = new Map();
    // 观战者（未入座） Map<userId, ws>
    this.watchers = new Map();

    logger.info(`房间创建: ${this.name}(ID:${this.id})`, {
      seats: this.maxSeats, minBet: this.minBet, maxBet: this.maxBet
    });
  }

  /**
   * 玩家加入房间（连接）
   */
  addClient(userId, ws) {
    this.clients.set(userId, ws);
  }

  /**
   * 玩家离开房间（断开连接）
   * @param {number} userId
   * @param {WebSocket} ws - 断开的ws实例，防止重连竞态
   */
  removeClient(userId, ws) {
    // 如果传了ws，检查是否是当前连接（防止重连时旧连接把新连接踢掉）
    if (ws) {
      const currentWs = this.clients.get(userId);
      if (currentWs && currentWs !== ws) {
        // 新连接已经替换了旧连接，不要删除
        return;
      }
    }
    this.clients.delete(userId);
    this.watchers.delete(userId);
    // 如果在座位上，处理离座
    const seatIdx = this.findSeatByUser(userId);
    if (seatIdx !== null) {
      this.leaveSeat(seatIdx);
    }
  }

  /**
   * 入座
   */
  sitDown(seatIndex, userData) {
    if (this.seats[seatIndex]) {
      return { ok: false, msg: '座位已被占用' };
    }
    if (seatIndex < 0 || seatIndex >= this.maxSeats) {
      return { ok: false, msg: '座位编号无效' };
    }
    // 检查是否已在其他座位
    const existingSeat = this.findSeatByUser(userData.userId);
    if (existingSeat !== null) {
      return { ok: false, msg: '你已在座位上' };
    }
    // 检查入场金币
    if (userData.diamond < this.minEnter) {
      return { ok: false, msg: `入场最低需要${this.minEnter}金币` };
    }

    this.seats[seatIndex] = {
      userId: userData.userId,
      userName: userData.userName,
      userImage: userData.userImage || '',
      diamond: userData.diamond,
      ready: false,
      isBot: userData.isBot || false
    };

    return { ok: true };
  }

  /**
   * 离座
   */
  leaveSeat(seatIndex) {
    if (!this.seats[seatIndex]) return;

    const seat = this.seats[seatIndex];

    // 游戏中不能立即离座，标记为离线，等本局结束再踢
    if (this.state !== GameState.WAITING && this.state !== GameState.PREPARING) {
      seat.offline = true;
      return;
    }

    // 如果是庄家，清除庄家
    if (this.bankerSeat === seatIndex) {
      this.bankerSeat = -1;
      this.bankerId = null;
    }

    delete this.seats[seatIndex];
  }

  /**
   * 查找用户所在座位
   */
  findSeatByUser(userId) {
    for (const [idx, seat] of Object.entries(this.seats)) {
      if (seat.userId === userId) return parseInt(idx);
    }
    return null;
  }

  /**
   * 玩家准备
   */
  setReady(userId) {
    const seatIdx = this.findSeatByUser(userId);
    if (seatIdx === null) return { ok: false, msg: '你不在座位上' };
    if (this.state !== GameState.WAITING && this.state !== GameState.PREPARING) {
      return { ok: false, msg: '当前阶段无法准备' };
    }

    this.seats[seatIdx].ready = true;
    return { ok: true, seatIndex: seatIdx };
  }

  /**
   * 获取已准备的玩家数
   */
  getReadyCount() {
    return Object.values(this.seats).filter(s => s.ready).length;
  }

  /**
   * 获取已入座的玩家数
   */
  getSeatedCount() {
    return Object.keys(this.seats).length;
  }

  /**
   * 获取非庄家的已准备座位列表
   */
  getNonBankerReadySeats() {
    return Object.entries(this.seats)
      .filter(([idx, seat]) => seat.ready && parseInt(idx) !== this.bankerSeat)
      .map(([idx, seat]) => ({ seatIndex: parseInt(idx), ...seat }));
  }

  /**
   * 抢庄
   */
  grabBanker(userId, isGrab) {
    const seatIdx = this.findSeatByUser(userId);
    if (seatIdx === null) return { ok: false, msg: '你不在座位上' };
    if (this.state !== GameState.GRABBING) return { ok: false, msg: '当前不是抢庄阶段' };

    if (isGrab) {
      this.grabList.push(seatIdx);
    }
    return { ok: true };
  }

  /**
   * 确定庄家
   */
  decideBanker() {
    if (this.grabList.length > 0) {
      // 随机选一个抢庄的人
      const randIdx = Math.floor(Math.random() * this.grabList.length);
      this.bankerSeat = this.grabList[randIdx];
      this.bankerId = this.seats[this.bankerSeat].userId;
      this.isSystemBanker = false;
    } else {
      // 无人抢庄，系统当庄
      this.bankerSeat = -1;
      this.bankerId = null;
      this.isSystemBanker = true;
    }
    this.grabList = [];
    return {
      bankerSeat: this.bankerSeat,
      bankerId: this.bankerId,
      isSystem: this.isSystemBanker
    };
  }

  /**
   * 下注
   */
  placeBet(userId, amount, target) {
    const seatIdx = this.findSeatByUser(userId);
    if (seatIdx === null) return { ok: false, msg: '你不在座位上' };
    if (this.state !== GameState.BETTING) return { ok: false, msg: '当前不是下注阶段' };
    if (seatIdx === this.bankerSeat) return { ok: false, msg: '庄家不能下注' };
    if (amount < this.minBet) return { ok: false, msg: `最低下注${this.minBet}` };
    if (amount > this.maxBet) return { ok: false, msg: `最高下注${this.maxBet}` };

    // 检查余额
    const seat = this.seats[seatIdx];
    const totalBet = this.getUserTotalBet(userId) + amount;
    if (totalBet > seat.diamond) {
      return { ok: false, msg: '余额不足' };
    }

    this.bets.push({
      userId,
      seatIndex: seatIdx,
      amount,
      target, // 单选: 数字编号, 组合: "1,0,3" 这样的字符串
      userName: seat.userName
    });

    return { ok: true, seatIndex: seatIdx };
  }

  /**
   * 获取玩家在本局的总下注
   */
  getUserTotalBet(userId) {
    return this.bets
      .filter(b => b.userId === userId)
      .reduce((sum, b) => sum + b.amount, 0);
  }

  /**
   * 重置局数据（新一局开始前）
   */
  resetRound() {
    this.bets = [];
    this.diceResult = [];
    this.grabList = [];
    this.bankerSeat = -1;
    this.bankerId = null;
    this.isSystemBanker = false;

    // 重置所有座位的准备状态
    for (const seat of Object.values(this.seats)) {
      seat.ready = false;
    }
  }

  /**
   * 广播消息给房间内所有连接的玩家
   */
  broadcast(message) {
    const data = typeof message === 'string' ? message : JSON.stringify(message);
    for (const [userId, ws] of this.clients) {
      try {
        if (ws.readyState === 1) { // WebSocket.OPEN
          ws.send(data);
        }
      } catch (e) {
        logger.error('广播消息失败', { userId, error: e.message });
      }
    }
  }

  /**
   * 发送消息给指定玩家
   */
  sendToUser(userId, message) {
    const ws = this.clients.get(userId);
    if (ws && ws.readyState === 1) {
      const data = typeof message === 'string' ? message : JSON.stringify(message);
      ws.send(data);
    }
  }

  /**
   * 获取房间快照（给新连接的玩家同步状态）
   */
  getSnapshot() {
    return {
      id: this.id,
      name: this.name,
      state: this.state,
      roundNo: this.roundNo,
      seats: this.seats,
      bankerSeat: this.bankerSeat,
      bankerId: this.bankerId,
      isSystemBanker: this.isSystemBanker,
      bets: this.bets,
      countdown: this.countdown,
      minBet: this.minBet,
      maxBet: this.maxBet,
      onlineCount: this.clients.size
    };
  }

  /**
   * 清除定时器
   */
  clearTimer() {
    if (this.timer) {
      clearInterval(this.timer);
      this.timer = null;
    }
  }
}

module.exports = { Room, GameState };
