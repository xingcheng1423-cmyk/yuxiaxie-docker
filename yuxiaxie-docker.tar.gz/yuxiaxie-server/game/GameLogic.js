const config = require('../config');
const logger = require('../utils/logger');
const { randomInt } = require('../utils/helpers');
const User = require('../models/User');
const Transaction = require('../models/Transaction');
const GameRecord = require('../models/GameRecord');
const redis = require('../db/redis');
const db = require('../db/mysql');

/**
 * 鱼虾蟹游戏逻辑 - 新前端协议 (type字段)
 * 3个骰子，每个骰子0-5对应: 葫芦(0)/虎(1)/鸡(2)/蟹(3)/鱼(4)/虾(5)
 *
 * 游戏流程:
 *   waiting → prepare(10s) → grab(10s) → shaking(5s) → betting(15s) → revealing(3s) → settling(3s) → waiting
 *
 * 下注模式:
 *   single  - 选1个动物，命中1/2/3颗分别赔1/2/3倍
 *   double  - 选2个动物，3颗中都出现才赢 (赔率待定，默认5倍)
 *   triple2 - 选3个动物，出现2个即赢 (赔率待定，默认3倍)
 *   triple3 - 选3个动物，全中才赢 (赔率待定，默认15倍)
 */
class GameLogic {
  constructor(room, botManager = null) {
    this.room = room;
    this.botManager = botManager;
    this.isRunning = false;
    this.phase = 'waiting';
    this.timer = null;
    this.countdownTimer = null;
    this.countdown = 0;

    // 时间配置 (秒)
    this.prepareTime = config.game.prepareTime || 10;
    this.grabTime = config.game.grabTime || 10;
    this.betTime = config.game.betTime || 15;
    this.shakeTime = 2;
    this.revealTime = 3;
    this.settleTime = 3;
    this.grabMinBalance = config.game.grabMinBalance || 30000;
    this.bankMinBalance = config.game.bankMinBalance || 5000;   // 没人抢庄时自动当庄的最低余额
    this.botMinBet = config.game.botMinBet || 10;
    this.botMaxBet = config.game.botMaxBet || 1000;
    this.roundFee = config.game.roundFee || 0;
    this.playerMaxBet = config.game.playerMaxBet || 0; // 0=不限制
    this.autoLoopNoBet = config.game.autoLoopNoBet !== false; // 默认true
    this.botCanGrab = config.game.botCanGrab === true;        // 机器人能否当庄（后台开关）

    this.chips = [10, 50, 100, 500, 1000];
    this.ANIMALS = ['葫芦', '虎', '鸡', '蟹', '鱼', '虾'];

    // 赔率配置
    this.odds = {
      single: [0, 1, 2, 3],   // 未中/中1/中2/中3
      double: 5,               // 二中二赔率
      triple2: 3,              // 三中二赔率
      triple3: 15              // 三中三赔率
    };

    // 本局数据
    this.roundBets = new Map();  // Map<userId, [{animals:[], amount, mode}]>
    this.diceResult = null;
    this.roundNo = 0;
    this.grabList = [];          // 抢庄列表 [userId]
    this.bankerUserId = null;
    this.bankerSeat = -1;
    this.isSystemBanker = true;
    this.isSkipping = false;     // 本局作废（无真人可当庄）标记
    this.history = [];           // [{round, dice:[]}]

    // 杀率
    this.killRate = config.game.killRate || 0.6;
    this.maxLossPerRound = config.game.maxLossPerRound || 50000;
  }

  // ===== 游戏循环 =====

  startLoop() {
    if (this.isRunning) return;
    this.isRunning = true;
    logger.info(`房间${this.room.id} 游戏循环启动`);
    this.startPreparePhase();
  }

  stopLoop() {
    this.isRunning = false;
    this.clearTimers();
    logger.info(`房间${this.room.id} 游戏循环停止`);
  }

  // ----- 阶段1: 入座即开始（跳过准备） -----
  startPreparePhase() {
    if (this.isSkipping) return;

    // 机器人不当庄时，桌上没有真人开局也打不起来 → 暂停等待；
    // 开关打开（机器人可当庄）时，沿用原来的「无人入座自动循环」设置
    const hasRealPlayer = Object.values(this.room.seats).some(s => s && !s.isBot);
    const mustPause = this.botCanGrab ? (!this.autoLoopNoBet && !hasRealPlayer) : !hasRealPlayer;
    if (mustPause) {
      logger.info(`房间${this.room.id} 无真人入座，暂停游戏（${this.botCanGrab ? '自动循环已关闭' : '机器人不当庄'}）`);
      this.broadcastPhase('waiting', 0);
      this.phase = 'waiting';
      this.clearTimers();
      this.timer = setTimeout(() => {
        if (this.isRunning) this.startPreparePhase();
      }, 5000);
      return;
    }

    // 检查入座人数是否足够
    const seatedCount = this.room.getSeatedCount();
    if (seatedCount < 2) {
      logger.info(`房间${this.room.id} 入座人数不足(${seatedCount})，等待中`);
      this.broadcastPhase('waiting', 0);
      this.phase = 'waiting';
      this.clearTimers();
      this.timer = setTimeout(() => {
        if (this.isRunning) this.startPreparePhase();
      }, 5000);
      return;
    }

    this.roundNo++;
    this.roundBets.clear();
    this.diceResult = null;
    this.grabList = [];

    logger.info(`房间${this.room.id} 第${this.roundNo}局 入座即开始，直接抢庄`);

    // 跳过准备阶段，直接进入抢庄
    this.startGrabPhase();
  }

  // ----- 阶段2: 抢庄 -----
  startGrabPhase() {
    this.phase = 'grab';
    this.grabList = [];

    logger.info(`房间${this.room.id} 抢庄阶段${this.botCanGrab ? '（机器人可抢庄）' : '（仅真人可抢庄，机器人/系统不当庄）'}`);
    this.broadcastPhase('grab', this.grabTime);

    // 机器人抢庄：受后台「机器人能否抢庄」开关控制
    if (this.botCanGrab && this.botManager) {
      this.botManager.autoGrab(this);
    }

    this.startCountdown(this.grabTime, () => {
      // decideBanker 返回 false 表示本局没有真人可当庄，已作废，必须中断本局流程
      if (!this.decideBanker()) return;
      // 抢庄动画延迟: 多人抢庄时等待前端动画
      const animDelay = this.grabList.length > 1 ? 4500 : 500;
      this.timer = setTimeout(() => this.startShakingPhase(), animDelay);
    });
  }

  decideBanker() {
    // 机器人能否当庄由后台开关决定；关闭时抢庄名单只保留真人
    const realGrabbers = this.grabList.filter(uid => this.botCanGrab || !this.isBotUser(uid));
    const grabbers = realGrabbers.map(uid => {
      const s = this.room.findSeatByUser(uid);
      return { userId: uid, seat: s, name: (s >= 0 && this.room.seats[s]) ? this.room.seats[s].userName : '???' };
    });

    if (realGrabbers.length > 0) {
      const idx = randomInt(0, realGrabbers.length - 1);
      this.bankerUserId = realGrabbers[idx];
      this.bankerSeat = this.room.findSeatByUser(this.bankerUserId);
      this.isSystemBanker = false;
      const seat = this.bankerSeat >= 0 ? this.room.seats[this.bankerSeat] : null;
      this.broadcast({
        type: 'grab_result',
        bankerSeat: this.bankerSeat,
        bankerName: seat ? seat.userName : '???',
        isSystem: false,
        grabbers
      });
    } else {
      // 没人抢庄：默认金币最多的真人当庄（机器人不参与；余额要达到坐庄门槛，钱不够顺位给下一个真人）
      let richestSeat = -1;
      let richestUserId = null;
      let richestName = '';
      let maxDiamond = 0;

      for (const [seatIdx, seatData] of Object.entries(this.room.seats)) {
        if (!seatData) continue;
        if (seatData.isBot && !this.botCanGrab) continue;   // 机器人不当庄（开关关闭时）
        const diamond = seatData.diamond || 0;
        if (diamond >= this.bankMinBalance && diamond > maxDiamond) {
          maxDiamond = diamond;
          richestSeat = parseInt(seatIdx);
          richestUserId = seatData.userId;
          richestName = seatData.userName || '???';
        }
      }

      if (richestUserId) {
        this.bankerUserId = richestUserId;
        this.bankerSeat = richestSeat;
        this.isSystemBanker = false;
        logger.info(`房间${this.room.id} 无人抢庄，自动指定金币最多的真人 ${richestName}(${richestUserId}, 余额${maxDiamond}) 为庄家`);
        this.broadcast({
          type: 'grab_result',
          bankerSeat: this.bankerSeat,
          bankerName: richestName,
          isSystem: false,
          grabbers: []
        });
      } else {
        // 没有真人能当庄：本局作废，绝不坐系统庄
        this.skipRound('无真人可当庄');
        return false;
      }
    }
    return true;
  }

  /**
   * 本局作废：没有真人能当庄时，不发牌、不结算、不派奖，直接回到等待
   */
  skipRound(reason) {
    if (this.isSkipping) return;
    this.isSkipping = true;

    logger.info(`房间${this.room.id} 第${this.roundNo}局 跳过（${reason}），等待真人玩家`);

    this.clearTimers();
    this.phase = 'waiting';
    this.bankerUserId = null;
    this.bankerSeat = -1;
    this.isSystemBanker = true;   // 仅表示"当前没有庄家"，不会再以系统身份坐庄
    this.grabList = [];
    this.roundBets.clear();
    this.diceResult = null;

    this.broadcastPhase('waiting', 0);
    this.broadcast({ type: 'round_skipped', msg: '本局没有可当庄的玩家，等待下局' });

    this.timer = setTimeout(() => {
      this.isSkipping = false;
      if (this.isRunning) this.startPreparePhase();
    }, 5000);
  }

  /**
   * 判断某个 userId 是否是机器人（机器人=系统，不能当庄）
   */
  isBotUser(userId) {
    if (!userId) return false;
    const seat = this.room.findSeatByUser(userId);
    if (seat < 0) return false;
    const seatData = this.room.seats[seat];
    return !!(seatData && seatData.isBot);
  }

  // ----- 阶段3: 摇骰 (仅动画，骰子结果在开奖时生成) -----
  startShakingPhase() {
    this.phase = 'shaking';

    logger.info(`房间${this.room.id} 摇骰阶段(动画)`);

    this.broadcastPhase('shaking', this.shakeTime);
    this.broadcast({ type: 'dice_shake' });

    this.clearTimers();
    this.timer = setTimeout(() => this.startBettingPhase(), this.shakeTime * 1000);
  }

  // ----- 阶段4: 下注 (摇骰后) -----
  startBettingPhase() {
    this.phase = 'betting';
    this.roundBets.clear();

    logger.info(`房间${this.room.id} 下注阶段 ${this.betTime}秒`);
    this.broadcastPhase('betting', this.betTime);

    // 机器人下注
    if (this.botManager) {
      this.botManager.autoBet(this, this.betTime);
    }

    this.startCountdown(this.betTime, () => {
      this.startRevealPhase().catch(e => {
        logger.error('开奖阶段错误', e);
        this.safeRestart();
      });
    });
  }

  // ----- 阶段5: 开奖 (生成骰子结果并揭晓) -----
  async startRevealPhase() {
    this.phase = 'revealing';
    this.diceResult = await this.generateDiceResult();

    logger.info(`房间${this.room.id} 骰子: [${this.diceResult.join(',')}] = ${this.diceResult.map(d => this.ANIMALS[d]).join(',')}`);

    this.broadcastPhase('revealing', this.revealTime, { dice: this.diceResult });
    this.broadcast({ type: 'dice_result', dice: this.diceResult });

    // 添加到历史
    this.history.unshift({ round: this.roundNo, dice: this.diceResult });
    if (this.history.length > 50) this.history.pop();

    this.clearTimers();
    this.timer = setTimeout(() => {
      this.startSettlePhase().catch(e => {
        logger.error('结算错误', e);
        this.safeRestart();
      });
    }, this.revealTime * 1000);
  }

  // ----- 阶段6: 结算 -----
  async startSettlePhase() {
    this.phase = 'settling';
    this.broadcastPhase('settling', this.settleTime);

    const animalCounts = [0, 0, 0, 0, 0, 0];
    for (const d of this.diceResult) animalCounts[d]++;

    let platformProfit = 0;
    const results = [];

    for (const [userId, bets] of this.roundBets) {
      // 通过座位的isBot字段判断是否机器人，而不是ID范围
      const seat = this.room.findSeatByUser(userId);
      const seatData = seat !== null ? this.room.seats[seat] : null;
      const isBot = seatData ? seatData.isBot : false;
      let netWin = 0;

      for (const bet of bets) {
        netWin += this.calcBetWin(bet, animalCounts);
      }

      // 机器人：更新显示余额，不走真人结算流程
      if (isBot) {
        if (seat !== null && seatData) {
          seatData.diamond = (seatData.diamond || 0) + netWin;
          const newBalance = seatData.diamond;
          results.push({
            userId, seat, win: netWin, newBalance,
            name: seatData.userName || '???'
          });
          // 同步到 BotManager 内存和数据库
          if (this.botManager) {
            const cfg = this.botManager.botConfigs.get(userId);
            if (cfg) {
              cfg.balance = newBalance;
              db.query('UPDATE bots SET balance = ? WHERE id = ?', [newBalance, cfg.dbId]).catch(() => {});
            }
          }
        }
        continue;
      }

      let commission = 0;
      platformProfit -= netWin; // 玩家赢=平台亏, 玩家输=平台赚

      try {
        const newBalance = await User.updateBalance(userId, netWin);
        if (seat !== null && seatData) {
          seatData.diamond = newBalance;
        }

        results.push({
          userId, seat, win: netWin, newBalance,
          name: seatData?.userName || '???'
        });

        if (netWin > 0) {
          await Transaction.add(userId, 3, netWin, null, '鱼虾蟹赢').catch(() => {});
        } else if (netWin < 0) {
          await Transaction.add(userId, 4, netWin, null, '鱼虾蟹输').catch(() => {});
        }
        this.processAgentCommission(userId, Math.abs(netWin)).catch(() => {});
      } catch (e) {
        logger.error('结算失败', { userId, error: e.message });
      }
    }

    // 每局固定扣费（所有入座玩家，含机器人）
    if (this.roundFee > 0) {
      for (const [idx, seat] of Object.entries(this.room.seats)) {
        const uid = seat.userId;
        if (seat.isBot) {
          // 机器人：只扣内存余额
          seat.diamond = (seat.diamond || 0) - this.roundFee;
          platformProfit += this.roundFee;
          const existing = results.find(r => r.userId === uid);
          if (existing) {
            existing.newBalance = seat.diamond;
          } else {
            results.push({
              userId: uid, seat: parseInt(idx), win: 0, newBalance: seat.diamond,
              name: seat.userName || '???'
            });
          }
        } else {
          // 真人玩家：扣数据库
          try {
            const newBal = await User.updateBalance(uid, -this.roundFee);
            seat.diamond = newBal;
            platformProfit += this.roundFee;
            const existing = results.find(r => r.userId === uid);
            if (existing) {
              existing.newBalance = newBal;
            } else {
              results.push({
                userId: uid, seat: parseInt(idx), win: 0, newBalance: newBal,
                name: seat.userName || '???'
              });
            }
            await Transaction.add(uid, 6, -this.roundFee, null, '每局扣费').catch(() => {});
          } catch (e) {
            logger.error('每局扣费失败', { userId: uid, error: e.message });
          }
        }
      }
    }

    this.broadcast({ type: 'settle', results });

    // ===== 庄家结算：闲家赢的钱从庄家扣，闲家输的钱庄家赚 =====
    if (!this.isSystemBanker && this.bankerSeat >= 0 && this.bankerUserId) {
      const bankerSeatData = this.room.seats[this.bankerSeat];
      if (bankerSeatData) {
        // 庄家盈亏 = 所有闲家输赢的相反数（闲家赢了庄家就亏）
        let bankerNetWin = 0;
        for (const r of results) {
          if (r.userId !== this.bankerUserId) {
            bankerNetWin -= r.win || 0;
          }
        }

        if (bankerSeatData.isBot) {
          // 机器人庄家：只更新内存
          bankerSeatData.diamond = (bankerSeatData.diamond || 0) + bankerNetWin;
          if (this.botManager) {
            const cfg = this.botManager.botConfigs.get(this.bankerUserId);
            if (cfg) {
              cfg.balance = bankerSeatData.diamond;
              db.query('UPDATE bots SET balance = ? WHERE id = ?', [bankerSeatData.diamond, cfg.dbId]).catch(() => {});
            }
          }
        } else {
          // 真人庄家：更新数据库
          try {
            const newBal = await User.updateBalance(this.bankerUserId, bankerNetWin);
            bankerSeatData.diamond = newBal;
            if (bankerNetWin > 0) {
              await Transaction.add(this.bankerUserId, 3, bankerNetWin, null, '鱼虾蟹坐庄赢').catch(() => {});
            } else if (bankerNetWin < 0) {
              await Transaction.add(this.bankerUserId, 4, bankerNetWin, null, '鱼虾蟹坐庄输').catch(() => {});
            }
          } catch (e) {
            logger.error('庄家结算失败', { userId: this.bankerUserId, error: e.message });
          }
        }

        // 把庄家结果也广播给前端（用于显示庄家余额变化）
        this.broadcast({
          type: 'banker_settle',
          bankerSeat: this.bankerSeat,
          bankerWin: bankerNetWin,
          bankerBalance: bankerSeatData.diamond
        });

        logger.info(`庄家结算: ${bankerSeatData.userName} ${bankerNetWin >= 0 ? '赢' : '输'} ${Math.abs(bankerNetWin)}, 余额: ${bankerSeatData.diamond}`);
      }
    }

    // 余额不足的机器人：重置余额并保持在座
    if (this.botManager) {
      for (const [idx, seat] of Object.entries(this.room.seats)) {
        if (!seat.isBot) continue;
        if ((seat.diamond || 0) <= 0) {
          const botId = seat.userId;
          const cfg = this.botManager.botConfigs.get(botId);
          const resetBalance = 10000;
          seat.diamond = resetBalance;
          if (cfg) {
            cfg.balance = resetBalance;
            db.query('UPDATE bots SET balance = ? WHERE id = ?', [resetBalance, cfg.dbId]).catch(() => {});
          }
          logger.info(`机器人 ${seat.userName}(${botId}) 余额不足，重置为${resetBalance}`);
        }
      }
    }

    // 保存记录
    try {
      await GameRecord.add({
        roomId: this.room.id, roundNo: this.roundNo,
        diceResult: this.diceResult, bankerId: this.bankerUserId || 0,
        betsDetail: Array.from(this.roundBets.entries()).map(([uid, bets]) => ({ uid, bets })),
        settleDetail: { dice: this.diceResult, animalCounts }, platformProfit
      });
    } catch (e) {
      logger.error('保存记录失败', e);
    }

    // 下一局
    this.clearTimers();
    this.timer = setTimeout(() => {
      if (this.isRunning) {
        // 清理离线玩家（本局结束后踢出座位）
        this.cleanOfflinePlayers();

        this.broadcastPhase('waiting', 0);
        this.phase = 'waiting';
        this.startPreparePhase();
      }
    }, this.settleTime * 1000);
  }

  // ===== 下注计算 =====
  calcBetWin(bet, animalCounts) {
    const { animals, amount, mode } = bet;

    if (mode === 'single') {
      // 单选: 选1个动物
      const matches = animalCounts[animals[0]] || 0;
      return matches > 0 ? amount * matches : -amount;
    }

    if (mode === 'double') {
      // 二中二: 选2个动物，都出现才赢
      const allMatch = animals.every(a => animalCounts[a] > 0);
      return allMatch ? amount * this.odds.double : -amount;
    }

    if (mode === 'triple2') {
      // 三中二: 选3个动物，出现2个以上即赢
      const matchCount = animals.filter(a => animalCounts[a] > 0).length;
      return matchCount >= 2 ? amount * this.odds.triple2 : -amount;
    }

    if (mode === 'triple3') {
      // 三中三: 选3个动物，全中
      const allMatch = animals.every(a => animalCounts[a] > 0);
      return allMatch ? amount * this.odds.triple3 : -amount;
    }

    return -amount; // 未知模式
  }

  // ===== 玩家操作处理 =====

  handleReady(ws) {
    if (this.phase !== 'prepare') {
      return this.sendTo(ws, { type: 'error', msg: '当前不是准备阶段' });
    }
    const seat = this.room.findSeatByUser(ws.userId);
    if (seat === null) {
      return this.sendTo(ws, { type: 'error', msg: '请先入座' });
    }
    this.room.seats[seat].ready = true;
    this.broadcast({ type: 'ready_ok', seat, userId: ws.userId });
  }

  handleGrab(ws, isGrab) {
    if (this.phase !== 'grab') {
      return this.sendTo(ws, { type: 'error', msg: '当前不是抢庄阶段' });
    }
    if (isGrab) {
      // 检查余额是否满足抢庄门槛
      const seat = this.room.findSeatByUser(ws.userId);
      const seatData = seat >= 0 ? this.room.seats[seat] : null;
      if (seatData && (seatData.diamond || 0) < this.grabMinBalance) {
        return this.sendTo(ws, {
          type: 'error',
          msg: `抢庄需 ${this.grabMinBalance} 金币，当前 ${Math.floor(seatData.diamond || 0)}`
        });
      }
      if (!this.grabList.includes(ws.userId)) {
        this.grabList.push(ws.userId);
        this.broadcast({ type: 'grab_ok', userId: ws.userId, seat, name: seatData ? seatData.userName : '???' });
      }
    }
  }

  async handleBet(ws, animals, amount, mode) {
    if (this.phase !== 'betting') {
      return this.sendTo(ws, { type: 'bet_fail', msg: '当前不是下注阶段' });
    }

    const seat = this.room.findSeatByUser(ws.userId);
    if (seat === null) {
      return this.sendTo(ws, { type: 'bet_fail', msg: '请先入座' });
    }
    if (seat === this.bankerSeat) {
      return this.sendTo(ws, { type: 'bet_fail', msg: '庄家不能下注' });
    }

    // 验证参数
    if (!Array.isArray(animals) || animals.length === 0) {
      return this.sendTo(ws, { type: 'bet_fail', msg: '请选择动物' });
    }
    if (!animals.every(a => a >= 0 && a <= 5)) {
      return this.sendTo(ws, { type: 'bet_fail', msg: '无效动物' });
    }
    if (!this.chips.includes(amount)) {
      return this.sendTo(ws, { type: 'bet_fail', msg: '无效筹码' });
    }

    const validModes = ['single', 'double', 'triple2', 'triple3'];
    if (!validModes.includes(mode)) {
      return this.sendTo(ws, { type: 'bet_fail', msg: '无效模式' });
    }

    const requiredCount = { single: 1, double: 2, triple2: 3, triple3: 3 };
    if (animals.length !== requiredCount[mode]) {
      return this.sendTo(ws, { type: 'bet_fail', msg: `${mode}模式需要选${requiredCount[mode]}个动物` });
    }

    // 检查余额
    const currentUser = await User.findById(ws.userId);
    if (!currentUser) return;

    // 余额为 0 或负数的不能下注
    if (!(currentUser.huobi > 0)) {
      return this.sendTo(ws, { type: 'bet_fail', msg: `余额 ${Math.floor(currentUser.huobi || 0)}，请先上分` });
    }

    const totalBet = this.getUserTotalBet(ws.userId) + amount;
    if (totalBet > currentUser.huobi) {
      return this.sendTo(ws, {
        type: 'bet_fail',
        msg: `余额不足：本局已押 ${this.getUserTotalBet(ws.userId)}，余额 ${Math.floor(currentUser.huobi)}`
      });
    }

    // 单场最大下注限制
    if (this.playerMaxBet > 0 && totalBet > this.playerMaxBet) {
      return this.sendTo(ws, { type: 'bet_fail', msg: '超过单场最大下注' + this.playerMaxBet });
    }

    // 不能超过庄家余额（检查全桌总下注，不仅是个人）
    if (!this.isSystemBanker && this.bankerSeat >= 0) {
      const bankerSeatData = this.room.seats[this.bankerSeat];
      if (bankerSeatData) {
        const bankerBal = bankerSeatData.diamond || 0;
        const allBetsTotal = this.getAllTotalBet() + amount;
        if (allBetsTotal > bankerBal) {
          return this.sendTo(ws, { type: 'bet_fail', msg: '全桌下注已超过庄家余额' + bankerBal });
        }
      }
    }

    // 记录下注
    if (!this.roundBets.has(ws.userId)) {
      this.roundBets.set(ws.userId, []);
    }
    this.roundBets.get(ws.userId).push({ animals, amount, mode });

    const newBalance = currentUser.huobi - totalBet;

    // 广播下注
    this.broadcast({
      type: 'bet_ok',
      userId: ws.userId,
      seat,
      animals,
      amount,
      mode,
      newBalance
    });

    logger.info(`${currentUser.name} 下注 ${amount} on ${animals.map(a => this.ANIMALS[a]).join('+')} (${mode})`);
  }

  // 机器人下注
  botBet(botId, animals, amount, mode = 'single') {
    if (this.phase !== 'betting') return;

    const seat = this.room.findSeatByUser(botId);
    const seatData = seat !== null ? this.room.seats[seat] : null;

    const totalBet = this.getUserTotalBet(botId) + amount;

    // 单场最大下注限制
    if (this.playerMaxBet > 0 && totalBet > this.playerMaxBet) return;

    // 不能超过庄家余额
    if (!this.isSystemBanker && this.bankerSeat >= 0) {
      const bankerSeatData = this.room.seats[this.bankerSeat];
      if (bankerSeatData && this.getAllTotalBet() + amount > (bankerSeatData.diamond || 0)) return;
    }

    if (!this.roundBets.has(botId)) {
      this.roundBets.set(botId, []);
    }
    this.roundBets.get(botId).push({ animals, amount, mode });

    // 扣减显示余额（和真人一样，让前端看到余额变化）
    const displayBalance = seatData ? Math.max((seatData.diamond || 0) - totalBet, 0) : 10000;

    this.broadcast({
      type: 'bet_ok',
      userId: botId,
      seat: seat !== null ? seat : -1,
      animals,
      amount,
      mode,
      newBalance: displayBalance
    });
  }

  // 机器人准备
  botReady(botId) {
    const seat = this.room.findSeatByUser(botId);
    if (seat !== null && this.room.seats[seat]) {
      this.room.seats[seat].ready = true;
      this.broadcast({ type: 'ready_ok', seat, userId: botId });
    }
  }

  // 机器人抢庄
  botGrab(botId, isGrab) {
    // 开关关闭时机器人不能当庄：直接忽略机器人的抢庄请求
    if (!this.botCanGrab && this.isBotUser(botId)) return;
    if (isGrab && !this.grabList.includes(botId)) {
      const seat = this.room.findSeatByUser(botId);
      const seatData = seat >= 0 ? this.room.seats[seat] : null;
      if (seatData && (seatData.diamond || 0) < this.grabMinBalance) return;
      this.grabList.push(botId);
      this.broadcast({ type: 'grab_ok', userId: botId, seat, name: seatData ? seatData.userName : '???' });
    }
  }

  getUserTotalBet(userId) {
    if (!this.roundBets.has(userId)) return 0;
    return this.roundBets.get(userId).reduce((sum, b) => sum + b.amount, 0);
  }

  getAllTotalBet() {
    let total = 0;
    for (const [userId, bets] of this.roundBets) {
      for (const b of bets) total += b.amount;
    }
    return total;
  }

  // ===== 房间数据 =====

  sendRoomInfo(ws) {
    const seats = [];
    for (const [idx, seat] of Object.entries(this.room.seats)) {
      seats.push({
        seat: parseInt(idx),
        userId: seat.userId,
        name: seat.userName,
        avatar: seat.userImage || '',
        balance: seat.diamond || 0,
        ready: seat.ready || false,
        isBot: seat.isBot || false
      });
    }

    // 当前下注汇总
    const bets = {};
    for (const [userId, betList] of this.roundBets) {
      for (const bet of betList) {
        for (const a of bet.animals) {
          bets[a] = (bets[a] || 0) + bet.amount;
        }
      }
    }

    this.sendTo(ws, {
      type: 'room',
      seats,
      maxSeats: this.room.maxSeats,
      phase: this.phase,
      countdown: this.countdown,
      round: this.roundNo,
      banker: this.bankerSeat,
      bankerName: this.isSystemBanker ? '系统' : (this.room.seats[this.bankerSeat]?.userName || '系统'),
      isSystemBanker: this.isSystemBanker,
      history: this.history.slice(0, 20),
      bets,
      diceResult: this.diceResult,
      watcherCount: this.room.watchers.size
    });
  }

  // ===== 骰子生成 (带杀率) =====

  async generateDiceResult() {
    if (this.roundBets.size === 0) {
      return [randomInt(0, 5), randomInt(0, 5), randomInt(0, 5)];
    }

    const allResults = [];
    for (let d1 = 0; d1 < 6; d1++)
      for (let d2 = 0; d2 < 6; d2++)
        for (let d3 = 0; d3 < 6; d3++)
          allResults.push([d1, d2, d3]);

    const scored = allResults.map(dice => {
      const counts = [0, 0, 0, 0, 0, 0];
      for (const d of dice) counts[d]++;

      let profit = 0;
      for (const [userId, bets] of this.roundBets) {
        for (const bet of bets) {
          profit -= this.calcBetWin(bet, counts);
        }
      }
      return { dice, profit };
    });

    let candidates = scored;

    // 点杀/放水
    try {
      const killList = await redis.getKillList();
      const winList = await redis.getWinList();

      if (killList && killList.length > 0) {
        const filtered = candidates.filter(c => {
          const counts = [0, 0, 0, 0, 0, 0];
          for (const d of c.dice) counts[d]++;
          return killList.every(uid => {
            const bets = this.roundBets.get(parseInt(uid)) || [];
            return bets.every(b => this.calcBetWin(b, counts) <= 0);
          });
        });
        if (filtered.length > 0) candidates = filtered;
        await redis.clearKillList();
      }

      if (winList && winList.length > 0) {
        const filtered = candidates.filter(c => {
          const counts = [0, 0, 0, 0, 0, 0];
          for (const d of c.dice) counts[d]++;
          return winList.every(uid => {
            const bets = this.roundBets.get(parseInt(uid)) || [];
            return bets.some(b => this.calcBetWin(b, counts) > 0);
          });
        });
        if (filtered.length > 0) candidates = filtered;
        await redis.clearWinList();
      }
    } catch (e) {
      logger.warn('杀率名单失败', e.message);
    }

    // 机器人胜负控制（区分庄家和闲家）
    if (this.botManager) {
      const allBots = this.botManager.getAllBots();
      for (const bot of allBots) {
        const ctrl = bot.control;
        if (ctrl === 'auto') continue;
        const isBanker = (bot.botId === this.bankerUserId);
        if (isBanker) {
          // 庄家赢 = 平台盈利(玩家输), 庄家输 = 平台亏损(玩家赢)
          if (ctrl === 'win') {
            const filtered = candidates.filter(c => c.profit > 0);
            if (filtered.length > 0) candidates = filtered;
            logger.info('机器人庄家控制-赢(玩家输)', { botId: bot.botId, remaining: candidates.length });
          } else if (ctrl === 'lose') {
            const filtered = candidates.filter(c => c.profit < 0);
            if (filtered.length > 0) candidates = filtered;
            logger.info('机器人庄家控制-输(玩家赢)', { botId: bot.botId, remaining: candidates.length });
          }
        } else {
          // 闲家赢 = 下注命中, 闲家输 = 下注没中
          const bets = this.roundBets.get(bot.botId) || [];
          if (bets.length === 0) continue;
          if (ctrl === 'win') {
            const filtered = candidates.filter(c => { const counts = [0,0,0,0,0,0]; for(const d of c.dice) counts[d]++; return bets.some(b => this.calcBetWin(b, counts) > 0); });
            if (filtered.length > 0) candidates = filtered;
            logger.info('机器人闲家控制-赢', { botId: bot.botId, remaining: candidates.length });
          } else if (ctrl === 'lose') {
            const filtered = candidates.filter(c => { const counts = [0,0,0,0,0,0]; for(const d of c.dice) counts[d]++; return bets.every(b => this.calcBetWin(b, counts) <= 0); });
            if (filtered.length > 0) candidates = filtered;
            logger.info('机器人闲家控制-输', { botId: bot.botId, remaining: candidates.length });
          }
        }
      }
    }

    const safe = candidates.filter(c => c.profit >= -this.maxLossPerRound);
    if (safe.length > 0) candidates = safe;

    const wins = candidates.filter(c => c.profit >= 0);
    const loses = candidates.filter(c => c.profit < 0);

    let final;
    if (Math.random() < this.killRate && wins.length > 0) final = wins;
    else if (loses.length > 0) final = loses;
    else final = candidates;

    const chosen = final[randomInt(0, final.length - 1)];
    logger.info('开奖', { dice: chosen.dice, profit: chosen.profit });
    return chosen.dice;
  }

  // ===== 广播/工具 =====

  broadcast(msg) {
    const data = JSON.stringify(msg);
    for (const [userId, ws] of this.room.clients) {
      if (ws.readyState === 1) {
        try { ws.send(data); } catch (e) {}
      }
    }
  }

  sendTo(ws, msg) {
    if (ws && ws.readyState === 1) {
      try { ws.send(JSON.stringify(msg)); } catch (e) {}
    }
  }

  broadcastPhase(phase, countdown, extra = {}) {
    // 同步 room.state，让 leaveSeat 的游戏中保护生效
    const phaseToState = {
      waiting: 'WAITING', prepare: 'PREPARING', grab: 'GRABBING',
      shaking: 'SHAKING', betting: 'BETTING', revealing: 'OPENING', settling: 'SETTLING'
    };
    if (phaseToState[phase]) this.room.state = phaseToState[phase];

    this.broadcast({
      type: 'phase', phase, countdown,
      round: this.roundNo,
      ...extra
    });
  }

  startCountdown(seconds, callback) {
    this.clearTimers();
    this.countdown = seconds;

    this.countdownTimer = setInterval(() => {
      this.countdown--;
      if (this.countdown <= 0) {
        this.clearTimers();
        callback();
      } else {
        this.broadcast({ type: 'countdown', seconds: this.countdown });
      }
    }, 1000);
  }

  clearTimers() {
    if (this.timer) { clearTimeout(this.timer); this.timer = null; }
    if (this.countdownTimer) { clearInterval(this.countdownTimer); this.countdownTimer = null; }
  }

  safeRestart() {
    this.clearTimers();
    this.timer = setTimeout(() => {
      if (this.isRunning) this.startPreparePhase();
    }, 3000);
  }

  cleanOfflinePlayers() {
    for (const [idx, seat] of Object.entries(this.room.seats)) {
      if (!seat || seat.isBot) continue;
      // 检查是否标记离线，或者WS已断开
      const ws = this.room.clients.get(seat.userId);
      const isOffline = seat.offline || !ws || ws.readyState !== 1;
      if (isOffline) {
        logger.info(`清理离线玩家 ${seat.userName}(${seat.userId}) 座位#${idx}`);
        // 清除庄家
        if (parseInt(idx) === this.bankerSeat) {
          this.bankerSeat = -1;
          this.bankerUserId = null;
        }
        delete this.room.seats[idx];
        // 广播离座
        this.broadcast({
          type: 'left_seat',
          seat: parseInt(idx),
          userId: seat.userId
        });
      }
    }
  }

  async processAgentCommission(userId, turnover) {
    try {
      const user = await User.findById(userId);
      if (!user || !user.tuid || user.tuid === 0) return;
      const commission = turnover * (config.game.agentCommission || 0.03);
      if (commission <= 0) return;
      await User.updateYongjin(user.tuid, commission);
      await Transaction.add(user.tuid, 5, commission, userId, '下级游戏佣金');
    } catch (e) {
      logger.error('佣金失败', e.message);
    }
  }

  tryStart() {
    // 检查是否有足够的入座玩家来启动
    if (!this.isRunning && this.room.getSeatedCount() >= 2) {
      this.startLoop();
    }
  }
}

module.exports = GameLogic;
