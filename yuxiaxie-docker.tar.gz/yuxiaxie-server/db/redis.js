const Redis = require('ioredis');
const config = require('../config');
const logger = require('../utils/logger');

let client = null;

/**
 * 获取Redis客户端
 */
function getClient() {
  if (!client) {
    const opts = {
      host: config.redis.host,
      port: config.redis.port,
      retryStrategy(times) {
        const delay = Math.min(times * 200, 3000);
        return delay;
      }
    };
    if (config.redis.password) {
      opts.password = config.redis.password;
    }
    client = new Redis(opts);

    client.on('connect', () => {
      logger.info('Redis连接成功', { host: config.redis.host });
    });
    client.on('error', (err) => {
      logger.error('Redis连接错误', { error: err.message });
    });
  }
  return client;
}

// ===== 在线用户 =====

async function setOnline(userId, data) {
  const r = getClient();
  await r.set(`online:${userId}`, JSON.stringify(data), 'EX', 86400);
}

async function getOnline(userId) {
  const r = getClient();
  const val = await r.get(`online:${userId}`);
  return val ? JSON.parse(val) : null;
}

async function delOnline(userId) {
  const r = getClient();
  await r.del(`online:${userId}`);
}

// ===== 登录令牌 =====

async function setToken(apptoken, userId) {
  const r = getClient();
  await r.set(`token:${apptoken}`, userId, 'EX', 86400 * 7);
}

async function getTokenUser(apptoken) {
  const r = getClient();
  return await r.get(`token:${apptoken}`);
}

async function delToken(apptoken) {
  const r = getClient();
  await r.del(`token:${apptoken}`);
}

// ===== 余额缓存 =====

async function setBalance(userId, amount) {
  const r = getClient();
  await r.set(`balance:${userId}`, amount.toString(), 'EX', 3600);
}

async function getBalance(userId) {
  const r = getClient();
  const val = await r.get(`balance:${userId}`);
  return val !== null ? parseFloat(val) : null;
}

async function delBalance(userId) {
  const r = getClient();
  await r.del(`balance:${userId}`);
}

// ===== 房间状态 =====

async function setRoomState(roomId, state) {
  const r = getClient();
  await r.set(`room:${roomId}:state`, JSON.stringify(state));
}

async function getRoomState(roomId) {
  const r = getClient();
  const val = await r.get(`room:${roomId}:state`);
  return val ? JSON.parse(val) : null;
}

// ===== 杀率临时配置 =====

async function setKillList(userId) {
  const r = getClient();
  await r.sadd('kill:list', userId.toString());
}

async function getKillList() {
  const r = getClient();
  return await r.smembers('kill:list');
}

async function clearKillList() {
  const r = getClient();
  await r.del('kill:list');
}

async function setWinList(userId) {
  const r = getClient();
  await r.sadd('win:list', userId.toString());
}

async function getWinList() {
  const r = getClient();
  return await r.smembers('win:list');
}

async function clearWinList() {
  const r = getClient();
  await r.del('win:list');
}

/**
 * 测试连接
 */
async function testConnection() {
  try {
    const r = getClient();
    await r.ping();
    logger.info('Redis连接测试成功');
    return true;
  } catch (err) {
    logger.error('Redis连接失败', { error: err.message });
    return false;
  }
}

/**
 * 关闭Redis连接
 */
async function close() {
  if (client) {
    await client.quit();
    client = null;
    logger.info('Redis连接已关闭');
  }
}

module.exports = {
  getClient,
  setOnline, getOnline, delOnline,
  setToken, getTokenUser, delToken,
  setBalance, getBalance, delBalance,
  setRoomState, getRoomState,
  setKillList, getKillList, clearKillList,
  setWinList, getWinList, clearWinList,
  testConnection, close
};
