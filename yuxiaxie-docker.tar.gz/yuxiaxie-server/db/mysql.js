const mysql = require('mysql2/promise');
const config = require('../config');
const logger = require('../utils/logger');

let pool = null;

/**
 * 获取MySQL连接池
 */
function getPool() {
  if (!pool) {
    pool = mysql.createPool(config.db);
    logger.info('MySQL连接池已创建', { host: config.db.host, database: config.db.database });
  }
  return pool;
}

/**
 * 执行SQL查询
 */
async function query(sql, params = []) {
  const p = getPool();
  const [rows] = await p.execute(sql, params);
  return rows;
}

/**
 * 获取单条记录
 */
async function queryOne(sql, params = []) {
  const rows = await query(sql, params);
  return rows[0] || null;
}

/**
 * 插入并返回insertId
 */
async function insert(sql, params = []) {
  const p = getPool();
  const [result] = await p.execute(sql, params);
  return result.insertId;
}

/**
 * 更新/删除并返回affectedRows
 */
async function update(sql, params = []) {
  const p = getPool();
  const [result] = await p.execute(sql, params);
  return result.affectedRows;
}

/**
 * 事务执行
 */
async function transaction(callback) {
  const p = getPool();
  const conn = await p.getConnection();
  try {
    await conn.beginTransaction();
    const result = await callback(conn);
    await conn.commit();
    return result;
  } catch (err) {
    await conn.rollback();
    throw err;
  } finally {
    conn.release();
  }
}

/**
 * 测试连接
 */
async function testConnection() {
  try {
    const p = getPool();
    const conn = await p.getConnection();
    conn.release();
    logger.info('MySQL连接测试成功');
    return true;
  } catch (err) {
    logger.error('MySQL连接失败', { error: err.message });
    return false;
  }
}

/**
 * 关闭连接池
 */
async function close() {
  if (pool) {
    await pool.end();
    pool = null;
    logger.info('MySQL连接池已关闭');
  }
}

module.exports = { getPool, query, queryOne, insert, update, transaction, testConnection, close };
