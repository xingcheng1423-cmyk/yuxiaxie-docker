const db = require('../db/mysql');
const logger = require('../utils/logger');
const { randomInt } = require('../utils/helpers');

const BOT_ID_BASE = 10000;

class BotManager {
  constructor() {
    this.roomBots = new Map(); // roomId => [botId]
    this.botConfigs = new Map(); // botId => { dbId, name, avatar, balance, control }
    this._rooms = new Map(); // roomId => room 引用
  }

  /**
   * 从数据库加载机器人配置并入座
   */
  async autoJoin(room) {
    // 防止重复调用：如果该房间已有bot，先跳过
    if (this.roomBots.has(room.id) && this.roomBots.get(room.id).length > 0) {
      logger.info(`房间${room.id}已有机器人，跳过autoJoin`);
      return;
    }

    // 只取前N个bot（不超过座位数-2，留2个位给真人）
    const maxBots = Math.max(room.maxSeats - 2, 1);
    const rows = await db.query('SELECT * FROM bots WHERE status = 1 ORDER BY sort_order, id LIMIT ' + parseInt(maxBots));
    if (rows.length === 0) {
      logger.info('无可用机器人');
      return;
    }

    const bots = [];
    const seenIds = new Set(); // 防止同名bot重复入座
    const half = Math.floor(room.maxSeats / 2);
    let leftNext = true; // 交替左右入座
    for (const row of rows) {
      const botId = BOT_ID_BASE + row.id;

      // 防止重复
      if (seenIds.has(row.name)) continue;
      seenIds.add(row.name);

      // 余额不足：重置余额而不是跳过
      if (row.balance != null && row.balance <= 0) {
        row.balance = 10000;
        db.query('UPDATE bots SET balance = 10000 WHERE id = ?', [row.id]).catch(() => {});
      }

      // 交替左右找空座位（左0~half-1，右half~maxSeats-1）
      let seat = -1;
      if (leftNext) {
        for (let s = 0; s < half; s++) { if (!room.seats[s]) { seat = s; break; } }
        if (seat < 0) { for (let s = half; s < room.maxSeats; s++) { if (!room.seats[s]) { seat = s; break; } } }
      } else {
        for (let s = half; s < room.maxSeats; s++) { if (!room.seats[s]) { seat = s; break; } }
        if (seat < 0) { for (let s = 0; s < half; s++) { if (!room.seats[s]) { seat = s; break; } } }
      }
      leftNext = !leftNext;
      if (seat < 0) break;

      room.sitDown(seat, {
        userId: botId,
        userName: row.name,
        userImage: row.avatar || '',
        diamond: row.balance || 10000,
        isBot: true
      });

      bots.push(botId);
      this.botConfigs.set(botId, {
        dbId: row.id,
        name: row.name,
        avatar: row.avatar || '',
        balance: row.balance,
        control: row.control || 'auto'
      });

      logger.info(`机器人 ${row.name}(${botId}) 入座房间${room.id} #${seat}`);
    }

    this.roomBots.set(room.id, bots);
    this._rooms.set(room.id, room);
  }

  /**
   * 机器人自动准备
   */
  autoReady(gameLogic) {
    const bots = this.roomBots.get(gameLogic.room.id) || [];
    for (const botId of bots) {
      const delay = randomInt(500, 3000);
      setTimeout(() => {
        if (gameLogic.phase !== 'prepare') return;
        gameLogic.botReady(botId);
      }, delay);
    }
  }

  /**
   * 机器人随机抢庄
   */
  autoGrab(gameLogic) {
    const bots = this.roomBots.get(gameLogic.room.id) || [];
    for (const botId of bots) {
      const delay = randomInt(1000, 5000);
      setTimeout(() => {
        if (gameLogic.phase !== 'grab') return;
        const isGrab = Math.random() < 0.3;
        gameLogic.botGrab(botId, isGrab);
      }, delay);
    }
  }

  /**
   * 机器人自动下注
   */
  autoBet(gameLogic, betTimeSeconds) {
    const bots = this.roomBots.get(gameLogic.room.id) || [];
    const allChips = gameLogic.chips || [10, 50, 100, 500, 1000];
    const botMinBet = gameLogic.botMinBet || 10;
    const botMaxBet = gameLogic.botMaxBet || 1000;
    const chips = allChips.filter(c => c >= botMinBet && c <= botMaxBet);
    if (chips.length === 0) return;

    for (const botId of bots) {
      if (botId === gameLogic.bankerUserId) continue;

      const betCount = randomInt(1, 3);
      for (let j = 0; j < betCount; j++) {
        const maxDelay = (betTimeSeconds - 2) * 1000;
        const delay = randomInt(500, Math.max(1000, maxDelay));

        setTimeout(() => {
          if (gameLogic.phase !== 'betting') return;
          const animal = randomInt(0, 5);
          const maxIdx = chips.length - 1;
          const chipIdx = Math.random() < 0.7 ? randomInt(0, Math.min(2, maxIdx)) : randomInt(0, maxIdx);
          const amount = chips[chipIdx];
          if (!amount) return;
          gameLogic.botBet(botId, [animal], amount, 'single');
        }, delay);
      }
    }
  }

  /**
   * 设置机器人胜负控制（同时写入DB持久化）
   */
  async setBotControl(botId, mode) {
    if (!['win', 'lose', 'auto'].includes(mode)) mode = 'auto';
    const cfg = this.botConfigs.get(botId);
    if (cfg) {
      cfg.control = mode;
      await db.query('UPDATE bots SET control = ? WHERE id = ?', [mode, cfg.dbId]).catch(e => {
        logger.warn('更新机器人控制失败', e.message);
      });
    }
    logger.info(`机器人控制: ${cfg ? cfg.name : botId} => ${mode}`);
  }

  /**
   * 获取机器人控制模式
   */
  getBotControl(botId) {
    const cfg = this.botConfigs.get(botId);
    return cfg ? cfg.control : 'auto';
  }

  /**
   * 获取所有机器人列表（带控制状态）
   */
  getBotsList(roomId) {
    const bots = this.roomBots.get(roomId) || [];
    return bots.map(id => {
      const cfg = this.botConfigs.get(id) || {};
      return { botId: id, dbId: cfg.dbId, name: cfg.name || '???', avatar: cfg.avatar || '', control: cfg.control || 'auto', balance: cfg.balance };
    });
  }

  /**
   * 获取所有房间的所有机器人
   */
  getAllBots() {
    const result = [];
    for (const [roomId, bots] of this.roomBots) {
      for (const id of bots) {
        const cfg = this.botConfigs.get(id) || {};
        result.push({
          botId: id,
          dbId: cfg.dbId,
          roomId,
          name: cfg.name || '???',
          avatar: cfg.avatar || '',
          control: cfg.control || 'auto',
          balance: cfg.balance
        });
      }
    }
    return result;
  }

  /**
   * 添加机器人（DB + 内存 + 入座）
   */
  async addBot(name, balance, room) {
    balance = balance || 10000;
    if (balance <= 0) {
      return { ok: false, msg: '机器人余额不足，无法入座' };
    }

    // 检查活跃bot数量限制（最多maxSeats-2个）
    const activeCount = await db.queryOne('SELECT COUNT(*) as cnt FROM bots WHERE status = 1');
    if (activeCount && activeCount.cnt >= room.maxSeats - 2) {
      return { ok: false, msg: '机器人数量已达上限（' + (room.maxSeats - 2) + '个）' };
    }

    // 检查重名（活跃bot中不能有同名的）
    const existing = await db.queryOne('SELECT id FROM bots WHERE name = ? AND status = 1', [name.trim()]);
    if (existing) {
      return { ok: false, msg: '已存在同名机器人: ' + name };
    }

    const id = await db.insert(
      'INSERT INTO bots (name, balance, status, control) VALUES (?, ?, 1, ?)',
      [name, balance, 'auto']
    );

    const botId = BOT_ID_BASE + id;

    // 找人少的一侧入座
    const half = Math.floor(room.maxSeats / 2);
    let leftCount = 0, rightCount = 0;
    for (let s = 0; s < half; s++) { if (room.seats[s]) leftCount++; }
    for (let s = half; s < room.maxSeats; s++) { if (room.seats[s]) rightCount++; }

    let seat = -1;
    if (leftCount <= rightCount) {
      for (let s = 0; s < half; s++) { if (!room.seats[s]) { seat = s; break; } }
      if (seat < 0) { for (let s = half; s < room.maxSeats; s++) { if (!room.seats[s]) { seat = s; break; } } }
    } else {
      for (let s = half; s < room.maxSeats; s++) { if (!room.seats[s]) { seat = s; break; } }
      if (seat < 0) { for (let s = 0; s < half; s++) { if (!room.seats[s]) { seat = s; break; } } }
    }
    if (seat < 0) return { ok: false, msg: '没有空座位' };

    room.sitDown(seat, {
      userId: botId,
      userName: name,
      userImage: '',
      diamond: balance || 10000,
      isBot: true
    });

    this.botConfigs.set(botId, { dbId: id, name, avatar: '', balance: balance || 10000, control: 'auto' });
    const bots = this.roomBots.get(room.id) || [];
    bots.push(botId);
    this.roomBots.set(room.id, bots);
    this._rooms.set(room.id, room);

    logger.info(`新增机器人 ${name}(${botId}) 入座#${seat}`);
    return { ok: true, botId, dbId: id, seat };
  }

  /**
   * 删除机器人（DB + 内存 + 离座）
   */
  async removeBot(dbId, room) {
    const botId = BOT_ID_BASE + dbId;
    const cfg = this.botConfigs.get(botId);
    if (!cfg) return { ok: false, msg: '机器人不存在' };

    const seat = room.findSeatByUser(botId);
    if (seat !== null) {
      // 使用 room.leaveSeat，遵循游戏阶段保护
      // 如果游戏中无法离座，标记bot为待删除，先从内存移除
      room.leaveSeat(seat);
      // 如果leaveSeat因游戏进行中而未删除座位，强制删除（管理员操作优先）
      if (room.seats[seat] && room.seats[seat].userId === botId) {
        delete room.seats[seat];
      }
    }

    this.botConfigs.delete(botId);
    for (const [roomId, bots] of this.roomBots) {
      const idx = bots.indexOf(botId);
      if (idx >= 0) bots.splice(idx, 1);
    }

    await db.query('UPDATE bots SET status = 0 WHERE id = ?', [dbId]);
    logger.info(`删除机器人 ${cfg.name}(${botId})`);
    return { ok: true };
  }

  /**
   * 更新机器人信息（名称/头像）
   */
  async updateBot(dbId, updates) {
    const botId = BOT_ID_BASE + dbId;
    const cfg = this.botConfigs.get(botId);
    if (!cfg) return { ok: false, msg: '机器人不存在' };

    const fields = [];
    const params = [];
    if (updates.name !== undefined && updates.name.trim()) {
      fields.push('name = ?');
      params.push(updates.name.trim());
      cfg.name = updates.name.trim();
    }
    if (updates.avatar !== undefined) {
      fields.push('avatar = ?');
      params.push(updates.avatar);
      cfg.avatar = updates.avatar;
    }
    if (updates.balance !== undefined && !isNaN(updates.balance)) {
      fields.push('balance = ?');
      params.push(parseInt(updates.balance));
      cfg.balance = parseInt(updates.balance);
    }
    if (fields.length === 0) return { ok: false, msg: '无修改项' };

    params.push(dbId);
    await db.query(`UPDATE bots SET ${fields.join(', ')} WHERE id = ?`, params);

    // 同步到房间座位
    for (const [roomId, bots] of this.roomBots) {
      if (!bots.includes(botId)) continue;
      const room = this._rooms && this._rooms.get(roomId);
      if (!room) continue;
      const seatIdx = room.findSeatByUser(botId);
      if (seatIdx === null) continue;
      const seat = room.seats[seatIdx];
      if (!seat) continue;
      if (updates.name !== undefined && updates.name.trim()) seat.userName = updates.name.trim();
      if (updates.avatar !== undefined) seat.userImage = updates.avatar;
      if (updates.balance !== undefined && !isNaN(updates.balance)) seat.diamond = parseInt(updates.balance);
    }

    logger.info(`更新机器人 ${cfg.name}(${botId})`, updates);
    return { ok: true, botId, name: cfg.name, avatar: cfg.avatar, balance: cfg.balance };
  }

  cleanRoom() {}
}

module.exports = BotManager;
