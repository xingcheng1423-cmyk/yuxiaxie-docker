/**
 * 鱼虾蟹 H5 游戏前端
 * 纯原生 JS，无框架依赖
 */

// ========== 常量 ==========
const ANIMALS = ['葫芦', '虎', '鸡', '蟹', '鱼', '虾'];
const ANIMAL_IMGS = ['/img/animals/hulu.png', '/img/animals/hu.png', '/img/animals/ji.png', '/img/animals/pangxie.png', '/img/animals/yu.png', '/img/animals/lonxia.png'];
const ANIMAL_ICONS = ['🍐', '🐅', '🐓', '🦀', '🐟', '🦐'];
const ANIMAL_CSS = ['animal-hulu', 'animal-hu', 'animal-ji', 'animal-xie', 'animal-yu', 'animal-xia'];
const ANIMAL_COLORS = ['#e74c3c', '#f0a500', '#e74c3c', '#2ecc71', '#4fc3f7', '#2ecc71'];
let MAX_SEATS = 10;
// ========== 全局状态 ==========
let ws = null;
let state = {
  user: null,           // { id, name, balance, avatar }
  token: null,
  mySeat: -1,           // -1 = 未入座
  phase: 'waiting',     // waiting, prepare, grab, betting, shaking, revealing, settling
  countdown: 0,
  round: 0,
  seats: {},            // { seatIndex: { userId, name, avatar, balance, ready, isBot, isBanker } }
  bankerSeat: -1,
  bankerName: '—',
  isSystemBanker: true,
  betMode: 'single',    // single, double, triple2, triple3
  selectedAnimals: [],  // 当前选中的动物
  selectedChip: 100,    // 当前选中的筹码
  myBets: {},           // { animalIndex: totalAmount }
  totalBets: {},        // { animalIndex: totalAmount } 全桌
  diceResult: [],       // [d1, d2, d3]
  history: [],          // [{ round, dice: [d1,d2,d3] }]
  timerInterval: null,
  selectedAvatar: '',   // 注册时选择的头像URL
  isWatching: false,    // 是否在观看室
  watcherCount: 0       // 观看室人数
};

// ========== WebSocket ==========
function connectWS() {
  // 关闭已有连接，防止重连时产生重复连接
  if (ws) {
    try { ws.onclose = null; ws.onerror = null; ws.close(); } catch(e) {}
    ws = null;
  }

  const host = window.location.hostname || '127.0.0.1';
  const wsPort = ':18282';
  const url = `ws://${host}${wsPort}/ws`;
  console.log('[WS] Connecting to', url);

  ws = new WebSocket(url);
  ws.onopen = () => {
    console.log('[WS] Connected');
    // 重连时重置观看状态，让 onRoomInfo 重新判断
    state.isWatching = false;
    // 如果有 token，自动登录
    if (state.token) {
      send({ type: 'login', token: state.token });
    }
  };
  ws.onmessage = (e) => {
    try {
      const msg = JSON.parse(e.data);
      handleMessage(msg);
    } catch (err) {
      console.warn('[WS] Parse error:', err, e.data);
    }
  };
  ws.onclose = () => {
    console.log('[WS] Disconnected, reconnecting in 3s...');
    setTimeout(connectWS, 3000);
  };
  ws.onerror = (e) => {
    console.error('[WS] Error:', e);
  };
}

function send(data) {
  if (ws && ws.readyState === WebSocket.OPEN) {
    ws.send(JSON.stringify(data));
    console.log('[WS] Send:', data);
  }
}

// ========== 音频系统（iOS Safari 兼容）==========
var audioCtx = null;
var audioBuffers = {};
var rawDataCache = {};
var bgmSource = null;
var bgmPlaying = false;
var bgmGain = null;
var audioUnlocked = false;
var decodeQueue = [];
var decoding = false;

var sndMap = { sndBet:'/snd/bet.mp3', sndDice:'/snd/dice.mp3', sndWin:'/snd/win.mp3', sndLose:'/snd/lose.mp3', sndCoin:'/snd/coin.mp3', sndGrab:'/snd/grab.mp3', sndSelect:'/snd/select.mp3', sndNoGrab:'/snd/noGrab.mp3' };

function unlockAudioCtx() {
  try {
    if (!audioCtx) {
      audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    }
    // 已解锁时只需恢复suspended状态，不用重复创建静音缓冲
    if (audioUnlocked) {
      if (audioCtx.state === 'suspended') audioCtx.resume();
      return audioCtx;
    }
    var silent = audioCtx.createBuffer(1, 1, 22050);
    var src = audioCtx.createBufferSource();
    src.buffer = silent;
    src.connect(audioCtx.destination);
    src.start(0);
    if (audioCtx.state === 'suspended') {
      audioCtx.resume();
    }
    audioUnlocked = true;
  } catch(e) {}
  tryDecodeAll();
  return audioCtx;
}

// 页面加载就下载原始数据
function prefetchRawData() {
  Object.keys(sndMap).forEach(function(k) {
    var url = sndMap[k];
    var xhr = new XMLHttpRequest();
    xhr.open('GET', url, true);
    xhr.responseType = 'arraybuffer';
    xhr.onload = function() {
      if (xhr.status === 200 && xhr.response) {
        rawDataCache[url] = xhr.response;
        if (audioCtx && audioUnlocked) queueDecode(url);
      }
    };
    xhr.send();
  });
}

function queueDecode(url) {
  if (audioBuffers[url]) return;
  if (decodeQueue.indexOf(url) === -1) decodeQueue.push(url);
  processDecodeQueue();
}

function processDecodeQueue() {
  if (decoding || !audioCtx || decodeQueue.length === 0) return;
  decoding = true;
  var url = decodeQueue.shift();
  var raw = rawDataCache[url];
  if (!raw || audioBuffers[url]) { decoding = false; processDecodeQueue(); return; }
  try {
    audioCtx.decodeAudioData(raw.slice(0), function(buf) {
      audioBuffers[url] = buf;
      decoding = false;
      processDecodeQueue();
    }, function() {
      decoding = false;
      processDecodeQueue();
    });
  } catch(e) { decoding = false; processDecodeQueue(); }
}

function tryDecodeAll() {
  if (!audioCtx) return;
  Object.keys(sndMap).forEach(function(k) {
    var url = sndMap[k];
    if (rawDataCache[url] && !audioBuffers[url]) queueDecode(url);
  });
}

function playSound(id) {
  if (!audioCtx || !audioUnlocked) return;
  try {
    if (audioCtx.state === 'suspended') audioCtx.resume();
    var url = sndMap[id];
    if (!url) return;
    var buf = audioBuffers[url];
    if (buf) {
      // WebAudio方式（优先）
      var s = audioCtx.createBufferSource();
      s.buffer = buf;
      var g = audioCtx.createGain();
      g.gain.value = 0.6;
      s.connect(g); g.connect(audioCtx.destination);
      s.start(0);
    } else {
      // Fallback: HTML5 Audio（iOS首次解码可能慢，用这个兜底）
      var a = new Audio(url);
      a.volume = 0.6;
      a.play().catch(function(){});
    }
  } catch(e) {}
}

prefetchRawData();

// ========== 背景音乐 ==========
function startBgm() {
  if (localStorage.getItem('yxx_bgm_off') === '1') { updateBgmBtn(false); return; }
  updateBgmBtn(false);
}

function toggleBgm() {
  unlockAudioCtx();
  if (!audioCtx) { showToast('音频初始化失败'); return; }

  if (bgmPlaying) {
    if (bgmSource) { try { bgmSource.stop(); } catch(e){} bgmSource = null; }
    bgmPlaying = false;
    localStorage.setItem('yxx_bgm_off', '1');
    updateBgmBtn(false);
    showToast('背景音乐已关闭');
  } else {
    localStorage.removeItem('yxx_bgm_off');
    showToast('加载中...');
    var xhr = new XMLHttpRequest();
    xhr.open('GET', '/snd/bgm.mp3', true);
    xhr.responseType = 'arraybuffer';
    xhr.onload = function() {
      if (!xhr.response) { showToast('音乐加载失败'); updateBgmBtn(false); return; }
      try {
        audioCtx.decodeAudioData(xhr.response.slice(0), function(buf) {
          if (bgmSource) { try { bgmSource.stop(); } catch(e){} }
          bgmSource = audioCtx.createBufferSource();
          bgmSource.buffer = buf;
          bgmSource.loop = true;
          bgmGain = audioCtx.createGain();
          bgmGain.gain.value = 0.15;
          bgmSource.connect(bgmGain); bgmGain.connect(audioCtx.destination);
          bgmSource.start(0);
          bgmPlaying = true;
          updateBgmBtn(true);
          showToast('背景音乐已开启');
        }, function() { showToast('音乐解码失败'); updateBgmBtn(false); });
      } catch(e) { showToast('播放失败'); updateBgmBtn(false); }
    };
    xhr.onerror = function() { showToast('音乐加载失败'); updateBgmBtn(false); };
    xhr.send();
  }
}

function updateBgmBtn(playing) {
  var btn = document.getElementById('btnBgm');
  if (!btn) return;
  btn.innerHTML = playing
    ? '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M11 5L6 9H2v6h4l5 4V5z"/><path d="M19.07 4.93a10 10 0 010 14.14M15.54 8.46a5 5 0 010 7.07"/></svg>'
    : '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M11 5L6 9H2v6h4l5 4V5z"/><line x1="23" y1="9" x2="17" y2="15"/><line x1="17" y1="9" x2="23" y2="15"/></svg>';
}

// 预下载 BGM 数据
var bgmRawData = null;
(function() {
  var xhr = new XMLHttpRequest();
  xhr.open('GET', '/snd/bgm.mp3', true);
  xhr.responseType = 'arraybuffer';
  xhr.onload = function() { if (xhr.status === 200 && xhr.response) bgmRawData = xhr.response; };
  xhr.send();
})();

function autoPlayBgm() {
  if (bgmPlaying || !audioCtx || !audioUnlocked) return;
  if (localStorage.getItem('yxx_bgm_off') === '1') return;
  if (!bgmRawData) return;
  try {
    audioCtx.decodeAudioData(bgmRawData.slice(0), function(buf) {
      if (bgmPlaying) return;
      bgmSource = audioCtx.createBufferSource();
      bgmSource.buffer = buf;
      bgmSource.loop = true;
      bgmGain = audioCtx.createGain();
      bgmGain.gain.value = 0.15;
      bgmSource.connect(bgmGain); bgmGain.connect(audioCtx.destination);
      bgmSource.start(0);
      bgmPlaying = true;
      updateBgmBtn(true);
    }, function() {});
  } catch(e) {}
}

// 每次触摸/点击尝试解锁（iOS需要用户交互才能播放音频）
document.addEventListener('touchstart', function() { unlockAudioCtx(); autoPlayBgm(); }, false);
document.addEventListener('click', function() { unlockAudioCtx(); autoPlayBgm(); }, false);

// BGM 按钮绑定
document.addEventListener('DOMContentLoaded', function() {
  var b = document.getElementById('btnBgm');
  if (b) b.addEventListener('click', function(e) { e.stopPropagation(); toggleBgm(); });
});

// ========== 消息处理 ==========
function handleMessage(msg) {
  console.log('[WS] Recv:', msg);

  switch (msg.type) {
    case 'login_ok':
      onLoginOk(msg);
      break;
    case 'login_fail':
      onLoginFail(msg);
      break;
    case 'room':
      onRoomInfo(msg);
      break;
    case 'seated':
      onSeated(msg);
      break;
    case 'left_seat':
      onLeftSeat(msg);
      break;
    case 'ready_ok':
      onReadyOk(msg);
      break;
    case 'phase':
      onPhaseChange(msg);
      break;
    case 'countdown':
      onCountdown(msg);
      break;
    case 'grab_ok':
      onGrabOk(msg);
      break;
    case 'grab_result':
      onGrabResult(msg);
      break;
    case 'bet_ok':
      onBetOk(msg);
      break;
    case 'bet_fail':
      onBetFail(msg);
      break;
    case 'dice_shake':
      onDiceShake(msg);
      break;
    case 'dice_result':
      onDiceResult(msg);
      break;
    case 'settle':
      onSettle(msg);
      break;
    case 'balance':
      onBalance(msg);
      break;
    case 'chat':
      onChatMsg(msg);
      break;
    case 'seats_update':
      MAX_SEATS = msg.maxSeats || 10;
      renderSeats();
      break;
    case 'watch_ok':
      onWatchOk(msg);
      break;
    case 'leave_watch_ok':
      onLeaveWatchOk(msg);
      break;
    case 'watcher_count':
      onWatcherCount(msg);
      break;
    case 'error':
      showToast(msg.msg || '操作失败');
      break;
    case 'kicked':
      showToast(msg.msg || '您在其他地方登录');
      ws = null; // 不要重连
      break;
    case 'banker_settle':
      if (msg.bankerSeat >= 0 && state.seats[msg.bankerSeat]) {
        state.seats[msg.bankerSeat].balance = msg.bankerBalance;
      }
      if (state.mySeat >= 0 && state.mySeat === msg.bankerSeat && state.user) {
        state.user.balance = msg.bankerBalance;
        updateTopBar();
      }
      state._pendingBankerSettle = { bankerWin: msg.bankerWin, bankerSeat: msg.bankerSeat };
      renderSeats();
      break;
    case 'round_skipped':
      showToast(msg.msg || '本局跳过，等待玩家');
      break;
    case 'heartbeat':
      send({ type: 'heartbeat' });
      break;
    default:
      console.log('[WS] Unknown message type:', msg.type);
  }
}

// ========== 登录/注册 ==========
function switchLoginTab(tab) {
  document.getElementById('loginForm').style.display = tab === 'login' ? 'block' : 'none';
  document.getElementById('registerForm').style.display = tab === 'register' ? 'block' : 'none';
  document.querySelectorAll('.tab-btn').forEach((btn, i) => {
    btn.classList.toggle('active', (i === 0 && tab === 'login') || (i === 1 && tab === 'register'));
  });
}

function doLogin() {
  const username = document.getElementById('loginUser').value.trim();
  const password = document.getElementById('loginPass').value;
  if (!username || !password) return showLoginMsg('请输入用户名和密码');
  showLoginMsg('');

  apiCall('userlogin', { username, password }, (res) => {
    if (res.code === 1) {
      saveAndEnter(res.data);
    } else {
      showLoginMsg(res.msg || '登录失败');
    }
  });
}

function doRegister() {
  const username = document.getElementById('regUser').value.trim();
  const nickname = document.getElementById('regNick').value.trim();
  const password = document.getElementById('regPass').value;
  const password2 = document.getElementById('regPass2').value;
  if (!username || !password) return showLoginMsg('请输入账号和密码');
  if (username.length < 3) return showLoginMsg('账号至少3个字符');
  if (!/^[a-zA-Z0-9_]+$/.test(username)) return showLoginMsg('账号只能包含字母、数字和下划线');
  if (!nickname) return showLoginMsg('请输入游戏昵称');
  if (nickname.length < 1 || nickname.length > 12) return showLoginMsg('昵称1-12个字符');
  if (password.length < 6) return showLoginMsg('密码至少6位');
  if (password !== password2) return showLoginMsg('两次密码不一致');
  showLoginMsg('');

  const avatar = state.selectedAvatar || '';
  apiCall('register', { username, password, nickname, avatar }, (res) => {
    if (res.code === 1) {
      saveAndEnter(res.data);
    } else {
      showLoginMsg(res.msg || '注册失败');
    }
  });
}

// ========== 头像选择/上传 ==========
function selectPresetAvatar(url) {
  state.selectedAvatar = url;
  const preview = document.getElementById('avatarPreview');
  const img = document.getElementById('avatarPreviewImg');
  const placeholder = preview.querySelector('.avatar-placeholder');
  img.src = url;
  img.style.display = 'block';
  if (placeholder) placeholder.style.display = 'none';
  preview.classList.add('has-avatar');
  document.querySelectorAll('.avatar-preset').forEach(el => {
    el.classList.toggle('selected', el.querySelector('img').src.endsWith(url));
  });
}

function handleAvatarUpload(input) {
  const file = input.files[0];
  if (!file) return;
  if (file.size > 2 * 1024 * 1024) { showLoginMsg('图片不能超过2MB'); return; }
  if (!/^image\//.test(file.type)) { showLoginMsg('请选择图片文件'); return; }

  showLoginMsg('上传中...');
  const formData = new FormData();
  formData.append('avatar', file);

  fetch('/api/upload-avatar', { method: 'POST', body: formData })
    .then(r => r.json())
    .then(res => {
      showLoginMsg('');
      if (res.code === 1 && res.data && res.data.url) {
        state.selectedAvatar = res.data.url;
        const preview = document.getElementById('avatarPreview');
        const img = document.getElementById('avatarPreviewImg');
        const placeholder = preview.querySelector('.avatar-placeholder');
        img.src = res.data.url;
        img.style.display = 'block';
        if (placeholder) placeholder.style.display = 'none';
        preview.classList.add('has-avatar');
        document.querySelectorAll('.avatar-preset').forEach(el => el.classList.remove('selected'));
      } else {
        showLoginMsg(res.msg || '上传失败');
      }
    })
    .catch(() => showLoginMsg('上传失败，请重试'));
  input.value = '';
}


function doLogout() {
  localStorage.removeItem('yxx_token');
  localStorage.removeItem('yxx_user');
  state.user = null;
  state.token = null;
  state.mySeat = -1;
  if (state.timerInterval) { clearInterval(state.timerInterval); state.timerInterval = null; }
  if (ws) { ws.onclose = null; ws.close(); ws = null; }
  showPage('loginPage');
}

function saveAndEnter(data) {
  state.user = {
    id: data.id,
    name: data.name || data.uid,
    balance: data.huobi || 0,
    avatar: data.touxiang || ''
  };
  state.token = data.apptoken;
  localStorage.setItem('yxx_token', data.apptoken);
  localStorage.setItem('yxx_user', JSON.stringify(state.user));
  enterGame();
}

function enterGame() {
  showPage('gamePage');
  updateTopBar();
  renderSeats();
  hideActionBtns();
  connectWS();
  startBgm();
}

function apiCall(y, data, callback) {
  const xhr = new XMLHttpRequest();
  xhr.open('POST', '/index/api/dologin', true);
  xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
  let params = 'y=' + y;
  for (const k in data) params += '&' + k + '=' + encodeURIComponent(data[k]);
  xhr.onload = function () {
    try { callback(JSON.parse(xhr.responseText)); }
    catch (e) { callback({ code: 0, msg: '网络错误' }); }
  };
  xhr.onerror = function () { callback({ code: 0, msg: '网络错误' }); };
  xhr.send(params);
}

function showLoginMsg(msg) {
  document.getElementById('loginMsg').textContent = msg;
}

// ========== 消息回调 ==========
function onLoginOk(msg) {
  if (msg.user) {
    if (!state.user) state.user = {};
    state.user.id = msg.user.id || state.user.id;
    state.user.name = msg.user.name || state.user.name;
    state.user.balance = msg.user.balance !== undefined ? msg.user.balance : state.user.balance;
    state.user.avatar = msg.user.avatar || state.user.avatar || '';
  }
  updateTopBar();
  // 请求房间信息
  send({ type: 'get_room' });
}

function onLoginFail(msg) {
  showToast(msg.msg || '登录失败，请重试');
}

function onRoomInfo(msg) {
  // 更新座位数
  if (msg.maxSeats) MAX_SEATS = msg.maxSeats;

  // 重置本地状态
  state.seats = {};
  state.totalBets = {};
  state.myBets = {};
  state.mySeat = -1;

  // 填充座位
  if (msg.seats) {
    for (const s of msg.seats) {
      state.seats[s.seat] = {
        userId: s.userId, name: s.name, avatar: s.avatar,
        balance: s.balance, ready: s.ready, isBot: s.isBot, isBanker: false
      };
      if (s.userId === state.user?.id) {
        state.mySeat = s.seat;
      }
    }
  }

  // 庄家
  if (msg.banker !== undefined) {
    state.bankerSeat = msg.banker;
    state.isSystemBanker = msg.isSystemBanker || false;
    state.bankerName = msg.bankerName || '—';
    if (state.bankerSeat >= 0 && state.seats[state.bankerSeat]) {
      state.seats[state.bankerSeat].isBanker = true;
    }
  }

  // 阶段
  if (msg.phase) {
    state.phase = msg.phase;
    state.countdown = msg.countdown || 0;
  }

  // 历史
  if (msg.history) state.history = msg.history;

  // 下注信息
  if (msg.bets) state.totalBets = msg.bets;

  // 骰子结果（断线重连用）
  if (msg.diceResult) state.diceResult = msg.diceResult;

  state.round = msg.round || 0;

  renderAll();

  // 观看人数
  if (msg.watcherCount !== undefined) {
    state.watcherCount = msg.watcherCount;
  }

  // 未入座时自动进入观看室
  if (state.mySeat < 0 && !state.isWatching) {
    doWatch();
  }

  updateWatcherUI();
}

function onSeated(msg) {
  state.seats[msg.seat] = {
    userId: msg.userId, name: msg.name, avatar: msg.avatar || '',
    balance: msg.balance || 0, ready: false, isBot: msg.isBot || false, isBanker: false
  };
  if (msg.userId === state.user?.id) {
    state.mySeat = msg.seat;
    state.isWatching = false;
  }
  renderSeats();
  updateWatcherUI();
}

function onLeftSeat(msg) {
  if (msg.userId === state.user?.id) {
    state.mySeat = -1;
    // 离座后进入观看室（不用延迟，直接执行）
    if (!state.isWatching) {
      doWatch();
    }
  }
  delete state.seats[msg.seat];
  renderSeats();
  updateWatcherUI();
}

function onReadyOk(msg) {
  if (state.seats[msg.seat]) {
    state.seats[msg.seat].ready = true;
  }
  renderSeats();
}

function onPhaseChange(msg) {
  state.phase = msg.phase;
  state.countdown = msg.countdown || 0;
  state.round = msg.round || state.round;

  startCountdown(state.countdown);

  switch (msg.phase) {
    case 'prepare':
      updatePhaseText('即将开始');
      resetBettingUI();
      hideDice();
      hideActionBtns();
      break;

    case 'grab':
      updatePhaseText('抢庄阶段');
      for (const s of Object.values(state.seats)) s.grabbed = false;
      if (state.mySeat >= 0) showActionBtn('grab');
      break;

    case 'shaking':
      updatePhaseText('摇骰中');
      document.getElementById('timerDisplay').textContent = '';
      hideActionBtns();
      playSound('sndDice');
      showDiceShaking();
      break;

    case 'betting':
      updatePhaseText('下注阶段');
      playSound('sndBet');
      stopDiceShaking();
      if (state.mySeat >= 0 && state.mySeat !== state.bankerSeat) {
        showBettingUI();
      } else {
        hideActionBtns();
      }
      break;

    case 'revealing':
      updatePhaseText('开奖');
      document.getElementById('timerDisplay').textContent = '';
      hideBettingUI();
      hideActionBtns();
      if (msg.dice) {
        state.diceResult = msg.dice;
      }
      break;

    case 'settling':
      updatePhaseText('结算中');
      document.getElementById('timerDisplay').textContent = '';
      break;

    case 'waiting':
      updatePhaseText('等待中');
      resetBettingUI();
      hideDice();
      hideActionBtns();
      // 重置座位准备状态
      for (const s of Object.values(state.seats)) s.ready = false;
      renderSeats();
      break;
  }

}

function onCountdown(msg) {
  state.countdown = msg.seconds;
  document.getElementById('timerDisplay').textContent = msg.seconds + 's';
  if (msg.text) updatePhaseText(msg.text);
}

function onGrabOk(msg) {
  if (msg.seat >= 0 && state.seats[msg.seat]) {
    state.seats[msg.seat].grabbed = true;
  }
  playSound('sndGrab');
  renderSeats();
}

function onGrabResult(msg) {
  const grabbers = msg.grabbers || [];
  if (grabbers.length > 1) {
    updatePhaseText('选庄中...');
    playGrabRoulette(grabbers, msg.bankerSeat, () => finalizeBanker(msg));
  } else {
    finalizeBanker(msg);
  }
}

function finalizeBanker(msg) {
  state.bankerSeat = msg.bankerSeat;
  state.bankerName = msg.bankerName || '—';
  state.isSystemBanker = msg.isSystem || false;
  for (const [idx, seat] of Object.entries(state.seats)) {
    seat.isBanker = parseInt(idx) === msg.bankerSeat;
    seat.grabbed = false;
  }
  document.getElementById('bankerName').textContent = state.bankerName;
  renderSeats();
  showToast(`庄家: ${state.bankerName}`);
}

function playGrabRoulette(grabbers, winnerSeat, callback) {
  if (grabbers.length <= 1) { callback(); return; }
  var winIdx = -1;
  for (var gi = 0; gi < grabbers.length; gi++) {
    if (grabbers[gi].seat === winnerSeat) { winIdx = gi; break; }
  }
  if (winIdx < 0) { callback(); return; }
  var n = grabbers.length;
  var total = 14;
  while ((total - 1) % n !== winIdx && total < 30) total++;
  var step = 0;

  // 创建飞行光圈指示器
  var ring = document.createElement('div');
  ring.className = 'grab-ring';
  document.body.appendChild(ring);

  // 判断某个grabber是否是自己
  function isMeGrabber(g) {
    return state.user && g.userId === state.user.id;
  }

  // 获取某个grabber对应的DOM位置
  function getGrabberPos(g) {
    // 自己 → 底部卡片
    if (isMeGrabber(g)) {
      var card = document.getElementById('mySeatCard');
      if (card) {
        var r = card.getBoundingClientRect();
        return { x: r.left + r.width / 2, y: r.top + r.height / 2, w: r.width, h: r.height, el: card };
      }
    }
    // 其他人 → 左右两边的座位
    var el = document.querySelector('.seat[data-seat="' + g.seat + '"]');
    if (el) {
      var r = el.getBoundingClientRect();
      return { x: r.left + r.width / 2, y: r.top + r.height / 2, w: r.width, h: r.height, el: el };
    }
    return null;
  }

  function clearAllHighlight() {
    document.querySelectorAll('.seat').forEach(function(el) { el.classList.remove('grab-highlight'); });
    var card = document.getElementById('mySeatCard');
    if (card) card.classList.remove('grab-highlight');
  }

  function tick() {
    clearAllHighlight();
    playSound('sndSelect');

    var g = grabbers[step % n];
    var pos = getGrabberPos(g);

    // 高亮对应元素
    if (pos && pos.el) {
      pos.el.classList.add('grab-highlight');
    }

    // 移动光圈到目标位置
    if (pos) {
      var size = Math.max(pos.w, pos.h) + 20;
      ring.style.left = (pos.x - size / 2) + 'px';
      ring.style.top = (pos.y - size / 2) + 'px';
      ring.style.width = size + 'px';
      ring.style.height = size + 'px';
      ring.style.opacity = '1';
    }

    step++;
    var isLast = step >= total;

    if (isLast) {
      ring.classList.add('grab-ring-winner');
      setTimeout(function() {
        ring.remove();
        clearAllHighlight();
        callback();
      }, 1200);
      return;
    }

    var p = step / total;
    var delay = 100 + p * p * 500;
    ring.style.transition = 'all ' + Math.min(delay / 1000, 0.4) + 's ease-out';
    setTimeout(tick, delay);
  }

  // 初始化光圈位置
  var firstPos = getGrabberPos(grabbers[0]);
  if (firstPos) {
    var sz = Math.max(firstPos.w, firstPos.h) + 20;
    ring.style.left = (firstPos.x - sz / 2) + 'px';
    ring.style.top = (firstPos.y - sz / 2) + 'px';
    ring.style.width = sz + 'px';
    ring.style.height = sz + 'px';
  }
  ring.style.transition = 'all 0.15s ease-out';

  setTimeout(tick, 300);
}

function onBetOk(msg) {
  // 更新全桌下注
  for (const animal of (msg.animals || [])) {
    state.totalBets[animal] = (state.totalBets[animal] || 0) + msg.amount;
    const betEl = document.getElementById('betAmt' + animal);
    if (betEl) betEl.textContent = state.totalBets[animal];
    // 筹码从座位飞入动物格
    throwChipToCell(animal, msg.amount, msg.userId === state.user?.id, msg.seat);
  }

  // 如果是自己的下注
  if (msg.userId === state.user?.id) {
    for (const animal of (msg.animals || [])) {
      state.myBets[animal] = (state.myBets[animal] || 0) + msg.amount;
      const myBetEl = document.getElementById('myBet' + animal);
      if (myBetEl) myBetEl.textContent = '我:' + state.myBets[animal];
    }
    state.user.balance = msg.newBalance !== undefined ? msg.newBalance : state.user.balance;
    updateTopBar();
  }

  // 更新座位余额
  if (msg.seat >= 0 && state.seats[msg.seat]) {
    state.seats[msg.seat].balance = msg.newBalance !== undefined ? msg.newBalance : state.seats[msg.seat].balance;
    renderSeats();
  }
}

function onBetFail(msg) {
  showToast(msg.msg || '下注失败');
}

function onDiceShake() {
  showDiceShaking();
}

function onDiceResult(msg) {
  state.diceResult = msg.dice;
  showDiceResult(msg.dice);

  // 高亮中奖动物
  const winSet = new Set(msg.dice);
  for (let i = 0; i < 6; i++) {
    const cell = document.querySelector(`.bet-cell[data-animal="${i}"]`);
    if (!cell) continue;
    if (winSet.has(i)) {
      cell.classList.add('winning');
      cell.classList.remove('dimmed');
      const mark = document.getElementById('winMark' + i);
      const count = msg.dice.filter(d => d === i).length;
      if (mark) {
        mark.textContent = count > 1 ? `×${count}` : '✓';
        mark.style.display = 'block';
      }
    } else {
      cell.classList.add('dimmed');
    }
  }

  // 添加到历史
  state.history.unshift({ round: state.round, dice: msg.dice });
  if (state.history.length > 50) state.history.pop();
  renderHistory();
}

function onSettle(msg) {
  const results = msg.results || [];

  function getBankerPos() {
    if (state.bankerSeat >= 0) {
      if (state.seats[state.bankerSeat] && state.seats[state.bankerSeat].userId === state.user?.id) {
        const el = document.getElementById('mySeatCard');
        if (el && el.offsetParent) { const r = el.getBoundingClientRect(); return { x: r.left + r.width / 2, y: r.top + r.height / 2 }; }
      }
      const el = document.querySelector(`.seat[data-seat="${state.bankerSeat}"]`);
      if (el) { const r = el.getBoundingClientRect(); return { x: r.left + r.width / 2, y: r.top + r.height / 2 }; }
    }
    const bi = document.querySelector('.banker-info');
    if (bi) { const r = bi.getBoundingClientRect(); return { x: r.left + r.width / 2, y: r.top + r.height / 2 }; }
    return { x: window.innerWidth / 2, y: 200 };
  }

  function getSeatPos(userId) {
    if (userId === state.user?.id) {
      const el = document.getElementById('mySeatCard');
      if (el && el.offsetParent) { const r = el.getBoundingClientRect(); return { x: r.left + r.width / 2, y: r.top + r.height / 2 }; }
    }
    for (const [idx, seat] of Object.entries(state.seats)) {
      if (seat && seat.userId === userId) {
        const el = document.querySelector(`.seat[data-seat="${idx}"]`);
        if (el) { const r = el.getBoundingClientRect(); return { x: r.left + r.width / 2, y: r.top + r.height / 2 }; }
      }
    }
    return null;
  }

  var bankerPos = getBankerPos();
  var winners = results.filter(function(r) { return r.win > 0 && getSeatPos(r.userId); });
  var losers = results.filter(function(r) { return r.win < 0 && getSeatPos(r.userId); });
  var draws = results.filter(function(r) { return r.win === 0 && getSeatPos(r.userId); });

  // ===== 第1步：所有筹码从格子飞向庄家（收集）=====
  playSound('sndCoin');
  var allChips = document.querySelectorAll('.cell-chips .cell-chip');
  allChips.forEach(function(chip, ci) {
    var r = chip.getBoundingClientRect();
    var fly = chip.cloneNode(true);
    fly.classList.add('cell-chip-fly');
    fly.style.left = r.left + 'px';
    fly.style.top = r.top + 'px';
    fly.style.transition = 'all 0.7s cubic-bezier(.25,.8,.25,1)';
    fly.style.transitionDelay = (ci * 30) + 'ms';
    document.body.appendChild(fly);
    requestAnimationFrame(function() {
      fly.style.left = (bankerPos.x - 14) + 'px';
      fly.style.top = (bankerPos.y - 14) + 'px';
      fly.style.opacity = '0.3';
      fly.style.transform = 'scale(0.3)';
    });
    setTimeout(function() { fly.remove(); }, 900);
  });
  clearAllCellChips();

  // 庄家位置闪光效果
  setTimeout(function() {
    var glow = document.createElement('div');
    glow.className = 'banker-glow';
    glow.style.left = bankerPos.x + 'px';
    glow.style.top = bankerPos.y + 'px';
    document.body.appendChild(glow);
    setTimeout(function() { glow.remove(); }, 800);
  }, 700);

  // ===== 第2步：输家金币飞向庄家 =====
  setTimeout(function() {
    // 输家标签 + 金币飞向庄家
    losers.forEach(function(r, li) {
      var pos = getSeatPos(r.userId);
      if (!pos) return;
      var text = formatNum(r.win);
      showSettleLabel(pos, text, false);

      var coinCount = Math.min(Math.ceil(Math.abs(r.win) / 500), 6);
      for (var c = 0; c < coinCount; c++) {
        (function(delay) {
          setTimeout(function() {
            flySettleCoin(pos, bankerPos, false);
          }, li * 150 + delay * 100);
        })(c);
      }
    });

    // 平局玩家显示 +0
    draws.forEach(function(r) {
      var pos = getSeatPos(r.userId);
      if (!pos) return;
      showSettleLabel(pos, '+0', null);
    });
  }, 1000);

  // ===== 第3步：庄家再发金币给赢家 =====
  var step3Delay = 1000 + Math.max(losers.length * 150 + 600, 800);
  setTimeout(function() {
    playSound('sndCoin');

    // 赢家标签 + 金币从庄家飞出
    winners.forEach(function(r, wi) {
      var pos = getSeatPos(r.userId);
      if (!pos) return;
      var text = '+' + formatNum(r.win);
      showSettleLabel(pos, text, true);

      var coinCount = Math.min(Math.ceil(Math.abs(r.win) / 500), 6);
      for (var c = 0; c < coinCount; c++) {
        (function(delay) {
          setTimeout(function() {
            flySettleCoin(bankerPos, pos, true);
          }, wi * 150 + delay * 100);
        })(c);
      }
    });
  }, step3Delay);

  // ===== 第4步：更新数据 =====
  var step4Delay = step3Delay + Math.max(winners.length * 150 + 600, 800);
  setTimeout(function() {
    var myResult = results.find(function(r) { return r.userId === state.user?.id; });
    if (myResult) {
      state.user.balance = myResult.newBalance !== undefined ? myResult.newBalance : state.user.balance;
      updateTopBar();
    }
    for (var i = 0; i < results.length; i++) {
      var r = results[i];
      for (var idx in state.seats) {
        if (state.seats[idx].userId === r.userId) {
          state.seats[idx].balance = r.newBalance !== undefined ? r.newBalance : state.seats[idx].balance;
        }
      }
    }
    renderSeats();
  }, step4Delay);

  // ===== 第5步：最后显示庄家输赢 =====
  var step5Delay = step4Delay + 600;
  setTimeout(function() {
    var pending = state._pendingBankerSettle;
    if (!pending || pending.bankerWin === undefined) return;
    var bPos = null;
    if (state.seats[pending.bankerSeat] && state.seats[pending.bankerSeat].userId === state.user?.id) {
      var bEl = document.getElementById('mySeatCard');
      if (bEl && bEl.offsetParent) { var br = bEl.getBoundingClientRect(); bPos = { x: br.left + br.width / 2, y: br.top + br.height / 2 }; }
    }
    if (!bPos) {
      var bEl2 = document.querySelector('.seat[data-seat="' + pending.bankerSeat + '"]');
      if (bEl2) { var br2 = bEl2.getBoundingClientRect(); bPos = { x: br2.left + br2.width / 2, y: br2.top + br2.height / 2 }; }
    }
    if (!bPos) {
      var bi = document.querySelector('.banker-info');
      if (bi) { var br3 = bi.getBoundingClientRect(); bPos = { x: br3.left + br3.width / 2, y: br3.top + br3.height / 2 }; }
    }
    if (bPos) {
      var bText = pending.bankerWin >= 0 ? '+' + formatNum(pending.bankerWin) : formatNum(pending.bankerWin);
      showSettleLabel(bPos, bText, pending.bankerWin > 0 ? true : (pending.bankerWin < 0 ? false : null));
    }
    state._pendingBankerSettle = null;
  }, step5Delay);
}

// 结算金币飞行
function flySettleCoin(from, to, isWin) {
  var coin = document.createElement('div');
  coin.className = 'settle-coin';
  // 加点随机偏移让多个金币不完全重叠
  var ox = (Math.random() - 0.5) * 20;
  var oy = (Math.random() - 0.5) * 20;
  coin.style.left = (from.x + ox) + 'px';
  coin.style.top = (from.y + oy) + 'px';
  document.body.appendChild(coin);
  requestAnimationFrame(function() {
    coin.style.left = (to.x + ox) + 'px';
    coin.style.top = (to.y + oy) + 'px';
    coin.style.opacity = '0.4';
  });
  setTimeout(function() { coin.remove(); }, 600);
}

// 座位输赢金额标签
function showSettleLabel(pos, text, isWin) {
  var el = document.createElement('div');
  var cls = isWin === null ? 'draw' : (isWin ? 'win' : 'lose');
  el.className = 'settle-label ' + cls;
  el.textContent = text;
  el.style.left = pos.x + 'px';
  el.style.top = (pos.y - 30) + 'px';
  document.body.appendChild(el);
  requestAnimationFrame(function() {
    el.style.top = (pos.y - 60) + 'px';
  });
  setTimeout(function() {
    el.style.opacity = '0';
    el.style.top = (pos.y - 80) + 'px';
  }, 1800);
  setTimeout(function() { el.remove(); }, 2500);
}

function onBalance(msg) {
  if (!state.user) return;
  state.user.balance = msg.balance;
  updateTopBar();
}

function onChatMsg(msg) {
  appendChat(msg.name || '???', msg.text || '');
}

// ========== 观看室回调 ==========
function onWatchOk() {
  state.isWatching = true;
  state.mySeat = -1;
  showToast('已进入观看室');
  hideActionBtns();
  updateWatcherUI();
}

function onLeaveWatchOk() {
  state.isWatching = false;
  updateWatcherUI();
}

function onWatcherCount(msg) {
  state.watcherCount = msg.count || 0;
  updateWatcherUI();
}

function doWatch() {
  if (state.isWatching) return; // 防止重复发送
  state.isWatching = true; // 立即标记，防止竞态重复触发
  send({ type: 'watch' });
}

function doLeaveWatch() {
  send({ type: 'leave_watch' });
  // 离开观看后尝试入座
  state.isWatching = false;
  updateWatcherUI();
  doSit();
}

function updateWatcherUI() {
  const badge = document.getElementById('watcherBadge');
  if (badge) {
    badge.textContent = '👁 观看 ' + state.watcherCount;
    badge.style.display = 'flex';
  }
  const watchBtn = document.getElementById('btnWatch');
  const leaveWatchBtn = document.getElementById('btnLeaveWatch');
  if (watchBtn) watchBtn.style.display = (state.mySeat < 0 && !state.isWatching) ? 'inline-block' : 'none';
  if (leaveWatchBtn) leaveWatchBtn.style.display = state.isWatching ? 'inline-block' : 'none';
}

// ========== 用户操作 ==========
function doSit() {
  // 找第一个空座位
  let emptySeat = -1;
  for (let i = 0; i < MAX_SEATS; i++) {
    if (!state.seats[i]) { emptySeat = i; break; }
  }
  if (emptySeat < 0) {
    showToast('没有空座位，可进入观看室');
    updateWatcherUI();
    return;
  }
  send({ type: 'sit', seat: emptySeat });
}

function doLeaveSeat() {
  send({ type: 'leave_seat' });
}

function doReady() {
  send({ type: 'ready' });
  const btn = document.getElementById('btnReady');
  if (btn) btn.style.display = 'none';
  showToast('已准备');
}

function doGrab(isGrab) {
  send({ type: 'grab', isGrab });
  hideActionBtns();
  if (!isGrab) playSound('sndNoGrab');
  showToast(isGrab ? '已抢庄' : '已放弃');
}

function selectAnimal(idx) {
  if (state.phase !== 'betting') return;
  if (state.mySeat < 0) return showToast('请先入座');
  if (state.mySeat === state.bankerSeat) return showToast('庄家不能下注');
  if (!state.selectedChip) return showToast('请选择筹码');
  if (state.selectedChip > (state.user?.balance || 0)) return showToast('余额不足');

  playSound('sndBet');
  send({
    type: 'bet',
    animals: [idx],
    amount: state.selectedChip,
    mode: 'single'
  });
}

function selectChip(amount) {
  state.selectedChip = amount;
  document.querySelectorAll('.chip').forEach(c => {
    c.classList.toggle('selected', parseInt(c.dataset.amount) === amount);
  });
}

function setBetMode(mode) {
  state.betMode = 'single';
  state.selectedAnimals = [];
  document.querySelectorAll('.bet-cell').forEach(c => c.classList.remove('selected'));
  const selEl = document.getElementById('selectedAnimals');
  if (selEl) selEl.textContent = '';
}

function confirmBet() {
  if (state.selectedAnimals.length !== 1) {
    return showToast('请选择一个动物');
  }
  if (!state.selectedChip) return showToast('请选择筹码');
  if (state.selectedChip > (state.user?.balance || 0)) return showToast('余额不足');

  playSound('sndBet');
  send({
    type: 'bet',
    animals: state.selectedAnimals,
    amount: state.selectedChip,
    mode: state.betMode
  });

  // 清除选中
  state.selectedAnimals = [];
  document.querySelectorAll('.bet-cell').forEach(c => c.classList.remove('selected'));
  document.getElementById('selectedAnimals').textContent = '';
}

function sendChat() {
  const input = document.getElementById('chatInput');
  const text = input.value.trim();
  if (!text) return;
  send({ type: 'chat', text });
  input.value = '';
}

// ========== UI 渲染 ==========
function showPage(pageId) {
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  document.getElementById(pageId).classList.add('active');
}

function updateTopBar() {
  if (!state.user) return;
  const nameEl = document.getElementById('myInfoName');
  const balEl = document.getElementById('myInfoBalance');
  if (nameEl) nameEl.textContent = state.user.name;
  if (balEl) balEl.textContent = formatNum(state.user.balance);
  const avatarEl = document.getElementById('myInfoAvatar');
  if (avatarEl && state.user.avatar) {
    avatarEl.innerHTML = '<img src="' + escHtml(state.user.avatar) + '">';
  }
}

function updatePhaseText(text) {
  document.getElementById('phaseText').textContent = text;
}

function startCountdown(seconds) {
  if (state.timerInterval) { clearInterval(state.timerInterval); state.timerInterval = null; }
  state.countdown = seconds;
  const el = document.getElementById('timerDisplay');
  el.textContent = seconds > 0 ? seconds + 's' : '--';
}

function renderAll() {
  updateTopBar();
  renderSeats();
  renderBetAmounts();
  renderHistory();

  document.getElementById('bankerName').textContent = state.bankerName;

  // 根据阶段显示按钮
  if (state.mySeat >= 0) {
    if (state.phase === 'betting' && state.mySeat !== state.bankerSeat) {
      showBettingUI();
    } else if (state.phase === 'grab') {
      showActionBtn('grab');
    } else {
      hideActionBtns();
    }
  } else {
    hideActionBtns();
  }

  if (state.phase !== 'waiting') {
    updatePhaseText({
      prepare: '准备阶段', grab: '抢庄阶段', betting: '下注阶段',
      shaking: '摇骰中', revealing: '开奖', settling: '结算中'
    }[state.phase] || state.phase);
  }

  // 断线重连时恢复骰子显示状态
  if (state.phase === 'shaking') {
    showDiceShaking();
  } else if (state.phase === 'betting') {
    stopDiceShaking();
  } else if ((state.phase === 'revealing' || state.phase === 'settling') && state.diceResult && state.diceResult.length) {
    showDiceResult(state.diceResult);
  } else {
    hideDice();
  }
}

function renderSeats() {
  const leftEl = document.getElementById('leftSeats');
  const rightEl = document.getElementById('rightSeats');
  const mySeatBar = document.getElementById('mySeatBar');
  const mySeatCard = document.getElementById('mySeatCard');
  if (!leftEl || !rightEl) return;

  let myRendered = false;
  let otherSeats = [];

  for (let i = 0; i < MAX_SEATS; i++) {
    const seat = state.seats[i];
    const isMe = seat && seat.userId === state.user?.id;

    if (isMe) {
      myRendered = true;
      let avatarHtml;
      if (seat.isBanker) {
        avatarHtml = '👑';
      } else if (seat.avatar) {
        avatarHtml = '<img src="' + escHtml(seat.avatar) + '" style="width:100%;height:100%;object-fit:cover;border-radius:50%">';
      } else {
        avatarHtml = '👤';
      }
      if (mySeatCard) {
        mySeatCard.innerHTML = `
          <div class="seat-avatar">${avatarHtml}</div>
          <div class="seat-name">${escHtml(seat.name)}</div>
          <div class="seat-balance">${formatNum(seat.balance)}</div>
          <div class="seat-status">${seat.grabbed ? '<div class="seat-grab">抢庄</div>' : (seat.ready ? '<span style="color:#4caf50">✓ 已准备</span>' : '')}</div>
        `;
      }
      if (mySeatBar) mySeatBar.style.display = 'flex';
      continue;
    }

    let seatHtml;
    if (seat) {
      let cls = 'seat occupied';
      if (seat.isBanker) cls += ' banker';
      if (seat.ready) cls += ' ready';

      let avatarHtml;
      if (seat.isBanker) {
        avatarHtml = '👑';
      } else if (seat.avatar) {
        avatarHtml = '<img src="' + escHtml(seat.avatar) + '" style="width:100%;height:100%;object-fit:cover;border-radius:50%">';
      } else {
        avatarHtml = seat.isBot ? '🤖' : '👤';
      }
      seatHtml = `<div class="${cls}" data-seat="${i}">
        <div class="seat-avatar">${avatarHtml}</div>
        <div class="seat-name">${escHtml(seat.name)}</div>
        <div class="seat-balance">${formatNum(seat.balance)}</div>
        <div class="seat-status">${seat.grabbed ? '<div class="seat-grab">抢庄</div>' : (seat.ready ? '<span style="color:#4caf50">✓</span>' : '')}</div>
      </div>`;
    } else {
      seatHtml = `<div class="seat" data-seat="${i}">
        <div class="seat-avatar" style="opacity:.3">🪑</div>
        <div class="seat-name" style="color:#5a4a3a">空位</div>
      </div>`;
    }
    otherSeats.push(seatHtml);
  }

  let leftHtml = '';
  let rightHtml = '';
  for (let i = 0; i < otherSeats.length; i++) {
    if (i % 2 === 0) leftHtml += otherSeats[i];
    else rightHtml += otherSeats[i];
  }

  leftEl.innerHTML = leftHtml;
  rightEl.innerHTML = rightHtml;

  if (!myRendered && mySeatBar) {
    mySeatBar.style.display = 'none';
  }
}

function renderBetAmounts() {
  for (let i = 0; i < 6; i++) {
    const betEl = document.getElementById('betAmt' + i);
    const myBetEl = document.getElementById('myBet' + i);
    const markEl = document.getElementById('winMark' + i);
    const cellEl = document.querySelector(`.bet-cell[data-animal="${i}"]`);
    if (betEl) betEl.textContent = state.totalBets[i] || 0;
    if (myBetEl) myBetEl.textContent = state.myBets[i] ? '我:' + state.myBets[i] : '';
    if (markEl) markEl.style.display = 'none';
    if (cellEl) cellEl.classList.remove('winning', 'selected', 'dimmed');
  }
}

function renderHistory() {
  const el = document.getElementById('historyList');
  el.innerHTML = state.history.map(h => {
    const icons = h.dice.map(d => `<span style="display:inline-flex;align-items:center;gap:2px"><img src="${ANIMAL_IMGS[d]}" style="width:20px;height:20px"> <span style="color:${ANIMAL_COLORS[d]};font-weight:bold">${ANIMALS[d]}</span></span>`).join(' ');
    return `<div class="history-item">
      <span class="history-round">#${h.round}</span>
      <span class="history-dice">${icons}</span>
    </div>`;
  }).join('');
}

function resetBettingUI() {
  state.myBets = {};
  state.totalBets = {};
  state.selectedAnimals = [];
  state.betMode = 'single';
  renderBetAmounts();
  hideBettingUI();
  clearAllCellChips();
}

function showBettingUI() {
  document.getElementById('betModeArea').style.display = 'none';
  document.getElementById('chipArea').style.display = 'flex';
  document.getElementById('btnConfirmBet').style.display = 'none';
  hideActionBtns();
  selectChip(state.selectedChip);
}

function hideBettingUI() {
  document.getElementById('betModeArea').style.display = 'none';
  document.getElementById('chipArea').style.display = 'none';
}

function showActionBtn(type) {
  hideActionBtns();
  const map = { sit: 'btnSit', ready: 'btnReady', grab: 'btnGrab,btnNoGrab', leave: 'btnLeave' };
  const ids = (map[type] || '').split(',');
  ids.forEach(id => {
    const el = document.getElementById(id);
    if (el) el.style.display = 'inline-block';
  });
}

function hideActionBtns() {
  ['btnSit', 'btnReady', 'btnGrab', 'btnNoGrab', 'btnLeave'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.style.display = 'none';
  });
}

// ========== 骰子动画 ==========
function hideDice() {
  document.getElementById('diceCover').style.display = 'flex';
  document.getElementById('diceCover').className = 'dice-cover';
  document.getElementById('diceResult').style.display = 'none';
}

function stopDiceShaking() {
  const cover = document.getElementById('diceCover');
  cover.style.display = 'flex';
  cover.className = 'dice-cover';
  document.getElementById('diceResult').style.display = 'none';
}

function showDiceShaking() {
  const cover = document.getElementById('diceCover');
  cover.style.display = 'flex';
  cover.className = 'dice-cover shaking';
  document.getElementById('diceResult').style.display = 'none';
}

function showDiceResult(dice) {
  const cover = document.getElementById('diceCover');
  cover.className = 'dice-cover open';

  setTimeout(() => {
    cover.style.display = 'none';
    const resultEl = document.getElementById('diceResult');
    resultEl.style.display = 'flex';

    dice.forEach((d, i) => {
      const die = document.getElementById('die' + (i + 1));
      if (!die) return;
      die.innerHTML = `<img src="${ANIMAL_IMGS[d]}" style="width:80%;height:80%;object-fit:contain">`;
      die.style.animationDelay = (i * 0.15) + 's';
    });
  }, 500);
}

// ========== 筹码飞入动画 ==========
const CHIP_LABELS = { 10: '10', 50: '50', 100: '100', 500: '500', 1000: '1K' };

function getChipClass(amount) {
  if (amount >= 1000) return 'chip-v1000';
  if (amount >= 500) return 'chip-v500';
  if (amount >= 100) return 'chip-v100';
  if (amount >= 50) return 'chip-v50';
  return 'chip-v10';
}

function throwChipToCell(animalIdx, amount, isMine, fromSeat) {
  const cell = document.querySelector(`.bet-cell[data-animal="${animalIdx}"]`);
  if (!cell) return;

  // 确保 cell-chips 容器存在
  let chipsContainer = cell.querySelector('.cell-chips');
  if (!chipsContainer) {
    chipsContainer = document.createElement('div');
    chipsContainer.className = 'cell-chips';
    const inner = cell.querySelector('.bet-cell-inner');
    if (!inner) return;
    inner.appendChild(chipsContainer);
  }

  // 目标位置（cell 内随机）
  const cellRect = cell.getBoundingClientRect();
  const randX = 5 + Math.random() * (cellRect.width - 38);
  const randY = 5 + Math.random() * (cellRect.height - 38);

  // 起飞位置：从座位飞出
  let startX, startY;
  if (isMine) {
    // 自己：从底部座位卡片飞出
    const mySeatCard = document.getElementById('mySeatCard');
    if (mySeatCard && mySeatCard.offsetParent) {
      const r = mySeatCard.getBoundingClientRect();
      startX = r.left + r.width / 2;
      startY = r.top + r.height / 2;
    } else {
      startX = window.innerWidth / 2;
      startY = window.innerHeight - 50;
    }
  } else if (fromSeat >= 0) {
    // 其他玩家：从对应座位飞出
    const seatEl = document.querySelector(`.seat[data-seat="${fromSeat}"]`);
    if (seatEl) {
      const r = seatEl.getBoundingClientRect();
      startX = r.left + r.width / 2;
      startY = r.top + r.height / 2;
    } else {
      startX = Math.random() < 0.5 ? -20 : window.innerWidth + 20;
      startY = cellRect.top + cellRect.height / 2;
    }
  } else {
    startX = Math.random() < 0.5 ? -20 : window.innerWidth + 20;
    startY = cellRect.top + cellRect.height / 2;
  }

  // 创建飞行筹码
  const flyChip = document.createElement('div');
  flyChip.className = `cell-chip ${getChipClass(amount)} cell-chip-fly`;
  flyChip.innerHTML = `<span>${CHIP_LABELS[amount] || amount}</span>`;
  flyChip.style.left = startX + 'px';
  flyChip.style.top = startY + 'px';
  flyChip.style.opacity = '0.8';
  document.body.appendChild(flyChip);

  // 触发动画
  requestAnimationFrame(() => {
    flyChip.style.left = (cellRect.left + randX) + 'px';
    flyChip.style.top = (cellRect.top + randY) + 'px';
    flyChip.style.opacity = '1';
  });

  // 动画结束后，移除飞行筹码，添加固定筹码到 cell
  setTimeout(() => {
    flyChip.remove();
    const staticChip = document.createElement('div');
    staticChip.className = `cell-chip ${getChipClass(amount)}`;
    staticChip.innerHTML = `<span>${CHIP_LABELS[amount] || amount}</span>`;
    staticChip.style.left = randX + 'px';
    staticChip.style.top = randY + 'px';
    chipsContainer.appendChild(staticChip);
  }, 380);
}

function clearAllCellChips() {
  document.querySelectorAll('.cell-chips').forEach(c => c.innerHTML = '');
  document.querySelectorAll('.cell-chip-fly').forEach(c => c.remove());
}

// ========== 结算弹窗 ==========
function showSettlePopup(winAmount) {
  if (winAmount > 0) playSound('sndWin');
  else if (winAmount < 0) playSound('sndLose');
  const popup = document.getElementById('settlePopup');
  const amountEl = document.getElementById('settleAmount');
  const titleEl = document.getElementById('settleTitle');

  const iconEl = document.getElementById('settleIcon');
  if (winAmount > 0) {
    iconEl.textContent = '🎉';
    titleEl.textContent = '恭喜赢了！';
    amountEl.textContent = '+' + formatNum(winAmount);
    amountEl.className = 'settle-amount win';
  } else if (winAmount < 0) {
    iconEl.textContent = '😢';
    titleEl.textContent = '很遗憾';
    amountEl.textContent = formatNum(winAmount);
    amountEl.className = 'settle-amount lose';
  } else {
    iconEl.textContent = '🎲';
    titleEl.textContent = '本局结算';
    amountEl.textContent = '0';
    amountEl.className = 'settle-amount draw';
  }

  document.getElementById('settleDetail').textContent = `当前余额: ${formatNum(state.user?.balance)}`;
  popup.style.display = 'flex';
  popup.onclick = () => { popup.style.display = 'none'; };
  setTimeout(() => { popup.style.display = 'none'; }, 4000);
}

// ========== 聊天/历史面板 ==========
function toggleHistory() {
  const el = document.getElementById('historyPanel');
  const chat = document.getElementById('chatPanel');
  chat.style.display = 'none';
  el.style.display = el.style.display === 'none' ? 'flex' : 'none';
  if (el.style.display !== 'none') renderHistory();
}

function toggleChat() {
  const el = document.getElementById('chatPanel');
  const hist = document.getElementById('historyPanel');
  hist.style.display = 'none';
  el.style.display = el.style.display === 'none' ? 'flex' : 'none';
}

function appendChat(name, text) {
  const el = document.getElementById('chatMessages');
  const div = document.createElement('div');
  div.className = 'chat-msg';
  div.innerHTML = `<span class="name">${escHtml(name)}</span> <span class="text">${escHtml(text)}</span>`;
  el.appendChild(div);
  el.scrollTop = el.scrollHeight;
}

// ========== 工具函数 ==========
function showToast(msg) {
  const el = document.getElementById('toast');
  el.textContent = msg;
  el.classList.add('show');
  setTimeout(() => el.classList.remove('show'), 2500);
}

function formatNum(n) {
  if (n === undefined || n === null) return '0';
  return Number(n).toLocaleString();
}

function escHtml(s) {
  if (!s) return '';
  return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

// ========== 初始化 ==========
(function init() {
  // 绑定回车键事件（无论哪个路径都需要）
  const loginPass = document.getElementById('loginPass');
  const regPass2 = document.getElementById('regPass2');
  const chatInput = document.getElementById('chatInput');
  if (loginPass) loginPass.addEventListener('keydown', (e) => { if (e.key === 'Enter') doLogin(); });
  if (regPass2) regPass2.addEventListener('keydown', (e) => { if (e.key === 'Enter') doRegister(); });
  if (chatInput) chatInput.addEventListener('keydown', (e) => { if (e.key === 'Enter') sendChat(); });

  // 检查本地保存的登录信息
  const savedToken = localStorage.getItem('yxx_token');
  const savedUser = localStorage.getItem('yxx_user');

  if (savedToken && savedUser) {
    try {
      state.user = JSON.parse(savedUser);
      state.token = savedToken;
      enterGame();
      return;
    } catch (e) {}
  }

  // 显示登录页
  showPage('loginPage');
})();
