const { v4: uuidv4 } = require('uuid');
const crypto = require('crypto');

/**
 * 生成用户UID（游客格式：yk + 时间戳 + 随机数）
 */
function generateUID() {
  const ts = Date.now().toString().slice(-8);
  const rand = Math.floor(Math.random() * 9000 + 1000);
  return 'yk' + ts + rand;
}

/**
 * 生成apptoken
 */
function generateToken() {
  return uuidv4().replace(/-/g, '');
}

/**
 * 密码哈希
 */
function hashPassword(password) {
  return crypto.createHash('md5').update(password).digest('hex');
}

/**
 * 生成随机整数 [min, max]
 */
function randomInt(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

/**
 * 延迟
 */
function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

/**
 * 统一HTTP响应格式
 */
function apiSuccess(data = null, msg = 'success') {
  return { code: 1, data, msg };
}

function apiError(msg = '操作失败', data = null) {
  return { code: 0, data, msg };
}

/**
 * 统一WS消息格式
 */
function wsSuccess(cmd, data = {}) {
  return JSON.stringify({ cmd, ...data });
}

function wsError(cmd, msg = '操作失败') {
  return JSON.stringify({ cmd, ret: 1, msg });
}

module.exports = {
  generateUID,
  generateToken,
  hashPassword,
  randomInt,
  sleep,
  apiSuccess,
  apiError,
  wsSuccess,
  wsError
};
