require('dotenv').config();

module.exports = {
  // 服务器
  port: parseInt(process.env.PORT) || 3000,
  wsPort: parseInt(process.env.WS_PORT) || 18282,
  publicHost: process.env.PUBLIC_HOST || '127.0.0.1',

  // MySQL
  db: {
    host: process.env.DB_HOST || '127.0.0.1',
    port: parseInt(process.env.DB_PORT) || 3306,
    user: process.env.DB_USER || 'baye',
    password: process.env.DB_PASS || 'baye',
    database: process.env.DB_NAME || 'baye',
    waitForConnections: true,
    connectionLimit: 20,
    queueLimit: 0
  },

  // Redis
  redis: {
    host: process.env.REDIS_HOST || '127.0.0.1',
    port: parseInt(process.env.REDIS_PORT) || 6379,
    password: process.env.REDIS_PASS || undefined
  },

  // Token
  tokenSecret: process.env.TOKEN_SECRET || 'yuxiaxie_secret_key',

  // 后台管理员
  admin: {
    user: process.env.ADMIN_USER || 'admin',
    pass: process.env.ADMIN_PASS || 'admin123'
  },

  // 游戏默认配置
  game: {
    // 阶段时间（秒）
    prepareTime: 10,
    grabTime: 10,
    betTime: 15,
    shakeTime: 5,
    openTime: 3,
    settleTime: 3,

    // 最少开局人数
    minPlayers: 2,

    // 抢庄最低余额（默认3万）
    grabMinBalance: 30000,

    // 坐庄最低余额（没人抢庄时自动当庄的门槛，默认5000，可用 .env 的 BANK_MIN_BALANCE 改）
    bankMinBalance: parseInt(process.env.BANK_MIN_BALANCE) || 5000,

    // 机器人下注范围
    botMinBet: 10,
    botMaxBet: 1000,

    // 无真人入座时自动循环游戏（仅机器人）
    autoLoopNoBet: true,

    // 机器人是否可以抢庄当庄（默认否；后台「机器人能否抢庄」开关可改，Redis 持久化）
    botCanGrab: process.env.BOT_CAN_GRAB === '1' || process.env.BOT_CAN_GRAB === 'true',

    // 被邀请来的玩家（有上级 tuid）每参与一局奖励多少金币（0=关闭；后台可调，Redis 持久化）
    inviteRoundReward: parseInt(process.env.INVITE_ROUND_REWARD) || 0,

    // 默认房间配置
    defaultRoom: {
      name: '鱼虾蟹',
      minBet: 10,
      maxBet: 10000,
      minEnter: 100,
      seats: 10,
      botCount: 3,
      commissionRate: 0.05  // 5%抽水
    },

    // 杀率配置
    killRate: 0.60,           // 60%全局杀率
    maxLossPerRound: 50000,   // 单局最大亏损保护

    // 代理佣金
    agentCommission: 0.03,    // 3%

    // 每局固定扣费
    roundFee: 0,               // 每局每人扣除金币，0=不扣费
    playerMaxBet: 0            // 闲家单场最大下注，0=不限制
  },

  // 动物编号映射
  animals: {
    0: '葫芦', // hu
    1: '虎',   // hu
    2: '鸡',   // ji
    3: '蟹',   // xie
    4: '鱼',   // yu
    5: '虾'    // xia
  }
};
