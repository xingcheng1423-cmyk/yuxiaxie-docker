﻿const express = require('express');
const router = express.Router();
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const config = require('../config');
const User = require('../models/User');
const Transaction = require('../models/Transaction');
const GameRecord = require('../models/GameRecord');
const ScoreLog = require('../models/ScoreLog');
const db = require('../db/mysql');
const { addAdminPages } = require('./admin_pages');
const redis = require('../db/redis');
const { apiSuccess, apiError, hashPassword } = require('../utils/helpers');
const logger = require('../utils/logger');

// 头像上传配置
const uploadDir = path.join(__dirname, '..', 'public', 'uploads', 'avatars');
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, uploadDir),
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname) || '.png';
    cb(null, 'bot_' + Date.now() + ext);
  }
});
const upload = multer({
  storage,
  limits: { fileSize: 2 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    if (/^image\/(jpeg|png|gif|webp)$/.test(file.mimetype)) cb(null, true);
    else cb(new Error('只支持 jpg/png/gif/webp 格式'));
  }
});

/**
 * 后台管理员认证中间件
 */
async function adminAuth(req, res, next) {
  const token = req.headers['x-admin-token'] || req.query.admin_token;
  if (!token) return res.json(apiError('未授权'));
  const stored = await redis.getClient().get('admin:token');
  if (!stored || token !== stored) {
    return res.json(apiError('未授权'));
  }
  next();
}

/**
 * 后台登录
 */

// GET /admin/login - 登录页面
router.get('/admin/login', (req, res) => {
  res.send(`<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>鱼虾蟹管理后台</title>
<meta name="viewport" content="width=device-width,initial-scale=1">
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{background:#1a1a2e;font-family:Arial,sans-serif;display:flex;justify-content:center;align-items:center;min-height:100vh}
.card{background:#16213e;border-radius:12px;padding:40px;width:380px;box-shadow:0 8px 32px rgba(0,0,0,.3)}
h2{color:#e94560;text-align:center;margin-bottom:30px;font-size:24px}
input{width:100%;padding:12px 16px;margin-bottom:16px;border:1px solid #0f3460;border-radius:8px;background:#1a1a2e;color:#fff;font-size:15px;outline:none}
input:focus{border-color:#e94560}
button{width:100%;padding:14px;background:#e94560;color:#fff;border:none;border-radius:8px;font-size:16px;cursor:pointer;font-weight:bold}
button:hover{background:#c73651}
.msg{color:#e94560;text-align:center;margin-top:12px;display:none;font-size:14px}
</style></head><body>
<div class="card">
<h2>鱼虾蟹 管理后台</h2>
<input id="u" placeholder="用户名" value="admin">
<input id="p" type="password" placeholder="密码">
<button onclick="doLogin()">登 录</button>
<div class="msg" id="msg"></div>
</div>
<script>
function doLogin(){
  var u=document.getElementById('u').value,p=document.getElementById('p').value;
  fetch('/admin/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({username:u,password:p})})
  .then(function(r){return r.json()}).then(function(d){
    if(d.code===1){localStorage.setItem('admin_token',d.data.token);location.href='/admin/page?admin_token='+d.data.token}
    else{var m=document.getElementById('msg');m.textContent=d.msg||'登录失败';m.style.display='block'}
  })
}
document.getElementById('p').addEventListener('keydown',function(e){if(e.key==='Enter')doLogin()})
</script></body></html>`);
});

// GET /admin/page - 管理面板页面
router.get('/admin/page', async (req, res) => {
  let token = req.query.admin_token || '';
  // 验证token有效性，无效则清空让页面显示登录表单
  if (token) {
    const r = redis.getClient();
    const stored = await r.get('admin:token').catch(() => null);
    if (stored !== token) token = '';
  }
  res.send(`<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>管理后台</title>
<meta name="viewport" content="width=device-width,initial-scale=1">
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{background:#1a1a2e;color:#fff;font-family:Arial,sans-serif;padding:20px}
h1{color:#e94560;margin-bottom:20px}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:16px;margin-bottom:24px}
.card{background:#16213e;border-radius:10px;padding:20px}
.card h3{color:#e94560;margin-bottom:12px}
.stat{font-size:28px;font-weight:bold;color:#4ecca3}
table{width:100%;border-collapse:collapse;margin-top:8px}
th,td{padding:8px 12px;text-align:left;border-bottom:1px solid #0f3460;font-size:14px}
th{color:#e94560}
input,select{padding:8px 12px;border:1px solid #0f3460;border-radius:6px;background:#1a1a2e;color:#fff;margin-right:8px}
button{padding:8px 16px;background:#e94560;color:#fff;border:none;border-radius:6px;cursor:pointer}
button:hover{background:#c73651}
.row{display:flex;gap:8px;align-items:center;margin-bottom:12px;flex-wrap:wrap}
.ok{color:#4ecca3}.err{color:#e94560}
.tabs{display:flex;gap:8px;margin-bottom:20px;flex-wrap:wrap}
.tab{padding:10px 20px;background:#16213e;border:1px solid #0f3460;border-radius:8px;cursor:pointer;color:#fff}
.tab.active{background:#e94560;border-color:#e94560}
.pnl{display:none}.pnl.active{display:block}
.login-box{max-width:360px;margin:80px auto;background:#16213e;padding:30px;border-radius:12px}
.login-box h2{color:#e94560;margin-bottom:20px;text-align:center}
.login-box input{width:100%;margin-bottom:12px;padding:12px}
.login-box button{width:100%;padding:12px;font-size:16px}
</style></head><body>

<div id="loginBox" class="login-box" style="display:none">
<h2>管理员登录</h2>
<input id="lu" placeholder="用户名" value=""><input id="lp" placeholder="密码" type="password" value="">
<button onclick="doLogin()">登 录</button>
<div id="le" class="err" style="margin-top:10px;text-align:center"></div>
</div>

<div id="mainPanel" style="display:none">
<h1>鱼虾蟹 管理后台</h1>
<div class="tabs">
<div class="tab active" onclick="st('dash')">概览</div>
<div class="tab" onclick="st('users')">用户管理</div>
<div class="tab" onclick="st('score')">上下分</div>
<div class="tab" onclick="st('kill')">杀率控制</div>
<div class="tab" onclick="st('bots')">机器人控制</div>
</div>

<div id="dash" class="pnl active"><div class="grid">
<div class="card"><h3>在线人数</h3><div class="stat" id="d1">-</div></div>
<div class="card"><h3>总用户数</h3><div class="stat" id="d2">-</div></div>
<div class="card"><h3>今日流水</h3><div class="stat" id="d3">-</div></div>
<div class="card"><h3>平台盈利</h3><div class="stat" id="d4">-</div></div>
</div></div>

<div id="users" class="pnl">
<div class="card"><h3>在线玩家 <button onclick="loadOnline()" style="padding:4px 12px;font-size:12px">刷新</button></h3>
<table><thead><tr><th>ID</th><th>UID</th><th>名称</th><th>余额</th><th>座位</th><th>IP</th><th>操作</th></tr></thead><tbody id="ol"></tbody></table>
<div id="olm" style="margin-top:8px"></div></div>
<div class="card" style="margin-top:16px"><h3>封禁列表 <button onclick="loadBanList()" style="padding:4px 12px;font-size:12px">刷新</button></h3>
<table><thead><tr><th>ID</th><th>UID</th><th>名称</th><th>余额</th><th>操作</th></tr></thead><tbody id="bl"></tbody></table></div>
<div class="card" style="margin-top:16px"><h3>全部用户</h3>
<table><thead><tr><th>ID</th><th>UID</th><th>名称</th><th>余额</th><th>上下分</th></tr></thead><tbody id="ul"></tbody></table>
</div></div>

<div id="score" class="pnl">
<div class="card"><h3>上分（充值）</h3><div class="row">
<input id="su" placeholder="用户ID或昵称"><input id="sa" placeholder="金额" type="number">
<button onclick="scoreUp()">上分</button><span id="sm"></span></div></div>
<div class="card" style="margin-top:16px"><h3>下分（提现）</h3><div class="row">
<input id="du" placeholder="用户ID或昵称"><input id="da" placeholder="金额" type="number">
<button onclick="scoreDn()">下分</button><span id="dm"></span></div></div>
<div class="card" style="margin-top:16px"><h3>上下分记录 <button onclick="loadScoreLogs()" style="padding:4px 12px;font-size:12px">刷新</button></h3>
<table><thead><tr><th>ID</th><th>用户ID</th><th>类型</th><th>金额</th><th>变动前</th><th>变动后</th><th>备注</th><th>时间</th></tr></thead><tbody id="sll"></tbody></table>
<div id="slp" style="margin-top:8px;display:flex;gap:8px;align-items:center"></div></div>
</div>

<div id="kill" class="pnl"><div class="card"><h3>游戏阶段时间（秒）</h3><div class="row">
<div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap">
<label>准备<input id="pt" type="number" min="3" style="width:60px;margin-left:4px"></label>
<label>抢庄<input id="gt" type="number" min="3" style="width:60px;margin-left:4px"></label>
<label>下注<input id="bt" type="number" min="5" style="width:60px;margin-left:4px"></label>
<button onclick="setPhaseTime()">设置</button><span id="ptm"></span>
</div></div>
<div style="color:#888;font-size:12px;margin-top:4px">准备/抢庄最少3秒，下注最少5秒，下局生效</div></div>
<div class="card" style="margin-top:16px"><h3>座位数量</h3><div class="row">
<input id="seatNum" placeholder="10" type="number" min="2" max="20" step="1">
<button onclick="setSeats()">设置</button><span id="seatMsg"></span></div>
<div style="color:#888;font-size:12px;margin-top:4px">范围2~20，修改后立即生效，默认10</div></div>
<div class="card" style="margin-top:16px"><h3>无人入座自动循环</h3><div class="row">
<button id="alBtn" onclick="toggleAutoLoop()" style="min-width:120px">加载中...</button><span id="alm"></span></div>
<div style="color:#888;font-size:12px;margin-top:4px">开启后，即使没有真人玩家入座，机器人也会自动循环游戏</div></div>
<div class="card" style="margin-top:16px"><h3>机器人下注范围</h3><div class="row">
<input id="bmb" placeholder="最低" type="number" min="1" style="width:100px">
<span style="margin:0 4px">~</span>
<input id="bmbx" placeholder="最高" type="number" min="1" style="width:100px">
<button onclick="setBotBetRange()">设置</button><span id="bmbm"></span></div>
<div style="color:#888;font-size:12px;margin-top:4px">机器人下注金额范围，可自定义任意数值，从筹码列表中筛选</div></div>
<div class="card" style="margin-top:16px"><h3>抢庄门槛（最低余额）</h3><div class="row">
<input id="gm" placeholder="30000" type="number" min="0" step="1000">
<button onclick="setGrabMin()">设置</button><span id="gmm"></span></div>
<div style="color:#888;font-size:12px;margin-top:4px">余额低于此金额的玩家无法抢庄，默认30000</div></div>
<div class="card" style="margin-top:16px"><h3>每局扣费</h3><div class="row">
<input id="rf" placeholder="0" type="number" min="0" step="1">
<button onclick="setRoundFee()">设置</button><span id="rfm"></span></div>
<div style="color:#888;font-size:12px;margin-top:4px">每局结算时从每位入座玩家扣除的固定金币，0=不扣费，默认0</div></div>
<div class="card" style="margin-top:16px"><h3>闲家单场最大下注</h3><div class="row">
<input id="pmb" placeholder="0" type="number" min="0" step="1">
<button onclick="setPlayerMaxBet()">设置</button><span id="pmbm"></span></div>
<div style="color:#888;font-size:12px;margin-top:4px">闲家单场累计下注不能超过此金额，0=不限制（仍受庄家余额限制），默认0</div></div>
<div class="card" style="margin-top:16px"><h3>全局杀率 (0~1)</h3><div class="row">
<input id="kr" placeholder="0.6" type="number" step="0.1" min="0" max="1">
<button onclick="setKR()">设置</button><span id="km"></span></div></div>
<div class="card" style="margin-top:16px"><h3>点杀/放水</h3><div class="row">
<input id="ku" placeholder="用户ID或昵称">
<button onclick="killU()">点杀</button><button onclick="winU()" style="background:#4ecca3">放水</button>
<span id="kum"></span></div></div>
</div>

<div id="bots" class="pnl"><div class="card"><h3>添加机器人</h3>
<div class="row"><input id="bn" placeholder="机器人昵称"><input id="bb" placeholder="显示余额" type="number" value="10000">
<button onclick="addBot()" style="background:#4ecca3">添加</button><span id="abm"></span></div></div>
<div class="card" style="margin-top:16px"><h3>机器人列表</h3>
<div class="row"><button onclick="loadBots()">刷新</button>
<button onclick="botAll('win')" style="background:#4ecca3">全部设赢</button>
<button onclick="botAll('lose')">全部设输</button>
<button onclick="botAll('auto')" style="background:#0f3460">全部自动</button>
<span id="bm"></span></div>
<table><thead><tr><th>ID</th><th>头像</th><th>名称</th><th>余额</th><th>当前控制</th><th>操作</th></tr></thead><tbody id="btl"></tbody></table>
</div></div>
</div>

<script>
var T='${token}';
if(!T){document.getElementById('loginBox').style.display='block'}
else{document.getElementById('mainPanel').style.display='block';loadD()}

function doLogin(){
  var u=document.getElementById('lu').value,p=document.getElementById('lp').value;
  fetch('/admin/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({username:u,password:p})})
  .then(function(r){return r.json()}).then(function(d){
    if(d.code===1){T=d.data.token;location.href='/admin/page?admin_token='+T}
    else{document.getElementById('le').textContent=d.msg||'登录失败'}
  })
}
function F(u,o){return fetch(u+(u.includes('?')?'&':'?')+'admin_token='+T,Object.assign({headers:{'Content-Type':'application/json','x-admin-token':T}},o)).then(function(r){return r.json()}).then(function(d){if(d.msg==='未授权'){location.href='/admin/login'}return d})}
function st(id){var tabs=['dash','users','score','kill','bots'];tabs.forEach(function(t){document.getElementById(t).className=t===id?'pnl active':'pnl'});document.querySelectorAll('.tab').forEach(function(el,i){el.className=tabs[i]===id?'tab active':'tab'});if(id==='users'){loadOnline();loadBanList();loadU()}if(id==='dash')loadD();if(id==='score')loadScoreLogs();if(id==='bots')loadBots();if(id==='kill'){loadPhaseTime();loadSeats();loadAutoLoop();loadBotBetRange();loadGrabMin();loadRoundFee();loadPlayerMaxBet()}}
function loadD(){F('/admin/dashboard').then(function(d){if(d.code===1){var s=d.data;document.getElementById('d1').textContent=s.onlineCount||0;document.getElementById('d2').textContent=s.totalUsers||0;document.getElementById('d3').textContent=s.todayRounds||0;document.getElementById('d4').textContent=s.todayProfit||0}})}
function loadOnline(){F('/admin/online-players').then(function(d){if(d.code===1){var h='';(d.data||[]).forEach(function(p){var seatTxt=p.seat!==null?'#'+p.seat:'未入座';h+='<tr><td>'+p.id+'</td><td>'+(p.uid||'-')+'</td><td>'+(p.name||'-')+'</td><td>'+p.balance+'</td><td>'+seatTxt+'</td><td>'+(p.ip||'-')+'</td><td>';if(p.seat!==null)h+='<button onclick="kickSeat('+p.id+')" style="background:#f0a500;padding:4px 10px">踢出座位</button> ';h+='<button onclick="banUser('+p.id+',true)" style="background:#e94560;padding:4px 10px">封禁</button>';h+='</td></tr>'});document.getElementById('ol').innerHTML=h||'<tr><td colspan="7" style="text-align:center">暂无在线玩家</td></tr>'}})}
function loadBanList(){F('/admin/ban-list').then(function(d){if(d.code===1){var h='';(d.data||[]).forEach(function(p){h+='<tr><td>'+p.id+'</td><td>'+(p.uid||'-')+'</td><td>'+(p.name||'-')+'</td><td>'+p.balance+'</td><td>';h+='<button onclick="banUser('+p.id+',false)" style="background:#4ecca3;padding:4px 10px">解封</button>';h+='</td></tr>'});document.getElementById('bl').innerHTML=h||'<tr><td colspan="5" style="text-align:center">无封禁用户</td></tr>'}})}
function kickSeat(id){if(!confirm('确定踢出该玩家座位？'))return;F('/admin/kick-seat',{method:'POST',body:JSON.stringify({user_id:id})}).then(function(d){var m=document.getElementById('olm');m.textContent=d.msg;m.className=d.code===1?'ok':'err';loadOnline()})}
function banUser(id,ban){var act=ban?'ban':'unban';var msg=ban?'确定封禁该用户？封禁后将被踢出游戏':'确定解封该用户？';if(!confirm(msg))return;F('/admin/ban',{method:'POST',body:JSON.stringify({user_id:id,action:act})}).then(function(d){var m=document.getElementById('olm');m.textContent=d.msg;m.className=d.code===1?'ok':'err';loadOnline();loadBanList()})}
function loadU(){F('/admin/users').then(function(d){if(d.code===1){var list=d.data.list||d.data;var h='';list.forEach(function(u){h+='<tr><td>'+u.id+'</td><td>'+(u.uid||'-')+'</td><td>'+(u.name||u.nickname||'-')+'</td><td id="ub_'+u.id+'">'+u.huobi+'</td><td style="white-space:nowrap"><input id="ua_'+u.id+'" type="number" placeholder="金额" style="width:70px;padding:4px 6px;font-size:12px"> <button onclick="inlineScore('+u.id+',1)" style="background:#4ecca3;padding:3px 8px;font-size:12px">+</button> <button onclick="inlineScore('+u.id+',-1)" style="padding:3px 8px;font-size:12px">-</button><span id="um_'+u.id+'" style="margin-left:4px;font-size:11px"></span></td></tr>'});document.getElementById('ul').innerHTML=h}})}
function scoreUp(){var uid=document.getElementById('su').value.trim(),amt=document.getElementById('sa').value;if(!uid||!amt)return;F('/admin/score/up',{method:'POST',body:JSON.stringify({user_id:uid,amount:parseFloat(amt)})}).then(function(d){var m=document.getElementById('sm');m.textContent=d.code===1?'成功! 余额:'+d.data.afterBalance:d.msg;m.className=d.code===1?'ok':'err'})}
function scoreDn(){var uid=document.getElementById('du').value.trim(),amt=document.getElementById('da').value;if(!uid||!amt)return;F('/admin/score/down',{method:'POST',body:JSON.stringify({user_id:uid,amount:parseFloat(amt)})}).then(function(d){var m=document.getElementById('dm');m.textContent=d.code===1?'成功! 余额:'+d.data.afterBalance:d.msg;m.className=d.code===1?'ok':'err'})}
function inlineScore(id,dir){var inp=document.getElementById('ua_'+id);var amt=parseFloat(inp.value);if(!amt||amt<=0){var m=document.getElementById('um_'+id);m.textContent='请输入金额';m.className='err';return}var url=dir>0?'/admin/score/up':'/admin/score/down';F(url,{method:'POST',body:JSON.stringify({user_id:String(id),amount:amt})}).then(function(d){var m=document.getElementById('um_'+id);if(d.code===1){document.getElementById('ub_'+id).textContent=d.data.afterBalance;inp.value='';m.textContent=(dir>0?'+':'-')+amt;m.className='ok'}else{m.textContent=d.msg;m.className='err'}setTimeout(function(){m.textContent=''},3000)})}
var _slPage=1;
function loadScoreLogs(pg){_slPage=pg||1;F('/admin/score/logs?page='+_slPage+'&limit=20').then(function(d){if(d.code===1){var list=d.data.list||[];var h='';list.forEach(function(r){var tp=r.type===1?'<span class="ok">上分</span>':'<span class="err">下分</span>';var t=r.created_at?r.created_at.replace('T',' ').substring(0,19):'';h+='<tr><td>'+r.id+'</td><td>'+r.user_id+'</td><td>'+tp+'</td><td>'+r.amount+'</td><td>'+r.before_balance+'</td><td>'+r.after_balance+'</td><td>'+(r.remark||'-')+'</td><td style="font-size:12px">'+t+'</td></tr>'});document.getElementById('sll').innerHTML=h||'<tr><td colspan="8" style="text-align:center">暂无记录</td></tr>';var total=d.data.total||0;var pages=Math.ceil(total/20);var ph='';if(pages>1){for(var i=1;i<=pages&&i<=10;i++){ph+=i===_slPage?'<span style="color:#e94560;font-weight:bold;padding:4px 8px">'+i+'</span>':'<button onclick="loadScoreLogs('+i+')" style="padding:4px 8px;font-size:12px">'+i+'</button>'}if(pages>10)ph+='<span style="color:#888">...共'+pages+'页</span>'}document.getElementById('slp').innerHTML=ph}})}
function setPhaseTime(){var p=document.getElementById('pt').value,g=document.getElementById('gt').value,b=document.getElementById('bt').value;if(!p||!g||!b)return;F('/admin/phase-time',{method:'POST',body:JSON.stringify({prepareTime:parseInt(p),grabTime:parseInt(g),betTime:parseInt(b)})}).then(function(d){var m=document.getElementById('ptm');m.textContent=d.code===1?d.msg:'失败: '+d.msg;m.className=d.code===1?'ok':'err'})}
function loadPhaseTime(){F('/admin/phase-time').then(function(d){if(d.code===1){document.getElementById('pt').value=d.data.prepareTime||10;document.getElementById('gt').value=d.data.grabTime||10;document.getElementById('bt').value=d.data.betTime||15}})}
function setSeats(){var v=document.getElementById('seatNum').value;if(!v||isNaN(v)||v<2||v>20)return;F('/admin/seats',{method:'POST',body:JSON.stringify({seats:parseInt(v)})}).then(function(d){var m=document.getElementById('seatMsg');m.textContent=d.code===1?d.msg:'失败: '+d.msg;m.className=d.code===1?'ok':'err'})}
function loadSeats(){F('/admin/seats').then(function(d){if(d.code===1){document.getElementById('seatNum').value=d.data.seats||10}})}
var _autoLoop=true;
function loadAutoLoop(){F('/admin/auto-loop').then(function(d){if(d.code===1){_autoLoop=d.data.autoLoopNoBet;var btn=document.getElementById('alBtn');btn.textContent=_autoLoop?'已开启（点击关闭）':'已关闭（点击开启）';btn.style.background=_autoLoop?'#4ecca3':'#e94560'}})}
function toggleAutoLoop(){_autoLoop=!_autoLoop;F('/admin/auto-loop',{method:'POST',body:JSON.stringify({autoLoopNoBet:_autoLoop})}).then(function(d){var m=document.getElementById('alm');m.textContent=d.code===1?d.msg:'失败';m.className=d.code===1?'ok':'err';loadAutoLoop()})}
function setBotBetRange(){var mn=document.getElementById('bmb').value,mx=document.getElementById('bmbx').value;if(!mn||!mx||isNaN(mn)||isNaN(mx))return;F('/admin/bot-bet-range',{method:'POST',body:JSON.stringify({botMinBet:parseInt(mn),botMaxBet:parseInt(mx)})}).then(function(d){var m=document.getElementById('bmbm');m.textContent=d.code===1?d.msg:'失败: '+d.msg;m.className=d.code===1?'ok':'err'})}
function loadBotBetRange(){F('/admin/bot-bet-range').then(function(d){if(d.code===1){document.getElementById('bmb').value=d.data.botMinBet||10;document.getElementById('bmbx').value=d.data.botMaxBet||1000}})}
function setGrabMin(){var v=document.getElementById('gm').value;if(!v||isNaN(v))return;F('/admin/grab-min',{method:'POST',body:JSON.stringify({grabMinBalance:parseInt(v)})}).then(function(d){var m=document.getElementById('gmm');m.textContent=d.code===1?d.msg:'设置失败: '+d.msg;m.className=d.code===1?'ok':'err'})}
function loadGrabMin(){F('/admin/grab-min').then(function(d){if(d.code===1){document.getElementById('gm').value=d.data.grabMinBalance||30000}})}
function setRoundFee(){var v=document.getElementById('rf').value;if(v===''||isNaN(v)||v<0)return;F('/admin/round-fee',{method:'POST',body:JSON.stringify({roundFee:parseInt(v)})}).then(function(d){var m=document.getElementById('rfm');m.textContent=d.code===1?d.msg:'\u5931\u8d25: '+d.msg;m.className=d.code===1?'ok':'err'})}
function loadRoundFee(){F('/admin/round-fee').then(function(d){if(d.code===1){document.getElementById('rf').value=d.data.roundFee||0}})}
function setPlayerMaxBet(){var v=document.getElementById('pmb').value;if(v===''||isNaN(v)||v<0)return;F('/admin/player-max-bet',{method:'POST',body:JSON.stringify({playerMaxBet:parseInt(v)})}).then(function(d){var m=document.getElementById('pmbm');m.textContent=d.code===1?d.msg:'\u5931\u8d25: '+d.msg;m.className=d.code===1?'ok':'err'})}
function loadPlayerMaxBet(){F('/admin/player-max-bet').then(function(d){if(d.code===1){document.getElementById('pmb').value=d.data.playerMaxBet||0}})}
function setKR(){var r=document.getElementById('kr').value;F('/admin/killrate/global',{method:'POST',body:JSON.stringify({kill_rate:parseFloat(r)})}).then(function(d){var m=document.getElementById('km');m.textContent=d.code===1?'设置成功':d.msg;m.className=d.code===1?'ok':'err'})}
function killU(){var uid=document.getElementById('ku').value.trim();if(!uid)return;F('/admin/killrate/kill',{method:'POST',body:JSON.stringify({user_id:uid})}).then(function(d){var m=document.getElementById('kum');m.textContent=d.msg;m.className=d.code===1?'ok':'err'})}
function winU(){var uid=document.getElementById('ku').value.trim();if(!uid)return;F('/admin/killrate/win',{method:'POST',body:JSON.stringify({user_id:uid})}).then(function(d){var m=document.getElementById('kum');m.textContent=d.msg;m.className=d.code===1?'ok':'err'})}
function loadBots(){F('/admin/bots').then(function(d){if(d.code===1){var h='';d.data.forEach(function(b){var cls=b.control==='win'?'ok':b.control==='lose'?'err':'';var lbl={win:'赢',lose:'输',auto:'自动'};var av=b.avatar?'<img src="'+b.avatar+'" style="width:32px;height:32px;border-radius:50%">':'<span style="font-size:24px">&#x1F916;</span>';h+='<tr><td>'+b.botId+'</td><td>'+av+'</td><td>'+b.name+'</td><td>'+(b.balance||0)+'</td><td class="'+cls+'">'+(lbl[b.control]||b.control)+'</td><td>';h+='<button onclick="editBot('+b.dbId+')" style="background:#f0a500;padding:4px 10px">编辑</button> ';h+='<button onclick="botCtrl('+b.botId+',&apos;win&apos;)" style="background:#4ecca3;padding:4px 10px">赢</button> ';h+='<button onclick="botCtrl('+b.botId+',&apos;lose&apos;)" style="padding:4px 10px">输</button> ';h+='<button onclick="botCtrl('+b.botId+',&apos;auto&apos;)" style="background:#0f3460;padding:4px 10px">自动</button> ';h+='<button onclick="delBot('+b.dbId+')" style="background:#e74c3c;padding:4px 10px;margin-left:8px">删除</button>';h+='</td></tr>'});document.getElementById('btl').innerHTML=h;window._botData=d.data}})}
function addBot(){var n=document.getElementById('bn').value.trim(),b=document.getElementById('bb').value;if(!n)return;F('/admin/bot/add',{method:'POST',body:JSON.stringify({name:n,balance:parseInt(b)||10000})}).then(function(d){var m=document.getElementById('abm');m.textContent=d.msg;m.className=d.code===1?'ok':'err';if(d.code===1){document.getElementById('bn').value='';loadBots()}})}
function delBot(dbId){if(!confirm('确定删除该机器人？'))return;F('/admin/bot/delete',{method:'POST',body:JSON.stringify({db_id:dbId})}).then(function(d){document.getElementById('bm').textContent=d.msg;document.getElementById('bm').className=d.code===1?'ok':'err';loadBots()})}
function editBot(dbId){var b=null;if(window._botData)window._botData.forEach(function(x){if(x.dbId===dbId)b=x});if(!b)return;window._editAvatarUrl=b.avatar||'';var m=document.createElement('div');m.id='editModal';m.style.cssText='position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,0.7);z-index:999;display:flex;align-items:center;justify-content:center';var html='<div style="background:#16213e;padding:24px;border-radius:12px;min-width:320px">';html+='<h3 style="color:#e94560;margin-bottom:16px">\\u7f16\\u8f91\\u673a\\u5668\\u4eba</h3>';html+='<div style="margin-bottom:12px"><label style="display:block;margin-bottom:4px">\\u540d\\u79f0</label><input id="editName" style="width:100%;padding:8px;background:#1a1a2e;border:1px solid #0f3460;border-radius:6px;color:#fff"></div>';html+='<div style="margin-bottom:12px"><label style="display:block;margin-bottom:4px">\\u5934\\u50cf</label><div style="display:flex;align-items:center;gap:12px"><div id="editPreview" style="width:64px;height:64px;border-radius:50%;background:#1a1a2e;border:2px dashed #0f3460;display:flex;align-items:center;justify-content:center;overflow:hidden;flex-shrink:0"></div><div><label style="display:inline-block;padding:8px 16px;background:#f0a500;border-radius:6px;cursor:pointer;font-size:14px">\\u9009\\u62e9\\u56fe\\u7247<input type="file" id="editAvatarFile" accept="image/jpeg,image/png,image/gif,image/webp" style="display:none"></label><div style="color:#888;font-size:12px;margin-top:4px">\\u652f\\u6301 jpg/png/gif/webp\\uff0c\\u6700\\u5927 2MB</div></div></div></div>';html+='<div style="margin-bottom:12px"><label style="display:block;margin-bottom:4px">\u663e\u793a\u4f59\u989d</label><input id="editBalance" type="number" style="width:100%;padding:8px;background:#1a1a2e;border:1px solid #0f3460;border-radius:6px;color:#fff"></div>';html+='<span id="editMsg"></span>';html+='<div style="display:flex;gap:8px;margin-top:16px"><button onclick="saveBot('+dbId+')" style="flex:1;background:#4ecca3">\\u4fdd\\u5b58</button><button id="editCancelBtn" style="flex:1;background:#555">\\u53d6\\u6d88</button></div>';html+='</div>';m.innerHTML=html;document.body.appendChild(m);document.getElementById('editName').value=b.name;document.getElementById('editBalance').value=b.balance||10000;document.getElementById('editCancelBtn').onclick=function(){m.remove()};var pv=document.getElementById('editPreview');if(b.avatar){pv.innerHTML='<img src="'+b.avatar+'" style="width:100%;height:100%;object-fit:cover">'}else{pv.innerHTML='<span style="font-size:28px">\\ud83e\\udd16</span>'}document.getElementById('editAvatarFile').onchange=function(){var file=this.files[0];if(!file)return;if(file.size>2*1024*1024){document.getElementById('editMsg').textContent='\\u56fe\\u7247\\u4e0d\\u80fd\\u8d85\\u8fc72MB';document.getElementById('editMsg').className='err';return}var rd=new FileReader();rd.onload=function(e){pv.innerHTML='<img src="'+e.target.result+'" style="width:100%;height:100%;object-fit:cover">'};rd.readAsDataURL(file);var fd=new FormData();fd.append('avatar',file);fetch('/admin/bot/upload-avatar?admin_token='+T,{method:'POST',headers:{'x-admin-token':T},body:fd}).then(function(r){return r.json()}).then(function(d){if(d.code===1){window._editAvatarUrl=d.data.url;document.getElementById('editMsg').textContent='\\u4e0a\\u4f20\\u6210\\u529f';document.getElementById('editMsg').className='ok'}else{document.getElementById('editMsg').textContent=d.msg;document.getElementById('editMsg').className='err'}})}}
function saveBot(dbId){var n=document.getElementById('editName').value.trim();if(!n){document.getElementById('editMsg').textContent='\\u540d\\u79f0\\u4e0d\\u80fd\\u4e3a\\u7a7a';document.getElementById('editMsg').className='err';return}var bal=document.getElementById('editBalance').value;F('/admin/bot/update',{method:'POST',body:JSON.stringify({db_id:dbId,name:n,avatar:window._editAvatarUrl||'',balance:parseInt(bal)||10000})}).then(function(d){if(d.code===1){document.getElementById('editModal').remove();loadBots();document.getElementById('bm').textContent=d.msg;document.getElementById('bm').className='ok'}else{document.getElementById('editMsg').textContent=d.msg;document.getElementById('editMsg').className='err'}})}
function botCtrl(id,mode){F('/admin/bot/control',{method:'POST',body:JSON.stringify({bot_id:id,mode:mode})}).then(function(d){document.getElementById('bm').textContent=d.msg;document.getElementById('bm').className=d.code===1?'ok':'err';loadBots()})}
function botAll(mode){F('/admin/bot/control-all',{method:'POST',body:JSON.stringify({mode:mode})}).then(function(d){document.getElementById('bm').textContent=d.msg;document.getElementById('bm').className=d.code===1?'ok':'err';loadBots()})}
</script></body></html>`);
});

router.post('/admin/login', async (req, res) => {
  const { username, password } = req.body;
  if (username === config.admin.user && password === config.admin.pass) {
    const token = hashPassword(config.admin.user + Date.now());
    await redis.getClient().set('admin:token', token, 'EX', 86400);
    logger.info('管理员登录成功');
    return res.json(apiSuccess({ token }));
  }
  res.json(apiError('用户名或密码错误'));
});

/**
 * 数据面板
 */
router.get('/admin/dashboard', adminAuth, async (req, res) => {
  const today = new Date().toISOString().split('T')[0];

  const totalUsers = await db.queryOne('SELECT COUNT(*) as cnt FROM users');
  const todayUsers = await db.queryOne(
    'SELECT COUNT(*) as cnt FROM users WHERE DATE(created_at) = ?', [today]
  );
  const gameStats = await GameRecord.getPlatformStats(today + ' 00:00:00', today + ' 23:59:59');
  const totalBalance = await db.queryOne('SELECT COALESCE(SUM(huobi), 0) as total FROM users');

  // 在线人数
  const wsServer = req.app.get('wsServer');
  const onlineCount = wsServer ? wsServer.wss.clients.size : 0;

  res.json(apiSuccess({
    totalUsers: totalUsers.cnt,
    todayNewUsers: todayUsers.cnt,
    onlineCount,
    todayRounds: gameStats.totalRounds,
    todayProfit: gameStats.totalProfit,
    totalBalance: parseFloat(totalBalance.total)
  }));
});

/**
 * 用户列表
 */
router.get('/admin/users', adminAuth, async (req, res) => {
  const page = parseInt(req.query.page) || 1;
  const limit = parseInt(req.query.limit) || 20;
  const search = req.query.search || '';
  const data = await User.list(page, limit, search);
  res.json(apiSuccess(data));
});

/**
 * 修改用户
 */
router.post('/admin/user/update', adminAuth, async (req, res) => {
  const { user_id, status, huobi } = req.body;
  if (!user_id) return res.json(apiError('缺少user_id'));

  const updates = [];
  const params = [];

  if (status !== undefined) {
    updates.push('status = ?');
    params.push(status);
  }
  if (huobi !== undefined) {
    updates.push('huobi = ?');
    params.push(huobi);
    await redis.delBalance(user_id);
  }

  if (updates.length === 0) return res.json(apiError('无修改项'));

  params.push(user_id);
  await db.update(`UPDATE users SET ${updates.join(', ')} WHERE id = ?`, params);

  logger.info('管理员修改用户', { user_id, status, huobi });
  res.json(apiSuccess(null, '修改成功'));
});

// 辅助：支持用户名或ID查找用户
async function resolveUserId(val) {
  if (!val) return null;
  if (!isNaN(val)) return parseInt(val);
  const rows = await db.query('SELECT id FROM users WHERE name = ? OR uid = ? LIMIT 1', [val, val]);
  return rows.length > 0 ? rows[0].id : null;
}

/**
 * 上分
 */
router.post('/admin/score/up', adminAuth, async (req, res) => {
  let { user_id, amount, remark } = req.body;
  const uid = await resolveUserId(user_id);
  if (!uid || !amount || amount <= 0) {
    return res.json(apiError(!uid && user_id ? '用户不存在: ' + user_id : '参数错误'));
  }
  user_id = uid;

  const user = await User.findById(user_id);
  if (!user) return res.json(apiError('用户不存在'));

  const beforeBalance = user.huobi;
  const afterBalance = await User.updateBalance(user_id, amount);

  await ScoreLog.add(user_id, 0, 1, amount, beforeBalance, afterBalance, remark || '管理员上分');
  await Transaction.add(user_id, 1, amount, null, '上分');

  // 如果玩家在线，推送余额变更
  const wsServer = req.app.get('wsServer');
  if (wsServer) {
    const room = wsServer.getRoomByClient(user_id);
    if (room) {
      room.sendToUser(user_id, {
        cmd: 219,
        user_id: user_id,
        _diamond: afterBalance,
        _opeddoped: amount
      });
    }
  }

  logger.info('上分', { user_id, amount, before: beforeBalance, after: afterBalance });
  res.json(apiSuccess({ beforeBalance, afterBalance }, '上分成功'));
});

/**
 * 下分
 */
router.post('/admin/score/down', adminAuth, async (req, res) => {
  let { user_id, amount, remark } = req.body;
  const uid = await resolveUserId(user_id);
  if (!uid || !amount || amount <= 0) {
    return res.json(apiError(!uid && user_id ? '用户不存在: ' + user_id : '参数错误'));
  }
  user_id = uid;

  const user = await User.findById(user_id);
  if (!user) return res.json(apiError('用户不存在'));

  if (user.huobi < amount) {
    return res.json(apiError('余额不足，当前余额: ' + user.huobi));
  }

  const beforeBalance = user.huobi;
  const afterBalance = await User.updateBalance(user_id, -amount);

  await ScoreLog.add(user_id, 0, 2, amount, beforeBalance, afterBalance, remark || '管理员下分');
  await Transaction.add(user_id, 2, -amount, null, '下分');

  // 如果玩家在线，推送余额变更
  const wsServer = req.app.get('wsServer');
  if (wsServer) {
    const room = wsServer.getRoomByClient(user_id);
    if (room) {
      room.sendToUser(user_id, {
        cmd: 219,
        user_id: user_id,
        _diamond: afterBalance,
        _opeddoped: -amount
      });
    }
  }

  logger.info('下分', { user_id, amount, before: beforeBalance, after: afterBalance });
  res.json(apiSuccess({ beforeBalance, afterBalance }, '下分成功'));
});

/**
 * 上下分记录
 */
router.get('/admin/score/logs', adminAuth, async (req, res) => {
  const page = parseInt(req.query.page) || 1;
  const limit = parseInt(req.query.limit) || 20;
  const userId = req.query.user_id || null;
  const data = await ScoreLog.list(page, limit, userId);
  res.json(apiSuccess(data));
});

/**
 * 房间管理
 */
router.get('/admin/rooms', adminAuth, async (req, res) => {
  const rooms = await db.query('SELECT * FROM room_config ORDER BY sort_order');
  res.json(apiSuccess(rooms));
});

/**
 * 修改房间配置
 */
router.post('/admin/room/update', adminAuth, async (req, res) => {
  const { id, name, min_bet, max_bet, min_enter, seats, bot_count, commission_rate, status } = req.body;
  if (!id) return res.json(apiError('缺少房间ID'));

  const updates = [];
  const params = [];

  const fields = { name, min_bet, max_bet, min_enter, seats, bot_count, commission_rate, status };
  for (const [key, val] of Object.entries(fields)) {
    if (val !== undefined) {
      updates.push(`${key} = ?`);
      params.push(val);
    }
  }

  if (updates.length === 0) return res.json(apiError('无修改项'));

  params.push(id);
  await db.update(`UPDATE room_config SET ${updates.join(', ')} WHERE id = ?`, params);

  logger.info('修改房间配置', req.body);
  res.json(apiSuccess(null, '修改成功，重启服务后生效'));
});

/**
 * 游戏记录
 */
router.get('/admin/records', adminAuth, async (req, res) => {
  const page = parseInt(req.query.page) || 1;
  const limit = parseInt(req.query.limit) || 20;
  const data = await GameRecord.list(page, limit);
  res.json(apiSuccess(data));
});

/**
 * 交易记录
 */
router.get('/admin/transactions', adminAuth, async (req, res) => {
  const page = parseInt(req.query.page) || 1;
  const limit = parseInt(req.query.limit) || 20;
  const userId = req.query.user_id || null;

  let data;
  if (userId) {
    data = await Transaction.listByUser(userId, page, limit);
  } else {
    const offset = (page - 1) * limit;
    const total = await db.queryOne('SELECT COUNT(*) as cnt FROM transactions');
    const list = await db.query(
      `SELECT * FROM transactions ORDER BY id DESC LIMIT ${Number(limit)} OFFSET ${Number(offset)}`
    );
    data = { total: total.cnt, list, page, limit };
  }
  res.json(apiSuccess(data));
});

/**
 * 杀率配置 - 获取
 */
router.get('/admin/killrate', adminAuth, async (req, res) => {
  const configs = await db.query('SELECT * FROM kill_config ORDER BY id');
  const killList = await redis.getKillList();
  const winList = await redis.getWinList();

  res.json(apiSuccess({
    configs,
    killList,
    winList,
    globalKillRate: config.game.killRate,
    maxLossPerRound: config.game.maxLossPerRound
  }));
});

/**
 * 在线玩家列表
 */
router.get('/admin/online-players', adminAuth, async (req, res) => {
  const wsServer = req.app.get('wsServer');
  if (!wsServer) return res.json(apiSuccess([]));
  const players = wsServer.getOnlinePlayers();
  // 标记封禁状态
  try {
    const bannedSet = await redis.getClient().smembers('game:banned');
    for (const p of players) {
      p.banned = bannedSet.includes(String(p.id));
    }
  } catch(e) {}
  res.json(apiSuccess(players));
});

/**
 * 封禁/解封玩家
 */
router.post('/admin/ban', adminAuth, async (req, res) => {
  const { user_id, action } = req.body;
  if (!user_id) return res.json(apiError('请提供用户ID'));
  
  const uid = String(user_id);
  if (action === 'ban') {
    await redis.getClient().sadd('game:banned', uid);
    // 踢出在线玩家
    const wsServer = req.app.get('wsServer');
    if (wsServer) wsServer.kickPlayer(parseInt(uid));
    logger.info('封禁玩家', { userId: uid });
    res.json(apiSuccess(null, '已封禁用户 ' + uid));
  } else if (action === 'unban') {
    await redis.getClient().srem('game:banned', uid);
    logger.info('解封玩家', { userId: uid });
    res.json(apiSuccess(null, '已解封用户 ' + uid));
  } else {
    res.json(apiError('action须为ban或unban'));
  }
});

/**
 * 踢出座位
 */
router.post('/admin/kick-seat', adminAuth, async (req, res) => {
  const { user_id } = req.body;
  if (!user_id) return res.json(apiError('请提供用户ID'));
  const wsServer = req.app.get('wsServer');
  if (!wsServer) return res.json(apiError('服务未就绪'));
  const ok = wsServer.kickSeat(parseInt(user_id));
  if (ok) {
    res.json(apiSuccess(null, '已踢出座位'));
  } else {
    res.json(apiError('该用户不在座位上'));
  }
});

/**
 * 封禁列表
 */
router.get('/admin/ban-list', adminAuth, async (req, res) => {
  try {
    const bannedIds = await redis.getClient().smembers('game:banned');
    const list = [];
    for (const id of bannedIds) {
      const user = await db.queryOne('SELECT id, uid, nickname, huobi FROM users WHERE id = ?', [id]);
      if (user) list.push({ id: user.id, uid: user.uid, name: user.nickname, balance: user.huobi });
      else list.push({ id: parseInt(id), uid: '-', name: '未知', balance: 0 });
    }
    res.json(apiSuccess(list));
  } catch(e) {
    res.json(apiSuccess([]));
  }
});

/**
 * 游戏阶段时间设置（Redis持久化）
 */
router.get('/admin/phase-time', adminAuth, async (req, res) => {
  try {
    const saved = await redis.getClient().get('game:phaseTime');
    if (saved) {
      const data = JSON.parse(saved);
      if (data.prepareTime) config.game.prepareTime = data.prepareTime;
      if (data.grabTime) config.game.grabTime = data.grabTime;
      if (data.betTime) config.game.betTime = data.betTime;
    }
  } catch(e) {}
  res.json(apiSuccess({
    prepareTime: config.game.prepareTime || 10,
    grabTime: config.game.grabTime || 10,
    betTime: config.game.betTime || 15
  }));
});

router.post('/admin/phase-time', adminAuth, async (req, res) => {
  const { prepareTime, grabTime, betTime } = req.body;
  if (!prepareTime || !grabTime || !betTime || isNaN(prepareTime) || isNaN(grabTime) || isNaN(betTime)) {
    return res.json(apiError('请输入有效秒数'));
  }
  if (prepareTime < 3 || grabTime < 3 || betTime < 5) {
    return res.json(apiError('准备/抢庄最少3秒，下注最少5秒'));
  }
  config.game.prepareTime = parseInt(prepareTime);
  config.game.grabTime = parseInt(grabTime);
  config.game.betTime = parseInt(betTime);

  // Redis持久化
  try {
    await redis.getClient().set('game:phaseTime', JSON.stringify({
      prepareTime: config.game.prepareTime,
      grabTime: config.game.grabTime,
      betTime: config.game.betTime
    }));
  } catch(e) {}

  // 同步到所有房间
  const wsServer = req.app.get('wsServer');
  if (wsServer && wsServer.rooms) {
    for (const room of wsServer.rooms.values()) {
      if (room.gameLogic) {
        room.gameLogic.prepareTime = config.game.prepareTime;
        room.gameLogic.grabTime = config.game.grabTime;
        room.gameLogic.betTime = config.game.betTime;
      }
    }
  }

  logger.info('修改阶段时间', { prepareTime: config.game.prepareTime, grabTime: config.game.grabTime, betTime: config.game.betTime });
  res.json(apiSuccess(null, '设置成功：准备' + config.game.prepareTime + 's / 抢庄' + config.game.grabTime + 's / 下注' + config.game.betTime + 's'));
});

/**
 * 座位数量设置
 */
router.get('/admin/seats', adminAuth, async (req, res) => {
  res.json(apiSuccess({ seats: config.game.defaultRoom.seats || 10 }));
});

router.post('/admin/seats', adminAuth, async (req, res) => {
  const { seats } = req.body;
  if (!seats || isNaN(seats) || seats < 2 || seats > 20) {
    return res.json(apiError('座位数须在2~20之间'));
  }
  const seatCount = parseInt(seats);
  config.game.defaultRoom.seats = seatCount;

  // 同步到房间（下局生效）
  const wsServer = req.app.get('wsServer');
  if (wsServer && wsServer.rooms) {
    for (const room of wsServer.rooms.values()) {
      room.maxSeats = seatCount;
      // 广播新座位数给所有客户端
      if (room.gameLogic) {
        room.gameLogic.broadcast({ type: 'seats_update', maxSeats: seatCount });
      }
    }
  }

  // 更新数据库 room_config
  try {
    await db.query('UPDATE room_config SET seats = ? WHERE id = 1', [seatCount]);
  } catch(e) { /* ignore if table doesn't exist */ }

  logger.info('修改座位数', { seats: seatCount });
  res.json(apiSuccess(null, '设置成功，座位数: ' + seatCount));
});

/**
 * 自动循环游戏开关
 */
router.get('/admin/auto-loop', adminAuth, async (req, res) => {
  res.json(apiSuccess({ autoLoopNoBet: config.game.autoLoopNoBet !== false }));
});

router.post('/admin/auto-loop', adminAuth, async (req, res) => {
  const { autoLoopNoBet } = req.body;
  config.game.autoLoopNoBet = !!autoLoopNoBet;

  const wsServer = req.app.get('wsServer');
  if (wsServer && wsServer.rooms) {
    for (const room of wsServer.rooms.values()) {
      if (room.gameLogic) {
        room.gameLogic.autoLoopNoBet = config.game.autoLoopNoBet;
      }
    }
  }

  logger.info('修改自动循环设置', { autoLoopNoBet: config.game.autoLoopNoBet });
  res.json(apiSuccess(null, config.game.autoLoopNoBet ? '已开启：无人入座也自动循环' : '已关闭：无真人入座时暂停游戏'));
});

/**
 * 机器人下注范围设置（Redis持久化）
 */
router.get('/admin/bot-bet-range', adminAuth, async (req, res) => {
  try {
    const saved = await redis.getClient().get('game:botBetRange');
    if (saved) {
      const data = JSON.parse(saved);
      config.game.botMinBet = data.botMinBet;
      config.game.botMaxBet = data.botMaxBet;
    }
  } catch(e) {}
  res.json(apiSuccess({ botMinBet: config.game.botMinBet || 10, botMaxBet: config.game.botMaxBet || 1000 }));
});

router.post('/admin/bot-bet-range', adminAuth, async (req, res) => {
  const { botMinBet, botMaxBet } = req.body;
  if (botMinBet === undefined || isNaN(botMinBet) || botMinBet < 1) {
    return res.json(apiError('最低下注须>=1'));
  }
  if (botMaxBet === undefined || isNaN(botMaxBet) || botMaxBet < 1) {
    return res.json(apiError('最高下注须>=1'));
  }
  if (parseInt(botMinBet) > parseInt(botMaxBet)) {
    return res.json(apiError('最低不能大于最高'));
  }
  config.game.botMinBet = parseInt(botMinBet);
  config.game.botMaxBet = parseInt(botMaxBet);

  // Redis持久化
  try {
    await redis.getClient().set('game:botBetRange', JSON.stringify({ botMinBet: config.game.botMinBet, botMaxBet: config.game.botMaxBet }));
  } catch(e) {}

  const wsServer = req.app.get('wsServer');
  if (wsServer && wsServer.rooms) {
    for (const room of wsServer.rooms.values()) {
      if (room.gameLogic) {
        room.gameLogic.botMinBet = config.game.botMinBet;
        room.gameLogic.botMaxBet = config.game.botMaxBet;
      }
    }
  }

  logger.info('修改机器人下注范围', { botMinBet: config.game.botMinBet, botMaxBet: config.game.botMaxBet });
  res.json(apiSuccess(null, '设置成功，下注范围: ' + config.game.botMinBet + ' ~ ' + config.game.botMaxBet));
});

/**
 * 抢庄门槛设置
 */
router.get('/admin/grab-min', adminAuth, async (req, res) => {
  res.json(apiSuccess({ grabMinBalance: config.game.grabMinBalance || 30000 }));
});

router.post('/admin/grab-min', adminAuth, async (req, res) => {
  const { grabMinBalance } = req.body;
  if (grabMinBalance === undefined || isNaN(grabMinBalance) || grabMinBalance < 0) {
    return res.json(apiError('请输入有效金额'));
  }
  config.game.grabMinBalance = parseInt(grabMinBalance);

  // 同步到所有房间的 GameLogic
  const wsServer = req.app.get('wsServer');
  if (wsServer && wsServer.rooms) {
    for (const room of wsServer.rooms.values()) {
      if (room.gameLogic) {
        room.gameLogic.grabMinBalance = config.game.grabMinBalance;
      }
    }
  }

  logger.info('修改抢庄门槛', { grabMinBalance: config.game.grabMinBalance });
  res.json(apiSuccess(null, '设置成功，抢庄最低余额: ' + config.game.grabMinBalance));
});

/**
 * 每局扣费设置
 */
router.get('/admin/round-fee', adminAuth, async (req, res) => {
  res.json(apiSuccess({ roundFee: config.game.roundFee || 0 }));
});

router.post('/admin/round-fee', adminAuth, async (req, res) => {
  const { roundFee } = req.body;
  if (roundFee === undefined || isNaN(roundFee) || roundFee < 0) {
    return res.json(apiError('请输入有效金额'));
  }
  config.game.roundFee = parseInt(roundFee);

  const wsServer = req.app.get('wsServer');
  if (wsServer && wsServer.rooms) {
    for (const room of wsServer.rooms.values()) {
      if (room.gameLogic) {
        room.gameLogic.roundFee = config.game.roundFee;
      }
    }
  }

  logger.info('修改每局扣费', { roundFee: config.game.roundFee });
  res.json(apiSuccess(null, '设置成功，每局扣费: ' + config.game.roundFee));
});

/**
 * 闲家单场最大下注
 */
router.get('/admin/player-max-bet', adminAuth, async (req, res) => {
  res.json(apiSuccess({ playerMaxBet: config.game.playerMaxBet || 0 }));
});

router.post('/admin/player-max-bet', adminAuth, async (req, res) => {
  const { playerMaxBet } = req.body;
  if (playerMaxBet === undefined || isNaN(playerMaxBet) || playerMaxBet < 0) {
    return res.json(apiError('请输入有效金额'));
  }
  config.game.playerMaxBet = parseInt(playerMaxBet);

  const wsServer = req.app.get('wsServer');
  if (wsServer && wsServer.rooms) {
    for (const room of wsServer.rooms.values()) {
      if (room.gameLogic) {
        room.gameLogic.playerMaxBet = config.game.playerMaxBet;
      }
    }
  }

  logger.info('修改闲家最大下注', { playerMaxBet: config.game.playerMaxBet });
  res.json(apiSuccess(null, '设置成功，闲家单场最大下注: ' + config.game.playerMaxBet));
});

/**
 * 杀率配置 - 设置全局
 */
router.post('/admin/killrate/global', adminAuth, async (req, res) => {
  const { kill_rate, max_loss } = req.body;

  if (kill_rate !== undefined) {
    config.game.killRate = parseFloat(kill_rate);
  }
  if (max_loss !== undefined) {
    config.game.maxLossPerRound = parseFloat(max_loss);
  }

  logger.info('修改全局杀率', { killRate: config.game.killRate, maxLoss: config.game.maxLossPerRound });
  res.json(apiSuccess(null, '修改成功'));
});

/**
 * 点杀
 */
router.post('/admin/killrate/kill', adminAuth, async (req, res) => {
  let { user_id } = req.body;
  if (!user_id) return res.json(apiError('请输入用户ID或用户名'));
  if (isNaN(user_id)) {
    const rows = await db.query('SELECT id FROM users WHERE name = ? OR uid = ? LIMIT 1', [user_id, user_id]);
    if (rows.length === 0) return res.json(apiError('用户不存在: ' + user_id));
    user_id = rows[0].id;
  }
  await redis.setKillList(user_id);
  logger.info('设置点杀', { user_id });
  res.json(apiSuccess(null, '点杀已设置(ID:' + user_id + ')，下局生效'));
});

/**
 * 放水
 */
router.post('/admin/killrate/win', adminAuth, async (req, res) => {
  let { user_id } = req.body;
  if (!user_id) return res.json(apiError('请输入用户ID或用户名'));
  if (isNaN(user_id)) {
    const rows = await db.query('SELECT id FROM users WHERE name = ? OR uid = ? LIMIT 1', [user_id, user_id]);
    if (rows.length === 0) return res.json(apiError('用户不存在: ' + user_id));
    user_id = rows[0].id;
  }
  await redis.setWinList(user_id);
  logger.info('设置放水', { user_id });
  res.json(apiSuccess(null, '放水已设置(ID:' + user_id + ')，下局生效'));
});

/**
 * 机器人列表
 */
router.get('/admin/bots', adminAuth, async (req, res) => {
  const wsServer = req.app.get('wsServer');
  if (!wsServer || !wsServer.botManager) {
    return res.json(apiError('服务未启动'));
  }
  const bots = wsServer.botManager.getAllBots();
  res.json(apiSuccess(bots));
});

/**
 * 机器人胜负控制
 * body: { bot_id: number, mode: 'win' | 'lose' | 'auto' }
 */
router.post('/admin/bot/control', adminAuth, async (req, res) => {
  const { bot_id, mode } = req.body;
  if (!bot_id) return res.json(apiError('缺少bot_id'));
  if (!['win', 'lose', 'auto'].includes(mode)) {
    return res.json(apiError('mode必须是 win/lose/auto'));
  }

  const wsServer = req.app.get('wsServer');
  if (!wsServer || !wsServer.botManager) {
    return res.json(apiError('服务未启动'));
  }

  await wsServer.botManager.setBotControl(parseInt(bot_id), mode);
  const modeText = { win: '赢', lose: '输', auto: '自动' };
  logger.info('管理员设置机器人控制', { bot_id, mode });
  res.json(apiSuccess(null, `机器人 ${bot_id} 设置为【${modeText[mode]}】`));
});

/**
 * 批量设置所有机器人
 * body: { mode: 'win' | 'lose' | 'auto' }
 */
router.post('/admin/bot/control-all', adminAuth, async (req, res) => {
  const { mode } = req.body;
  if (!['win', 'lose', 'auto'].includes(mode)) {
    return res.json(apiError('mode必须是 win/lose/auto'));
  }

  const wsServer = req.app.get('wsServer');
  if (!wsServer || !wsServer.botManager) {
    return res.json(apiError('服务未启动'));
  }

  const allBots = wsServer.botManager.getAllBots();
  for (const bot of allBots) {
    await wsServer.botManager.setBotControl(bot.botId, mode);
  }

  const modeText = { win: '赢', lose: '输', auto: '自动' };
  logger.info('管理员批量设置机器人控制', { mode, count: allBots.length });
  res.json(apiSuccess(null, `所有机器人(${allBots.length}个)设置为【${modeText[mode]}】`));
});

/**
 * 添加机器人
 */
router.post('/admin/bot/add', adminAuth, async (req, res) => {
  const { name, balance } = req.body;
  if (!name || !name.trim()) return res.json(apiError('请输入机器人昵称'));
  const wsServer = req.app.get('wsServer');
  if (!wsServer || !wsServer.botManager) return res.json(apiError('服务未启动'));
  const room = wsServer.getDefaultRoom();
  if (!room) return res.json(apiError('房间不存在'));
  const result = await wsServer.botManager.addBot(name.trim(), parseInt(balance) || 10000, room);
  if (!result.ok) return res.json(apiError(result.msg));
  room.broadcast({ type: 'seated', seat: result.seat, userId: result.botId, name: name.trim(), balance: parseInt(balance) || 10000, isBot: true });
  logger.info('管理员添加机器人', { name, botId: result.botId });
  res.json(apiSuccess(result, '机器人 ' + name + ' 添加成功'));
});

/**
 * 上传机器人头像
 */
router.post('/admin/bot/upload-avatar', adminAuth, (req, res) => {
  upload.single('avatar')(req, res, (err) => {
    if (err) {
      if (err instanceof multer.MulterError && err.code === 'LIMIT_FILE_SIZE') {
        return res.json(apiError('文件大小不能超过2MB'));
      }
      return res.json(apiError(err.message || '上传失败'));
    }
    if (!req.file) return res.json(apiError('请选择图片'));
    const url = '/uploads/avatars/' + req.file.filename;
    logger.info('上传机器人头像', { filename: req.file.filename });
    res.json(apiSuccess({ url }, '上传成功'));
  });
});

/**
 * 修改机器人（名称/头像）
 */
router.post('/admin/bot/update', adminAuth, async (req, res) => {
  const { db_id, name, avatar, balance } = req.body;
  if (!db_id) return res.json(apiError('缺少db_id'));
  const wsServer = req.app.get('wsServer');
  if (!wsServer || !wsServer.botManager) return res.json(apiError('服务未启动'));
  const result = await wsServer.botManager.updateBot(parseInt(db_id), { name, avatar, balance });
  if (!result.ok) return res.json(apiError(result.msg));
  logger.info('管理员修改机器人', { db_id, name, avatar, balance });
  res.json(apiSuccess(result, '修改成功'));
});

/**
 * 删除机器人
 */
router.post('/admin/bot/delete', adminAuth, async (req, res) => {
  const { db_id } = req.body;
  if (!db_id) return res.json(apiError('缺少db_id'));
  const wsServer = req.app.get('wsServer');
  if (!wsServer || !wsServer.botManager) return res.json(apiError('服务未启动'));
  const room = wsServer.getDefaultRoom();
  if (!room) return res.json(apiError('房间不存在'));
  const botId = 10000 + parseInt(db_id);
  const seat = room.findSeatByUser(botId);
  const result = await wsServer.botManager.removeBot(parseInt(db_id), room);
  if (!result.ok) return res.json(apiError(result.msg));
  if (seat !== null) room.broadcast({ type: 'left_seat', seat, userId: botId });
  logger.info('管理员删除机器人', { db_id });
  res.json(apiSuccess(null, '机器人已删除'));
});

/**
 * 系统配置
 */
router.post('/admin/config', adminAuth, async (req, res) => {
  const { key, value } = req.body;
  if (!key) return res.json(apiError('缺少key'));

  await db.query(
    `INSERT INTO system_config (\`key\`, value) VALUES (?, ?)
     ON DUPLICATE KEY UPDATE value = ?`,
    [key, value, value]
  );
  res.json(apiSuccess(null, '配置已保存'));
});

addAdminPages(router);

module.exports = router;
