/**
 * 后台管理HTML页面路由（已迁移到admin.js内联）
 */
function addAdminPages(router) {
  // 页面路由已在admin.js中直接定义
}

module.exports = { addAdminPages };
