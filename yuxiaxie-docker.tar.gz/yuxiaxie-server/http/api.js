const express = require('express');
const router = express.Router();
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const User = require('../models/User');
const Transaction = require('../models/Transaction');
const { apiSuccess, apiError } = require('../utils/helpers');
const logger = require('../utils/logger');

// 头像上传配置
const uploadDir = path.join(__dirname, '../public/uploads/avatars');
if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir, { recursive: true });

const avatarStorage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, uploadDir),
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname) || '.jpg';
    cb(null, Date.now() + '_' + Math.random().toString(36).slice(2, 8) + ext);
  }
});
const avatarUpload = multer({
  storage: avatarStorage,
  limits: { fileSize: 2 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    if (/^image\/(jpeg|png|gif|webp|svg\+xml)$/.test(file.mimetype)) cb(null, true);
    else cb(new Error('只支持图片格式'));
  }
});

/**
 * 单入口API: POST /index/api/dologin
 * 前端通过 y 参数区分不同操作
 */
router.post('/index/api/dologin', async (req, res) => {
  const y = req.body.y || req.query.y || 'login';

  try {
    switch (y) {
      case 'register':
        return await handleRegister(req, res);
      case 'userlogin':
        return await handleUserLogin(req, res);
      case 'index':
        return await handleIndex(req, res);
      case 'user':
        return await handleUser(req, res);
      case 'bet':
        return await handleBetLog(req, res);
      case 'huobilog':
        return await handleHuobiLog(req, res);
      case 'paihang':
        return await handlePaihang(req, res);
      case 'shangzhuanglist':
        return await handleShangzhuangList(req, res);
      case 'shangzhuang':
        return await handleShangzhuang(req, res);
      case 'xiazhuang':
        return await handleXiazhuang(req, res);
      case 'cancelzhuang':
        return await handleCancelzhuang(req, res);
      case 'daili_count':
        return await handleDailiCount(req, res);
      case 'xintiao':
        return await handleXintiao(req, res);
      case 'duihuan':
        return await handleDuihuan(req, res);
      case 'tx':
        return await handleTx(req, res);
      default:
        return res.json(apiError('未知操作'));
    }
  } catch (err) {
    logger.error('API错误', { y, error: err.message, stack: err.stack });
    return res.json(apiError('服务器错误'));
  }
});

async function handleRegister(req, res) {
  const { username, password, nickname, avatar } = req.body;
  if (!username || !password) return res.json(apiError('请输入账号和密码'));
  if (username.length < 3 || username.length > 20) return res.json(apiError('账号3-20个字符'));
  if (!/^[a-zA-Z0-9_]+$/.test(username)) return res.json(apiError('账号只能包含字母、数字和下划线'));
  if (!nickname || nickname.length < 1 || nickname.length > 12) return res.json(apiError('昵称1-12个字符'));
  if (password.length < 6) return res.json(apiError('密码至少6位'));
  const result = await User.register(username, password, nickname, avatar || '');
  if (!result.ok) return res.json(apiError(result.msg));
  logger.info('用户注册', { uid: username, nickname, avatar: avatar || '' });
  res.json(apiSuccess(result.data));
}

async function handleUserLogin(req, res) {
  const { username, password } = req.body;
  if (!username || !password) return res.json(apiError('请输入用户名和密码'));
  const result = await User.loginByPassword(username, password);
  if (!result.ok) return res.json(apiError(result.msg));
  logger.info('用户登录', { uid: username });
  res.json(apiSuccess(result.data));
}

/**
 * 获取用户信息 + 房间列表（主页数据）
 */
async function handleIndex(req, res) {
  const apptoken = req.body.apptoken || req.query.apptoken;
  if (!apptoken) return res.json(apiError('未登录'));

  const user = await User.findByToken(apptoken);
  if (!user) return res.json(apiError('用户不存在'));

  // 获取房间数据（由WsServer注入）
  const wsServer = req.app.get('wsServer');
  const rooms = wsServer ? wsServer.getRoomsInfo() : [];

  // 设置房间token
  const roomData = rooms.length > 0 ? {
    ...rooms[0],
    t: apptoken
  } : null;

  res.json(apiSuccess({
    ...user,
    d: roomData  // cc.GAME = data.d
  }));
}

/**
 * 查询用户详情
 */
async function handleUser(req, res) {
  const apptoken = req.body.apptoken || req.query.apptoken;
  if (!apptoken) return res.json(apiError('未登录'));

  const user = await User.findByToken(apptoken);
  if (!user) return res.json(apiError('用户不存在'));

  res.json(apiSuccess(user));
}

/**
 * 下注记录
 */
async function handleBetLog(req, res) {
  const apptoken = req.body.apptoken || req.query.apptoken;
  if (!apptoken) return res.json(apiError('未登录'));

  const user = await User.findByToken(apptoken);
  if (!user) return res.json(apiError('用户不存在'));

  const page = parseInt(req.body.page) || 1;
  const data = await Transaction.listByUser(user.id, page, 20);
  res.json(apiSuccess(data));
}

/**
 * 金币变动记录
 */
async function handleHuobiLog(req, res) {
  const apptoken = req.body.apptoken || req.query.apptoken;
  if (!apptoken) return res.json(apiError('未登录'));

  const user = await User.findByToken(apptoken);
  if (!user) return res.json(apiError('用户不存在'));

  const page = parseInt(req.body.page) || 1;
  const data = await Transaction.listByUser(user.id, page, 20);
  res.json(apiSuccess(data));
}

/**
 * 排行榜
 */
async function handlePaihang(req, res) {
  const db = require('../db/mysql');
  const list = await db.query(
    'SELECT name, touxiang, huobi FROM users ORDER BY huobi DESC LIMIT 50'
  );
  res.json(apiSuccess({ data: list }));
}

/**
 * 上庄列表
 */
async function handleShangzhuangList(req, res) {
  res.json(apiSuccess({ data: [] }));
}

/**
 * 申请上庄
 */
async function handleShangzhuang(req, res) {
  res.json(apiSuccess(null, '已申请'));
}

/**
 * 申请下庄
 */
async function handleXiazhuang(req, res) {
  res.json(apiSuccess(null, '已下庄'));
}

/**
 * 取消上庄
 */
async function handleCancelzhuang(req, res) {
  res.json(apiSuccess(null, '已取消'));
}

/**
 * 代理统计
 */
async function handleDailiCount(req, res) {
  const apptoken = req.body.apptoken || req.query.apptoken;
  if (!apptoken) return res.json(apiError('未登录'));

  const user = await User.findByToken(apptoken);
  if (!user) return res.json(apiError('用户不存在'));

  res.json(apiSuccess({
    data: {
      yongjin: user.yongjin,
      pobaiget: user.pobaiget,
      pobaijine: user.pobaijine
    }
  }));
}

/**
 * 心跳
 */
async function handleXintiao(req, res) {
  res.json(apiSuccess(null, 'pong'));
}

/**
 * 兑换/提现
 */
async function handleDuihuan(req, res) {
  res.json(apiSuccess(null, '提现申请已提交'));
}

/**
 * 提现操作
 */
async function handleTx(req, res) {
  res.json(apiSuccess(null, '操作成功'));
}

/**
 * GET /index/API/Info - 前端main.js初始化接口
 * 读取cookie中的apptoken获取用户信息
 */
router.get('/index/API/Info', async (req, res) => {
  try {
    // 从cookie中读取token（index.html设置了code/access_token/xianwan）
    const cookies = {};
    (req.headers.cookie || '').split(';').forEach(c => {
      const [k, v] = c.trim().split('=');
      if (k && v) cookies[k] = decodeURIComponent(v);
    });
    const apptoken = cookies.code || cookies.access_token || cookies.xianwan || req.query.apptoken;

    let userInfo = {
      uid: 'guest',
      money: 0,
      ban: '0',
      fuli: '0,0,0',
      shangji: '0',
      yjmoney: '0,0,0',
      xiaji: '0,0,0',
      yjsore: 0
    };

    if (apptoken) {
      const user = await User.findByToken(apptoken);
      if (user) {
        userInfo = {
          uid: user.uid,
          money: user.huobi || 0,
          ban: '0',
          fuli: '0,0,0',
          shangji: '0',
          yjmoney: '0,0,0',
          xiaji: '0,0,0',
          yjsore: 0
        };
      }
    }

    const config = require('../config');
    res.json({
      code: 'ok',
      UserInfo: userInfo,
      config: {
        sygg: '欢迎来到鱼虾蟹游戏',
        cztype: '微信,支付宝',
        yjbl: (config.agentCommission || [10, 5, 3]).join(',')
      },
      subUserInfo: {}
    });
  } catch (err) {
    logger.error('API/Info错误', { error: err.message });
    res.json({ code: 'error', msg: err.message });
  }
});

/**
 * GET /index/api/kai - 开奖记录
 */
router.get('/index/api/kai', async (req, res) => {
  res.json({ code: 1, data: [] });
});

/**
 * GET /API/info/tgimg - 推广图片
 */
router.get('/API/info/tgimg', async (req, res) => {
  res.json({ code: 'ok', img: '' });
});

/**
 * POST /api/upload-avatar - 头像上传
 */
router.post('/api/upload-avatar', (req, res) => {
  avatarUpload.single('avatar')(req, res, (err) => {
    if (err) {
      if (err.code === 'LIMIT_FILE_SIZE') return res.json(apiError('图片不能超过2MB'));
      return res.json(apiError(err.message || '上传失败'));
    }
    if (!req.file) return res.json(apiError('请选择图片'));
    const url = '/uploads/avatars/' + req.file.filename;
    logger.info('头像上传', { filename: req.file.filename });
    res.json(apiSuccess({ url }));
  });
});

module.exports = router;
