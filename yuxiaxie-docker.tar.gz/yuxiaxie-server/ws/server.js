const http = require('http');
const { WebSocketServer } = require('ws');
const url = require('url');
const config = require('../config');
const logger = require('../utils/logger');
const GameRouter = require('./router');
const { Room } = require('../game/Room');
const GameLogic = require('../game/GameLogic');
const BotManager = require('../bot/BotManager');
const db = require('../db/mysql');
const redis = require('../db/redis');
const User = require('../models/User');

class WsServer {
  constructor() {
    // 房间管理 Map<roomId, Room>
    this.rooms = new Map();
    // 用户所在房间 Map<userId, roomId>
    this.userRooms = new Map();
    // 游戏逻辑 Map<roomId, GameLogic>
    this.gameLogics = new Map();
    // 机器人管理
    this.botManager = new BotManager();
    // CMD消息路由
    this.router = new GameRouter(this);
    // 大厅连接 Map<userId, ws>
    this.hallClients = new Map();

    this.server = null;
    this.wss = null;
    this.socketIdCounter = 0;
  }

  /**
   * 启动WS服务器
   */
  async start() {
    // 创建HTTP服务器（同时处理HTTP请求和WS升级）
    this.server = http.createServer((req, res) => {
      this.handleHttpRequest(req, res);
    });

    // 创建WebSocket服务器
    this.wss = new WebSocketServer({ server: this.server });

    this.wss.on('connection', (ws, req) => {
      this.onConnection(ws, req);
    });

    // 初始化房间
    await this.initRooms();

    // 启动监听
    this.server.listen(config.wsPort, () => {
      logger.info(`WebSocket服务器启动 端口:${config.wsPort}`);
    });

    // 心跳检测
    this.startHeartbeat();
  }

  /**
   * 处理非WS的HTTP请求（getaccept认证端点）
   */
  handleHttpRequest(req, res) {
    const parsed = url.parse(req.url, true);

    // Egret认证端点
    if (parsed.pathname === '/getaccept') {
      const { code, xianwan } = parsed.query;
      logger.info('getaccept认证请求', { code, xianwan });

      // 验证token
      res.writeHead(200, {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*'
      });
      res.end(JSON.stringify({ code: 1, msg: 'ok' }));
      return;
    }

    // 其他请求返回404
    res.writeHead(404);
    res.end('Not Found');
  }

  /**
   * 初始化房间（从数据库加载或创建默认房间）
   */
  async initRooms() {
    // 从Redis恢复持久化的游戏设置
    try {
      const savedBetRange = await redis.getClient().get('game:botBetRange');
      if (savedBetRange) {
        const data = JSON.parse(savedBetRange);
        config.game.botMinBet = data.botMinBet;
        config.game.botMaxBet = data.botMaxBet;
        logger.info('从Redis恢复机器人下注范围', data);
      }
      const savedBotCanGrab = await redis.getClient().get('game:botCanGrab');
      if (savedBotCanGrab !== null && savedBotCanGrab !== undefined && savedBotCanGrab !== '') {
        config.game.botCanGrab = (savedBotCanGrab === '1' || savedBotCanGrab === 'true');
        logger.info('从Redis恢复机器人抢庄开关', { botCanGrab: config.game.botCanGrab });
      }
      const savedPhaseTime = await redis.getClient().get('game:phaseTime');
      if (savedPhaseTime) {
        const data = JSON.parse(savedPhaseTime);
        if (data.prepareTime) config.game.prepareTime = data.prepareTime;
        if (data.grabTime) config.game.grabTime = data.grabTime;
        if (data.betTime) config.game.betTime = data.betTime;
        logger.info('从Redis恢复阶段时间', data);
      }
    } catch(e) {}

    try {
      // 只加载第1个房间，所有玩家进同一房间
      const rooms = await db.query('SELECT * FROM room_config WHERE status = 1 ORDER BY id LIMIT 1');

      if (rooms.length === 0) {
        // 没有房间配置，创建默认房间
        logger.info('没有房间配置，创建默认房间');
        const defaultCfg = config.game.defaultRoom;
        const existing = await db.query('SELECT id FROM room_config LIMIT 1');
        let roomId;
        if (existing.length > 0) {
          roomId = existing[0].id;
          await db.update('UPDATE room_config SET status = 1 WHERE id = ?', [roomId]);
        } else {
          roomId = await db.insert(
            `INSERT INTO room_config (name, min_bet, max_bet, min_enter, seats, bot_count, commission_rate, status)
             VALUES (?, ?, ?, ?, ?, ?, ?, 1)`,
            [defaultCfg.name, defaultCfg.minBet, defaultCfg.maxBet, defaultCfg.minEnter,
             defaultCfg.seats, defaultCfg.botCount, defaultCfg.commissionRate]
          );
        }
        const roomCfg = { id: roomId, ...defaultCfg };
        this.createRoom(roomCfg);
      } else {
        this.createRoom(rooms[0]);
      }

      logger.info(`加载1个房间，所有玩家进同一房间`);
    } catch (err) {
      logger.error('初始化房间失败', { error: err.message });
      // 创建内存中的默认房间
      const defaultCfg = { id: 1, ...config.game.defaultRoom };
      this.createRoom(defaultCfg);
    }
  }

  /**
   * 创建房间并绑定游戏逻辑
   */
  createRoom(roomCfg) {
    const room = new Room(roomCfg);
    const gameLogic = new GameLogic(room, this.botManager);
    room.gameLogic = gameLogic;

    this.rooms.set(room.id, room);
    this.gameLogics.set(room.id, gameLogic);

    // 延迟添加机器人，完成后自动启动游戏循环
    setTimeout(async () => {
      await this.botManager.autoJoin(room);
      if (!gameLogic.isRunning && room.getSeatedCount() >= 2) {
        gameLogic.startLoop();
      }
    }, 2000);

    return room;
  }

  /**
   * WebSocket连接建立
   */
  onConnection(ws, req) {
    ws._socketId = ++this.socketIdCounter;
    ws._lastPing = Date.now();
    ws._isAlive = true;

    const clientIp = req.headers['x-real-ip'] || req.socket.remoteAddress;
    ws._clientIp = clientIp;
    logger.info(`新连接 #${ws._socketId}`, { ip: clientIp });

    // 不发送lianjieok，Egret前端会在onSocketOpen时自动发送CMD 180登录

    ws.on('message', (data) => {
      this.onMessage(ws, data);
    });

    ws.on('close', () => {
      this.onClose(ws);
    });

    ws.on('error', (err) => {
      logger.error(`连接错误 #${ws._socketId}`, { error: err.message });
    });

    ws.on('pong', () => {
      ws._isAlive = true;
      ws._lastPing = Date.now();
    });
  }

  /**
   * 收到消息
   */
  async onMessage(ws, data) {
    let msg;
    try {
      const str = data.toString();
      msg = JSON.parse(str);
    } catch (e) {
      logger.warn('消息解析失败', { data: data.toString().substring(0, 200) });
      return;
    }

    ws._lastPing = Date.now();

    // 新协议: type 字段路由
    if (msg.type !== undefined) {
      await this.router.handle(ws, msg);
    } else if (msg.y === 'xintiao') {
      ws.send(JSON.stringify({ y: 'xintiao' }));
    } else {
      logger.warn('未知消息格式', { keys: Object.keys(msg) });
    }
  }

  /**
   * 处理大厅WS消息（y字段路由）
   */
  async handleHallMessage(ws, msg) {
    switch (msg.y) {
      case 'tx': {
        // 进入游戏，用token验证
        const token = msg.u;
        if (!token) break;

        const user = await User.findByToken(token);
        if (!user) {
          logger.warn('tx认证失败', { token: String(token).substring(0, 10) });
          break;
        }

        // 检查封禁
        try {
          const isBanned = await redis.getClient().sismember('game:banned', String(user.id));
          if (isBanned) {
            logger.info('封禁用户尝试登录', { userId: user.id, name: user.name });
            ws.send(JSON.stringify({ type: 'kicked', msg: '您的账号已被封禁，请联系管理员' }));
            ws.close();
            break;
          }
        } catch(e) {}

        ws.userId = user.id;
        ws.userData = user;
        this.hallClients.set(user.id, ws);

        // 自动加入默认房间
        const room = this.getDefaultRoom();
        if (room) {
          room.addClient(user.id, ws);
          ws.roomId = room.id;

          // 发送游戏状态
          const gameLogic = this.gameLogics.get(room.id);
          if (gameLogic) {
            gameLogic.sendRoomInfo(ws);
            // 确保游戏循环已启动
            if (!gameLogic.isRunning) {
              gameLogic.startLoop();
            }
          }
        }

        logger.info(`用户进入游戏: ${user.name}(uid:${user.uid})`);
        break;
      }

      case 'xintiao':
        ws.send(JSON.stringify({ y: 'xintiao' }));
        break;

      case 'bet': {
        if (!ws.userId) break;
        const room = this.getRoomByClient(ws.userId);
        if (!room) break;
        const gameLogic = this.gameLogics.get(room.id);
        if (gameLogic) {
          await gameLogic.handleBet(ws, msg.d);
        }
        break;
      }

      case 'shangzhuanglist': {
        // 老协议庄家列表，新前端不使用
        break;
      }

      case 'shangzhuang': {
        // 老协议上庄，新前端不使用
        break;
      }

      case 'xiazhuang': {
        // 老协议下庄，新前端不使用
        break;
      }

      case 'cancelzhuang': {
        // 老协议下庄，新前端不使用
        break;
      }

      default:
        logger.info('未处理的y消息', { y: msg.y, userId: ws.userId });
    }
  }

  /**
   * 连接关闭
   */
  async onClose(ws) {
    logger.info(`连接关闭 #${ws._socketId}`, { userId: ws.userId });

    if (ws.userId) {
      // 检查是否是当前活跃连接（防止重连时旧连接误删新连接的映射）
      const currentWs = this.hallClients.get(ws.userId);
      if (currentWs === ws) {
        this.hallClients.delete(ws.userId);
        await redis.delOnline(ws.userId);
      }

      // 从房间移除（Room.removeClient已有竞态保护）
      const room = this.getRoomByClient(ws.userId);
      if (room) {
        room.removeClient(ws.userId, ws);
      }
      this.userRooms.delete(ws.userId);
    }
  }

  /**
   * 心跳检测（30秒一次）
   */
  startHeartbeat() {
    setInterval(() => {
      if (!this.wss) return;
      this.wss.clients.forEach(ws => {
        if (!ws._isAlive) {
          logger.info(`心跳超时，断开连接 #${ws._socketId}`);
          return ws.terminate();
        }
        ws._isAlive = false;
        ws.ping();
      });
    }, 30000);
  }

  // ===== RoomManager 接口 =====

  /**
   * 获取默认房间（第一个）
   */
  getDefaultRoom() {
    if (this.rooms.size === 0) return null;
    return this.rooms.values().next().value;
  }

  /**
   * 根据ID获取房间
   */
  getRoom(roomId) {
    return this.rooms.get(roomId) || null;
  }

  /**
   * 获取用户所在的房间
   */
  getRoomByClient(userId) {
    // 遍历所有房间查找用户
    for (const [roomId, room] of this.rooms) {
      if (room.clients.has(userId)) {
        return room;
      }
    }
    return null;
  }

  /**
   * 获取所有房间信息（给HTTP API用）
   */
  /**
   * 获取在线玩家列表（给管理后台用）
   */
  getOnlinePlayers() {
    const players = [];
    for (const [userId, ws] of this.hallClients) {
      if (ws.userData) {
        const roomId = ws.roomId || null;
        const room = roomId ? this.rooms.get(roomId) : null;
        const seatIdx = room ? room.findSeatByUser(userId) : null;
        players.push({
          id: ws.userData.id,
          uid: ws.userData.uid,
          name: ws.userData.name || ws.userData.nickname,
          balance: ws.userData.huobi || ws.userData.balance || 0,
          roomId: roomId,
          seat: seatIdx,
          ip: ws._clientIp || ''
        });
      }
    }
    return players;
  }

  /**
   * 踢出玩家（断开连接）
   */
  kickPlayer(userId) {
    const ws = this.hallClients.get(userId);
    if (ws) {
      try {
        ws.send(JSON.stringify({ type: 'kicked', msg: '您已被管理员踢出' }));
      } catch(e) {}
      ws.close();
      return true;
    }
    return false;
  }

  /**
   * 踢出座位（不断开连接，只离座）
   */
  kickSeat(userId) {
    for (const [roomId, room] of this.rooms) {
      const seatIdx = room.findSeatByUser(userId);
      if (seatIdx !== null) {
        room.leaveSeat(userId);
        // 广播离座消息
        const gameLogic = this.gameLogics.get(roomId);
        if (gameLogic) {
          gameLogic.broadcast({ type: 'left_seat', seat: seatIdx, userId: userId });
        }
        // 通知该玩家
        const ws = this.hallClients.get(userId);
        if (ws) {
          try { ws.send(JSON.stringify({ type: 'kicked_seat', msg: '您已被管理员踢出座位' })); } catch(e) {}
        }
        logger.info('管理员踢出座位', { userId, seat: seatIdx, roomId });
        return true;
      }
    }
    return false;
  }

  getRoomsInfo() {
    const result = [];
    for (const [id, room] of this.rooms) {
      result.push({
        id: room.id,
        name: room.name,
        ip: config.publicHost || '127.0.0.1',
        port: config.wsPort,
        t: '', // token placeholder
        online: room.clients.size,
        seats: room.maxSeats,
        minBet: room.minBet,
        maxBet: room.maxBet
      });
    }
    return result;
  }
}

module.exports = WsServer;
