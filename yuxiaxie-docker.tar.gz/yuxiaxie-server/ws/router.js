const logger = require('../utils/logger');
const User = require('../models/User');
const redis = require('../db/redis');

/**
 * 新前端消息路由 - 使用 type 字段
 */
class GameRouter {
  constructor(roomManager) {
    this.roomManager = roomManager;
  }

  async handle(ws, msg) {
    const type = msg.type;
    try {
      switch (type) {
        case 'login':       return await this.onLogin(ws, msg);
        case 'get_room':    return await this.onGetRoom(ws, msg);
        case 'sit':         return await this.onSit(ws, msg);
        case 'leave_seat':  return await this.onLeaveSeat(ws, msg);
        case 'ready':       return await this.onReady(ws, msg);
        case 'grab':        return await this.onGrab(ws, msg);
        case 'bet':         return await this.onBet(ws, msg);
        case 'chat':        return await this.onChat(ws, msg);
        case 'watch':       return await this.onWatch(ws, msg);
        case 'leave_watch': return await this.onLeaveWatch(ws, msg);
        case 'heartbeat':   return; // 忽略心跳
        default:
          logger.warn('未知消息类型', { type });
      }
    } catch (err) {
      logger.error('消息处理错误', { type, error: err.message, stack: err.stack });
      this.sendTo(ws, { type: 'error', msg: '服务器内部错误' });
    }
  }

  // ===== 登录 =====
  async onLogin(ws, msg) {
    const token = msg.token;
    if (!token) {
      return this.sendTo(ws, { type: 'login_fail', msg: '缺少token' });
    }

    const user = await User.findByToken(token);
    if (!user) {
      return this.sendTo(ws, { type: 'login_fail', msg: '用户不存在' });
    }

    // 检查封禁（Redis错误时拒绝登录，防止被封用户趁Redis故障进入）
    try {
      const isBanned = await redis.getClient().sismember('game:banned', String(user.id));
      if (isBanned) {
        this.sendTo(ws, { type: 'login_fail', msg: '您的账号已被封禁，请联系管理员' });
        ws.close();
        return;
      }
    } catch(e) {
      logger.warn('Redis封禁检查失败，拒绝登录', { userId: user.id, error: e.message });
      this.sendTo(ws, { type: 'login_fail', msg: '服务器繁忙，请稍后重试' });
      return;
    }

    // 关闭同一用户的旧连接，防止重复登录导致WS泄漏
    const oldWs = this.roomManager.hallClients.get(user.id);
    if (oldWs && oldWs !== ws && oldWs.readyState === 1) {
      logger.info(`用户${user.id}重复登录，关闭旧连接 #${oldWs._socketId}`);
      try { oldWs.send(JSON.stringify({ type: 'kicked', msg: '您在其他地方登录' })); } catch(e) {}
      oldWs.userId = null; // 防止旧连接onClose误删新映射
      oldWs.close();
    }

    ws.userId = user.id;
    ws.userData = user;
    ws.apptoken = token;

    // 加入在线列表
    this.roomManager.hallClients.set(user.id, ws);

    // 加入默认房间
    const room = this.roomManager.getDefaultRoom();
    if (room) {
      room.addClient(user.id, ws);
      ws.roomId = room.id;
    }

    await redis.setOnline(user.id, {
      socketId: ws._socketId, roomId: room ? room.id : null, seatId: null
    });

    logger.info(`WS登录: ${user.name}(${user.uid})`, { userId: user.id });

    this.sendTo(ws, {
      type: 'login_ok',
      user: { id: user.id, name: user.name, balance: user.huobi, avatar: user.touxiang || '' }
    });

    // 发送房间信息
    if (room) {
      const gl = this.roomManager.gameLogics.get(room.id);
      if (gl) gl.sendRoomInfo(ws);
    }
  }

  // ===== 获取房间信息 =====
  async onGetRoom(ws) {
    if (!ws.userId) return this.sendTo(ws, { type: 'error', msg: '请先登录' });

    const room = this.roomManager.getRoomByClient(ws.userId);
    if (!room) return this.sendTo(ws, { type: 'error', msg: '未在房间中' });

    const gl = this.roomManager.gameLogics.get(room.id);
    if (gl) gl.sendRoomInfo(ws);
  }

  // ===== 入座 =====
  async onSit(ws, msg) {
    if (!ws.userId) return this.sendTo(ws, { type: 'error', msg: '请先登录' });

    let room = this.roomManager.getRoomByClient(ws.userId);
    if (!room) {
      room = this.roomManager.getDefaultRoom();
      if (room) {
        room.addClient(ws.userId, ws);
        ws.roomId = room.id;
      }
    }
    if (!room) return this.sendTo(ws, { type: 'error', msg: '房间不存在' });

    const seatId = msg.seat !== undefined ? msg.seat : 0;
    const balance = await User.getBalance(ws.userId);

    // 入座时从观看者列表移除
    if (room.watchers.has(ws.userId)) {
      room.watchers.delete(ws.userId);
      ws.isWatching = false;
      room.broadcast(JSON.stringify({ type: 'watcher_count', count: room.watchers.size }));
    }

    const result = room.sitDown(seatId, {
      userId: ws.userId,
      userName: ws.userData.name,
      userImage: ws.userData.touxiang || '',
      diamond: balance
    });

    if (!result.ok) {
      return this.sendTo(ws, { type: 'error', msg: result.msg });
    }

    await redis.setOnline(ws.userId, {
      socketId: ws._socketId, roomId: room.id, seatId
    });

    // 广播入座
    room.broadcast(JSON.stringify({
      type: 'seated',
      seat: seatId,
      userId: ws.userId,
      name: ws.userData.name,
      avatar: ws.userData.touxiang || '',
      balance,
      isBot: false
    }));

    logger.info(`${ws.userData.name} 入座 #${seatId}`);

    // 尝试启动游戏（需要2人以上入座）
    const gl = this.roomManager.gameLogics.get(room.id);
    if (gl) gl.tryStart();
  }

  // ===== 离座 =====
  async onLeaveSeat(ws) {
    if (!ws.userId) return;

    const room = this.roomManager.getRoomByClient(ws.userId);
    if (!room) return;

    const seat = room.findSeatByUser(ws.userId);
    if (seat === null) return;

    room.leaveSeat(seat);

    // 只有真的离座了才广播（游戏中leaveSeat会被拒绝）
    if (!room.seats[seat] || room.seats[seat].userId !== ws.userId) {
      room.broadcast(JSON.stringify({
        type: 'left_seat',
        seat,
        userId: ws.userId
      }));
      logger.info(`${ws.userData.name} 离座 #${seat}`);
    } else {
      this.sendTo(ws, { type: 'error', msg: '游戏中无法离座' });
    }
  }

  // ===== 准备 =====
  async onReady(ws) {
    if (!ws.userId) return this.sendTo(ws, { type: 'error', msg: '请先登录' });

    const room = this.roomManager.getRoomByClient(ws.userId);
    if (!room) return;

    const gl = this.roomManager.gameLogics.get(room.id);
    if (gl) gl.handleReady(ws);
  }

  // ===== 抢庄 =====
  async onGrab(ws, msg) {
    if (!ws.userId) return;

    const room = this.roomManager.getRoomByClient(ws.userId);
    if (!room) return;

    const gl = this.roomManager.gameLogics.get(room.id);
    if (gl) gl.handleGrab(ws, msg.isGrab);
  }

  // ===== 下注 =====
  async onBet(ws, msg) {
    if (!ws.userId) return this.sendTo(ws, { type: 'bet_fail', msg: '请先登录' });

    const room = this.roomManager.getRoomByClient(ws.userId);
    if (!room) return this.sendTo(ws, { type: 'bet_fail', msg: '未在房间中' });

    const gl = this.roomManager.gameLogics.get(room.id);
    if (!gl) return this.sendTo(ws, { type: 'bet_fail', msg: '游戏未启动' });

    await gl.handleBet(ws, msg.animals, msg.amount, msg.mode);
  }

  // ===== 观看 =====
  async onWatch(ws) {
    if (!ws.userId) return this.sendTo(ws, { type: 'error', msg: '请先登录' });

    let room = this.roomManager.getRoomByClient(ws.userId);
    if (!room) {
      room = this.roomManager.getDefaultRoom();
      if (room) {
        room.addClient(ws.userId, ws);
        ws.roomId = room.id;
      }
    }
    if (!room) return this.sendTo(ws, { type: 'error', msg: '房间不存在' });

    // 如果已在座位上，不能切换为观看
    const seat = room.findSeatByUser(ws.userId);
    if (seat !== null) return this.sendTo(ws, { type: 'error', msg: '请先离座' });

    // 如果已经在观看列表中，只回复ok，不重复发送房间信息
    const alreadyWatching = room.watchers.has(ws.userId);

    // 加入观看者
    room.watchers.set(ws.userId, ws);
    ws.isWatching = true;

    this.sendTo(ws, { type: 'watch_ok' });

    // 广播观看人数
    room.broadcast(JSON.stringify({
      type: 'watcher_count',
      count: room.watchers.size
    }));

    // 仅首次进入观看室时发送房间信息，避免重复刷新导致座位闪烁
    if (!alreadyWatching) {
      const gl = this.roomManager.gameLogics.get(room.id);
      if (gl) gl.sendRoomInfo(ws);
    }

    logger.info(`${ws.userData.name} 进入观看室`);
  }

  async onLeaveWatch(ws) {
    if (!ws.userId) return;

    const room = this.roomManager.getRoomByClient(ws.userId);
    if (!room) return;

    room.watchers.delete(ws.userId);
    ws.isWatching = false;

    this.sendTo(ws, { type: 'leave_watch_ok' });

    // 广播观看人数
    room.broadcast(JSON.stringify({
      type: 'watcher_count',
      count: room.watchers.size
    }));
  }

  // ===== 聊天 =====
  async onChat(ws, msg) {
    if (!ws.userId) return;

    const room = this.roomManager.getRoomByClient(ws.userId);
    if (!room) return;

    room.broadcast(JSON.stringify({
      type: 'chat',
      userId: ws.userId,
      name: ws.userData.name,
      text: (msg.text || '').substring(0, 50)
    }));
  }

  sendTo(ws, msg) {
    if (ws && ws.readyState === 1) {
      try { ws.send(JSON.stringify(msg)); } catch (e) {}
    }
  }
}

module.exports = GameRouter;
