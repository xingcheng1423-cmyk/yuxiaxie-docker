# 鱼虾蟹 H5 游戏 · Docker 一键部署

一台干净的 Linux 服务器（1核2G 起），一条命令装好 MySQL + Redis + 游戏服务，无需手动装 Node、建库、配 PM2。

---

## 一、一键部署（推荐）

登录服务器（root），执行：

```bash
curl -fsSL <发布地址>/install.sh | bash
```

脚本自动完成：
1. 没装 Docker 就自动装（含 compose 插件）
2. 下载安装包解压到 `/opt/yuxiaxie`
3. 生成 `.env`：随机数据库密码、随机 TOKEN_SECRET、随机后台密码
4. `docker compose up -d --build` 拉起三个容器
5. 健康检查通过后打印访问地址和后台密码

装完直接用，重跑同一条命令即可覆盖升级（数据库数据在 docker volume 里，不会丢）。

### 自定义

```bash
# 换安装目录
curl -fsSL <地址>/install.sh | bash -s /data/yuxiaxie

# 指定别的安装包地址
PKG_URL=http://x/yuxiaxie-docker.tar.gz bash install.sh
```

### 离线部署

把 `yuxiaxie-docker.tar.gz` 和 `install.sh` 放同一个目录：

```bash
bash install.sh
```

---

## 二、手动部署（用源码）

```bash
mkdir -p /opt/yuxiaxie && cd /opt/yuxiaxie
tar -xzf yuxiaxie-docker.tar.gz --strip-components=1
cp .env.docker.example .env
vi .env          # 改 PUBLIC_HOST 为公网IP、改各种密码
docker compose up -d --build
```

### 用预构建镜像（不编译，最快）

```bash
docker pull <registry>/yuxiaxie-server:latest
# 或本地导入离线镜像
docker load -i yuxiaxie-image.tar.gz
```

---

## 三、配置说明（.env）

| 变量 | 说明 |
|---|---|
| `HTTP_PORT` | 宿主机 HTTP 端口，默认 3000（玩家网页 + 后台） |
| `WS_PORT_HOST` | 宿主机 WebSocket 端口，默认 18282，**前端 game.js 硬编码，一般别改** |
| `PUBLIC_HOST` | 公网 IP 或域名，房间列表会下发这个地址给客户端 |
| `DB_ROOT_PASS` / `DB_PASS` | MySQL root / 业务账号密码，首次启动后写死在 volume 里，改了要清 volume 才生效 |
| `DB_NAME` / `DB_USER` | 数据库名/账号，默认 baye（`sql/init.sql` 里写死了 baye，一般别改） |
| `REDIS_PASS` | 留空=无密码（Redis 不映射到宿主机，只在容器内网可达） |
| `TOKEN_SECRET` | 登录令牌签名密钥，务必随机 |
| `ADMIN_USER` / `ADMIN_PASS` | 后台管理员，后台地址 `/admin/login` |
| `IMAGE_NAME` | 构建出的镜像名，推 registry 时用 |

---

## 四、开服必做

1. **安全组/防火墙放行** `HTTP_PORT`（3000）和 `WS_PORT_HOST`（18282）TCP。
   - 宝塔面板：安全 → 放行端口
   - 阿里云/腾讯云：控制台安全组加规则
2. 改掉 `.env` 里的默认 `ADMIN_PASS`（一键脚本已自动生成随机密码）。
3. 域名访问：Nginx 反代 3000 即可；**WebSocket 18282 需要单独放行或反代**（当前前端连 `ws://域名:18282/ws`，要单端口走 HTTPS 得改 `public/game.js` 的 ws 地址构造逻辑）。

---

## 五、常用运维

```bash
cd /opt/yuxiaxie             # 安装目录

docker compose ps            # 查看状态
docker compose logs -f app   # 看游戏服日志
docker compose restart app   # 重启游戏服
docker compose down          # 停止（保留数据）
docker compose down -v       # 停止并清空数据库（危险）

docker exec -it yxx-mysql mysql -ubaye -p baye   # 进数据库

# 只更新代码（保留数据库）
docker compose up -d --build app

# 备份数据库
docker exec yxx-mysql mysqldump -uroot -p"$DB_ROOT_PASS" baye | gzip > backup_$(date +%F).sql.gz
```

---

## 六、目录/端口对照

| 容器 | 镜像 | 端口 | 数据卷 |
|---|---|---|---|
| yxx-app | yuxiaxie-server:latest（本仓库构建） | 3000 / 18282 | `./logs` |
| yxx-mysql | mysql:8.0 | 仅内网 3306 | `mysql-data` |
| yxx-redis | redis:7-alpine | 仅内网 6379 | `redis-data` |

容器同一 bridge 网络 `yxx`，app 通过服务名 `mysql` / `redis` 访问，宿主机只暴露 3000 和 18282。

---

## 七、常见问题

**构建慢 / apk 卡住**
Dockerfile 默认已用阿里云 apk 源 + npmmirror npm 源。海外机器可覆盖：
```bash
docker compose build --build-arg APK_MIRROR=dl-cdn.alpinelinux.org --build-arg NPM_REGISTRY=https://registry.npmjs.org
```

**外网打不开**
99% 是安全组/防火墙没放行 3000 和 18282。在服务器上先 `curl http://127.0.0.1:3000/health` 确认服务本身是好的。

**改了 DB 密码不生效**
MySQL 只在 volume 首次初始化时读环境变量，需 `docker compose down -v` 清库重来（会丢数据）。

**想换端口**
只改 `HTTP_PORT` 可以；改 `WS_PORT_HOST` 必须同步改 `public/game.js` 里的 `wsPort`，否则客户端连不上。

**`docker compose` 提示 command not found**
老版本只有 `docker-compose`（带横线），脚本已自动兼容；手动部署时换成 `docker-compose up -d --build` 即可。
