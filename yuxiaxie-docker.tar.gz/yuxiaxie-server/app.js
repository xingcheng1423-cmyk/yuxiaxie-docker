/**
 * 鱼虾蟹 H5 游戏后端 - 主入口
 */
const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const path = require('path');
const config = require('./config');
const logger = require('./utils/logger');
const dbMysql = require('./db/mysql');
const dbRedis = require('./db/redis');
const WsServer = require('./ws/server');
const apiRouter = require('./http/api');
const adminRouter = require('./http/admin');



async function main() {
  logger.info('=== 鱼虾蟹游戏服务器启动中 ===');

  

  // 1. 测试数据库连接
  const mysqlOk = await dbMysql.testConnection();
  const redisOk = await dbRedis.testConnection();

  if (!mysqlOk) {
    logger.error('MySQL连接失败，请检查配置');
    process.exit(1);
  }
  if (!redisOk) {
    logger.warn('Redis连接失败，将使用降级模式');
  }

  // 2. 创建Express HTTP服务
  const app = express();
  app.use(cors());
  app.use(bodyParser.json());
  app.use(bodyParser.urlencoded({ extended: true }));

  // 3. 启动WebSocket服务器
  const wsServer = new WsServer();
  await wsServer.start();

  // 注入wsServer到Express，供API使用
  app.set('wsServer', wsServer);

  // 4. 挂载路由
  app.use('/', apiRouter);
  app.use('/', adminRouter);

  // 微信登录回调页面（预留）
  app.get('/login/weixinopen.php', (req, res) => {
    res.json({ code: 1, msg: '微信登录接口预留' });
  });
  app.get('/login/weixingame.php', (req, res) => {
    res.json({ code: 1, msg: '微信游戏登录接口预留' });
  });

  // 静态文件（前端）— HTML不缓存，其他资源缓存7天
  app.use(express.static(path.join(__dirname, 'public'), {
    maxAge: 0,
    etag: false,
    lastModified: false,
    setHeaders: (res, filePath) => {
      if (filePath.endsWith('.html') || filePath.endsWith('.js') || filePath.endsWith('.css')) {
        res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
        res.setHeader('Pragma', 'no-cache');
        res.setHeader('Expires', '0');
      }
    }
  }));

  // 健康检查
  app.get('/health', (req, res) => {
    res.json({
      status: 'ok',
      uptime: process.uptime(),
      rooms: wsServer.rooms.size,
      connections: wsServer.wss ? wsServer.wss.clients.size : 0
    });
  });

  // 5. 启动HTTP服务
  const httpServer = app.listen(config.port, () => {
    logger.info(`HTTP服务器启动 端口:${config.port}`);
    logger.info('=== 服务器启动完成 ===');
    logger.info(`HTTP API: http://127.0.0.1:${config.port}`);
    logger.info(`WebSocket: ws://127.0.0.1:${config.wsPort}`);
    logger.info(`后台管理: http://127.0.0.1:${config.port}/admin/login`);
  });

  

  // 优雅关闭
  function gracefulShutdown(signal) {
    logger.info(`收到 ${signal}，正在关闭服务器...`);

    // 停止所有游戏循环
    for (const [id, gl] of wsServer.gameLogics) {
      gl.stopLoop();
    }

    httpServer.close(() => {
      logger.info('HTTP服务器已关闭');
    });
    if (wsServer.wss) {
      wsServer.wss.close(() => {
        logger.info('WebSocket服务器已关闭');
      });
    }
    if (wsServer.server) {
      wsServer.server.close(() => {
        logger.info('WS HTTP服务器已关闭');
      });
    }

    // 关闭数据库连接池
    dbMysql.close().catch(() => {});
    dbRedis.close().catch(() => {});

    setTimeout(() => {
      logger.info('强制退出');
      process.exit(0);
    }, 3000);
  }
  process.on('SIGINT', () => gracefulShutdown('SIGINT'));
  process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
}

// 未捕获异常处理
process.on('uncaughtException', (err) => {
  logger.error('未捕获异常', { error: err.message, stack: err.stack });
});

process.on('unhandledRejection', (reason) => {
  logger.error('未处理的Promise拒绝', { reason: reason?.message || reason });
});

// 启动
main().catch(err => {
  logger.error('启动失败', { error: err.message, stack: err.stack });
  process.exit(1);
});
