const db = require('../db/mysql');
const redis = require('../db/redis');
const { generateUID, generateToken, hashPassword } = require('../utils/helpers');

class User {
  /**
   * 游客登录（自动注册）
   */
  static async guestLogin() {
    const uid = generateUID();
    const apptoken = generateToken();
    const name = '游客' + uid.slice(-6);
    const touxiang = '';

    const id = await db.insert(
      `INSERT INTO users (uid, name, touxiang, apptoken, huobi, yongjin, jifen, login_type)
       VALUES (?, ?, ?, ?, 0, 0, 0, 0)`,
      [uid, name, touxiang, apptoken]
    );

    await redis.setToken(apptoken, id);

    return {
      id, uid, name, touxiang, apptoken,
      huobi: 0, yongjin: 0, jifen: 0,
      allhuobi: 0, tuid: 0, ticheng: 0,
      pobaiget: 0, pobaijine: 0, paytype: ''
    };
  }

  /**
   * 用户名密码注册
   */
  static async register(username, password, nickname, avatar = '', tuid = 0) {
    // 检查用户名是否已存在
    const existing = await db.queryOne('SELECT id FROM users WHERE uid = ?', [username]);
    if (existing) return { ok: false, msg: '账号已存在' };

    // 检查昵称是否已存在
    const nickExist = await db.queryOne('SELECT id FROM users WHERE name = ?', [nickname]);
    if (nickExist) return { ok: false, msg: '昵称已被使用' };

    const displayName = nickname || username;
    const apptoken = generateToken();
    const passHash = hashPassword(password);
    const touxiang = avatar || '';

    // 邀请人（分享链接 ?tuid=N 带过来）：必须是真实存在且状态正常的用户
    let inviterId = 0;
    const inviteUid = parseInt(tuid) || 0;
    if (inviteUid > 0) {
      const inviter = await db.queryOne('SELECT id FROM users WHERE id = ? AND status = 1', [inviteUid]);
      if (inviter) inviterId = inviter.id;
    }

    const id = await db.insert(
      `INSERT INTO users (uid, name, touxiang, apptoken, password, huobi, yongjin, jifen, login_type, tuid)
       VALUES (?, ?, ?, ?, ?, 0, 0, 0, 1, ?)`,
      [username, displayName, touxiang, apptoken, passHash, inviterId]
    );

    await redis.setToken(apptoken, id);

    return {
      ok: true,
      data: {
        id, uid: username, name: displayName, touxiang, apptoken,
        huobi: 0, yongjin: 0, jifen: 0,
        allhuobi: 0, tuid: inviterId, ticheng: 0,
        pobaiget: 0, pobaijine: 0, paytype: ''
      }
    };
  }

  /**
   * 用户名密码登录
   */
  static async loginByPassword(username, password) {
    const user = await db.queryOne('SELECT * FROM users WHERE uid = ?', [username]);
    if (!user) return { ok: false, msg: '用户不存在' };

    const passHash = hashPassword(password);
    if (user.password !== passHash) return { ok: false, msg: '密码错误' };

    // 更新token
    const apptoken = generateToken();
    await db.update('UPDATE users SET apptoken = ? WHERE id = ?', [apptoken, user.id]);
    await redis.setToken(apptoken, user.id);
    user.apptoken = apptoken;

    return { ok: true, data: User.formatUser(user) };
  }

  /**
   * 微信登录
   */
  static async wechatLogin(openid, name, touxiang) {
    let user = await db.queryOne('SELECT * FROM users WHERE openid = ?', [openid]);

    if (!user) {
      const uid = generateUID();
      const apptoken = generateToken();
      const id = await db.insert(
        `INSERT INTO users (uid, name, touxiang, apptoken, openid, huobi, yongjin, jifen, login_type)
         VALUES (?, ?, ?, ?, ?, 0, 0, 0, 1)`,
        [uid, name, touxiang, apptoken, openid]
      );
      user = await db.queryOne('SELECT * FROM users WHERE id = ?', [id]);
    } else {
      // 更新token
      const apptoken = generateToken();
      await db.update('UPDATE users SET apptoken = ?, name = ?, touxiang = ? WHERE id = ?',
        [apptoken, name, touxiang, user.id]);
      user.apptoken = apptoken;
      user.name = name;
      user.touxiang = touxiang;
    }

    await redis.setToken(user.apptoken, user.id);
    return User.formatUser(user);
  }

  /**
   * 通过apptoken查找用户
   */
  static async findByToken(apptoken) {
    const userId = await redis.getTokenUser(apptoken);
    if (userId) {
      const user = await db.queryOne('SELECT * FROM users WHERE id = ?', [userId]);
      return user ? User.formatUser(user) : null;
    }
    // Redis没有则查库
    const user = await db.queryOne('SELECT * FROM users WHERE apptoken = ?', [apptoken]);
    if (user) {
      await redis.setToken(apptoken, user.id);
      return User.formatUser(user);
    }
    return null;
  }

  /**
   * 通过ID查找用户
   */
  static async findById(id) {
    const user = await db.queryOne('SELECT * FROM users WHERE id = ?', [id]);
    return user ? User.formatUser(user) : null;
  }

  /**
   * 获取用户余额（优先Redis缓存）
   */
  static async getBalance(userId) {
    let balance = await redis.getBalance(userId);
    if (balance !== null) return balance;

    const user = await db.queryOne('SELECT huobi FROM users WHERE id = ?', [userId]);
    if (user) {
      balance = parseFloat(user.huobi);
      await redis.setBalance(userId, balance);
      return balance;
    }
    return 0;
  }

  /**
   * 更新用户余额
   */
  static async updateBalance(userId, amount) {
    await db.update('UPDATE users SET huobi = huobi + ? WHERE id = ?', [amount, userId]);
    // 刷新缓存
    const user = await db.queryOne('SELECT huobi FROM users WHERE id = ?', [userId]);
    if (user) {
      const newBalance = parseFloat(user.huobi);
      await redis.setBalance(userId, newBalance);
      return newBalance;
    }
    return 0;
  }

  /**
   * 设置用户余额（绝对值）
   */
  static async setBalance(userId, amount) {
    await db.update('UPDATE users SET huobi = ? WHERE id = ?', [amount, userId]);
    await redis.setBalance(userId, amount);
    return amount;
  }

  /**
   * 更新佣金
   */
  static async updateYongjin(userId, amount) {
    await db.update('UPDATE users SET yongjin = yongjin + ?, pobaiget = pobaiget + ? WHERE id = ?',
      [amount, amount, userId]);
  }

  /**
   * 用户列表（后台）
   */
  static async list(page = 1, limit = 20, search = '') {
    const offset = (page - 1) * limit;
    let where = 'WHERE 1=1';
    const params = [];

    if (search) {
      where += ' AND (uid LIKE ? OR name LIKE ?)';
      params.push(`%${search}%`, `%${search}%`);
    }

    const total = await db.queryOne(`SELECT COUNT(*) as cnt FROM users ${where}`, params);
    const list = await db.query(
      `SELECT * FROM users ${where} ORDER BY id DESC LIMIT ${Number(limit)} OFFSET ${Number(offset)}`,
      params
    );

    return {
      total: total.cnt,
      list: list.map(u => User.formatUser(u)),
      page,
      limit
    };
  }

  /**
   * 格式化用户对象（匹配前端 cc.User 字段名）
   */
  static formatUser(user) {
    const huobi = parseFloat(user.huobi) || 0;
    const yongjin = parseFloat(user.yongjin) || 0;
    return {
      id: user.id,
      uid: user.uid,
      name: user.name,
      touxiang: user.touxiang || '',
      apptoken: user.apptoken,
      huobi: huobi,
      yongjin: yongjin,
      allhuobi: huobi + yongjin,    // 计算字段
      jifen: parseFloat(user.jifen) || 0,
      tuid: user.tuid || 0,
      ticheng: parseFloat(user.ticheng) || 0,
      pobaiget: parseFloat(user.pobaiget) || 0,
      pobaijine: parseFloat(user.pobaijine) || 0,
      paytype: user.paytype || '',
      status: user.status
    };
  }
}

module.exports = User;
