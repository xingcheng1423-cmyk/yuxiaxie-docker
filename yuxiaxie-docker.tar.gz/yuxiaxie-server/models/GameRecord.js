const db = require('../db/mysql');

class GameRecord {
  /**
   * 保存游戏记录
   */
  static async add(data) {
    return await db.insert(
      `INSERT INTO game_records (room_id, round_no, dice_result, banker_id, bets_detail, settle_detail, platform_profit)
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [
        data.roomId,
        data.roundNo,
        JSON.stringify(data.diceResult),
        data.bankerId,
        JSON.stringify(data.betsDetail),
        JSON.stringify(data.settleDetail),
        data.platformProfit
      ]
    );
  }

  /**
   * 查询记录列表
   */
  static async list(page = 1, limit = 20, roomId = null) {
    const offset = (page - 1) * limit;
    let where = 'WHERE 1=1';
    const params = [];

    if (roomId) {
      where += ' AND room_id = ?';
      params.push(roomId);
    }

    const total = await db.queryOne(`SELECT COUNT(*) as cnt FROM game_records ${where}`, params);
    const list = await db.query(
      `SELECT * FROM game_records ${where} ORDER BY id DESC LIMIT ${Number(limit)} OFFSET ${Number(offset)}`,
      params
    );

    return {
      total: total.cnt,
      list: list.map(r => ({
        ...r,
        dice_result: JSON.parse(r.dice_result || '[]'),
        bets_detail: JSON.parse(r.bets_detail || '[]'),
        settle_detail: JSON.parse(r.settle_detail || '[]')
      })),
      page,
      limit
    };
  }

  /**
   * 统计平台盈亏
   */
  static async getPlatformStats(startDate = null, endDate = null) {
    let where = 'WHERE 1=1';
    const params = [];

    if (startDate) {
      where += ' AND created_at >= ?';
      params.push(startDate);
    }
    if (endDate) {
      where += ' AND created_at <= ?';
      params.push(endDate);
    }

    const result = await db.queryOne(
      `SELECT COUNT(*) as total_rounds,
              COALESCE(SUM(platform_profit), 0) as total_profit
       FROM game_records ${where}`,
      params
    );

    return {
      totalRounds: result.total_rounds,
      totalProfit: parseFloat(result.total_profit)
    };
  }
}

module.exports = GameRecord;
