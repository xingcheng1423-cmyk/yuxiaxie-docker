const db = require('../db/mysql');

class ScoreLog {
  /**
   * 添加上下分记录
   * type: 1=上分 2=下分
   */
  static async add(userId, adminId, type, amount, beforeBalance, afterBalance, remark = '') {
    return await db.insert(
      `INSERT INTO score_logs (user_id, admin_id, type, amount, before_balance, after_balance, remark)
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [userId, adminId, type, amount, beforeBalance, afterBalance, remark]
    );
  }

  /**
   * 查询上下分记录
   */
  static async list(page = 1, limit = 20, userId = null) {
    const offset = (page - 1) * limit;
    let where = 'WHERE 1=1';
    const params = [];

    if (userId) {
      where += ' AND user_id = ?';
      params.push(userId);
    }

    const total = await db.queryOne(`SELECT COUNT(*) as cnt FROM score_logs ${where}`, params);
    const list = await db.query(
      `SELECT * FROM score_logs ${where} ORDER BY id DESC LIMIT ${Number(limit)} OFFSET ${Number(offset)}`,
      params
    );

    return { total: total.cnt, list, page, limit };
  }
}

module.exports = ScoreLog;
