const db = require('../db/mysql');

class Transaction {
  /**
   * 添加交易记录
   * type: 1=充值/上分 2=提现/下分 3=游戏赢 4=游戏输 5=佣金
   */
  static async add(userId, type, amount, relatedId = null, remark = '') {
    return await db.insert(
      `INSERT INTO transactions (user_id, type, amount, related_id, remark)
       VALUES (?, ?, ?, ?, ?)`,
      [userId, type, amount, relatedId, remark]
    );
  }

  /**
   * 查询用户交易记录
   */
  static async listByUser(userId, page = 1, limit = 20) {
    const offset = (page - 1) * limit;
    const total = await db.queryOne(
      'SELECT COUNT(*) as cnt FROM transactions WHERE user_id = ?', [userId]
    );
    const list = await db.query(
      `SELECT * FROM transactions WHERE user_id = ? ORDER BY id DESC LIMIT ${Number(limit)} OFFSET ${Number(offset)}`,
      [userId]
    );
    return {
      total: total.cnt,
      data: list.map(t => ({
        atime: t.created_at,
        jine: parseFloat(t.amount),
        type: Transaction.typeLabel(t.type),
        remark: t.remark
      })),
      page,
      limit
    };
  }

  /**
   * 类型标签
   */
  static typeLabel(type) {
    const labels = { 1: '充值', 2: '提现', 3: '游戏赢', 4: '游戏输', 5: '佣金' };
    return labels[type] || '其他';
  }
}

module.exports = Transaction;
