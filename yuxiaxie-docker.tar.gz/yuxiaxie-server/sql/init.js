/**
 * 数据库初始化脚本
 * 运行: node sql/init.js
 */
const fs = require('fs');
const path = require('path');
const mysql = require('mysql2/promise');
require('dotenv').config({ path: path.join(__dirname, '../.env') });

async function init() {
  const config = {
    host: process.env.DB_HOST || '127.0.0.1',
    port: parseInt(process.env.DB_PORT) || 3306,
    user: process.env.DB_USER || 'baye',
    password: process.env.DB_PASS || 'baye',
    multipleStatements: true
  };

  console.log('正在连接数据库...', config.host);

  let conn;
  try {
    conn = await mysql.createConnection(config);
    console.log('数据库连接成功');

    const sqlFile = path.join(__dirname, 'init.sql');
    const sql = fs.readFileSync(sqlFile, 'utf8');

    console.log('正在执行初始化SQL...');
    await conn.query(sql);

    console.log('✅ 数据库初始化完成！');
    console.log('  - 数据库: baye');
    console.log('  - 表: users, transactions, game_records, room_config, system_config, kill_config, score_logs');
    console.log('  - 默认房间: 鱼虾蟹 (底注10, 上限10000, 8座位)');
    console.log('  - 默认杀率: 60%');
  } catch (err) {
    console.error('❌ 数据库初始化失败:', err.message);
    process.exit(1);
  } finally {
    if (conn) await conn.end();
  }
}

init();
