-- ============================================================
-- 修复种子数据中文乱码（双重编码）
-- 原因：MySQL 官方镜像首次导入 init.sql 时客户端字符集为 latin1，
--       导致种子里的中文被存成「é±¼è™¾èŸ¹」这种双重编码。
-- 用法（数据库已在跑的老部署，新部署不用执行）：
--   docker exec -i yxx-mysql mysql -uroot -p"$DB_ROOT_PASS" < sql/fix_charset.sql
-- 说明：只处理「以 C2/C3 开头」的乱码串，正常中文（E4~E9 开头）不受影响，可安全重复执行。
-- ============================================================
USE `baye`;
SET NAMES utf8mb4;

UPDATE `bots`
   SET `name` = CONVERT(BINARY(CONVERT(`name` USING latin1)) USING utf8mb4)
 WHERE HEX(`name`) LIKE 'C2%' OR HEX(`name`) LIKE 'C3%';

UPDATE `room_config`
   SET `name` = CONVERT(BINARY(CONVERT(`name` USING latin1)) USING utf8mb4)
 WHERE HEX(`name`) LIKE 'C2%' OR HEX(`name`) LIKE 'C3%';

UPDATE `kill_config`
   SET `remark` = CONVERT(BINARY(CONVERT(`remark` USING latin1)) USING utf8mb4)
 WHERE HEX(`remark`) LIKE 'C2%' OR HEX(`remark`) LIKE 'C3%';

UPDATE `system_config`
   SET `value` = CONVERT(BINARY(CONVERT(`value` USING latin1)) USING utf8mb4)
 WHERE HEX(`value`) LIKE 'C2%' OR HEX(`value`) LIKE 'C3%';

UPDATE `system_config`
   SET `remark` = CONVERT(BINARY(CONVERT(`remark` USING latin1)) USING utf8mb4)
 WHERE HEX(`remark`) LIKE 'C2%' OR HEX(`remark`) LIKE 'C3%';

SELECT '修复后检查：' AS info;
SELECT id, name FROM bots;
SELECT id, name FROM room_config;
SELECT `key`, `value` FROM system_config;
