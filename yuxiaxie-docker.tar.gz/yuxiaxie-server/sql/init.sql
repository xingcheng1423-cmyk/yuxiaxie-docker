-- 鱼虾蟹游戏 数据库初始化脚本
-- 数据库: baye

CREATE DATABASE IF NOT EXISTS `baye` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `baye`;

-- 强制客户端字符集为 utf8mb4（否则 MySQL 官方镜像导入时中文会双重编码变乱码）
SET NAMES utf8mb4;

-- 用户表
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` varchar(32) NOT NULL COMMENT '用户唯一标识',
  `name` varchar(64) NOT NULL COMMENT '昵称',
  `touxiang` varchar(256) DEFAULT '' COMMENT '头像URL',
  `password` varchar(64) DEFAULT '' COMMENT '密码哈希',
  `apptoken` varchar(64) NOT NULL COMMENT '登录令牌',
  `huobi` decimal(12,2) NOT NULL DEFAULT 0.00 COMMENT '金币余额',
  `yongjin` decimal(12,2) NOT NULL DEFAULT 0.00 COMMENT '佣金余额',
  `jifen` decimal(12,2) NOT NULL DEFAULT 0.00 COMMENT '积分',
  `openid` varchar(64) DEFAULT '' COMMENT '微信OpenID',
  `login_type` tinyint(1) DEFAULT 0 COMMENT '0=游客 1=微信',
  `status` tinyint(1) DEFAULT 1 COMMENT '1=正常 0=禁用',
  `tuid` int(11) DEFAULT 0 COMMENT '上级推广ID',
  `ticheng` decimal(4,2) DEFAULT 0.00 COMMENT '提成比例',
  `pobaiget` decimal(12,2) DEFAULT 0.00 COMMENT '累计获得佣金',
  `pobaijine` decimal(12,2) DEFAULT 0.00 COMMENT '佣金金额',
  `paytype` varchar(32) DEFAULT '' COMMENT '支付方式',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_uid` (`uid`),
  UNIQUE KEY `idx_apptoken` (`apptoken`),
  KEY `idx_openid` (`openid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户表';

-- 交易记录表
CREATE TABLE IF NOT EXISTS `transactions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `type` tinyint(2) NOT NULL COMMENT '1=充值/上分 2=提现/下分 3=游戏赢 4=游戏输 5=佣金',
  `amount` decimal(12,2) NOT NULL COMMENT '金额',
  `related_id` int(11) DEFAULT NULL COMMENT '关联ID',
  `remark` varchar(128) DEFAULT '' COMMENT '备注',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_user` (`user_id`),
  KEY `idx_type` (`type`),
  KEY `idx_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='交易记录';

-- 游戏记录表
CREATE TABLE IF NOT EXISTS `game_records` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `room_id` int(11) NOT NULL,
  `round_no` int(11) NOT NULL COMMENT '局号',
  `dice_result` varchar(32) NOT NULL COMMENT '骰子结果JSON',
  `banker_id` int(11) DEFAULT 0 COMMENT '庄家ID(0=系统庄)',
  `bets_detail` text COMMENT '下注详情JSON',
  `settle_detail` text COMMENT '结算详情JSON',
  `platform_profit` decimal(12,2) DEFAULT 0.00 COMMENT '平台盈亏',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_room` (`room_id`),
  KEY `idx_round` (`round_no`),
  KEY `idx_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='游戏记录';

-- 房间配置表
CREATE TABLE IF NOT EXISTS `room_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL COMMENT '房间名称',
  `min_bet` int(11) NOT NULL DEFAULT 10 COMMENT '最低下注',
  `max_bet` int(11) NOT NULL DEFAULT 10000 COMMENT '最高下注',
  `min_enter` int(11) NOT NULL DEFAULT 100 COMMENT '最低入场金币',
  `seats` int(11) NOT NULL DEFAULT 8 COMMENT '座位数',
  `bot_count` int(11) NOT NULL DEFAULT 3 COMMENT '机器人数量',
  `commission_rate` decimal(4,2) DEFAULT 0.05 COMMENT '抽水比例',
  `status` tinyint(1) DEFAULT 1 COMMENT '1=开启 0=关闭',
  `sort_order` int(11) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='房间配置';

-- 系统配置表
CREATE TABLE IF NOT EXISTS `system_config` (
  `key` varchar(64) NOT NULL,
  `value` text NOT NULL,
  `remark` varchar(128) DEFAULT '',
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='系统配置';

-- 杀率配置表
CREATE TABLE IF NOT EXISTS `kill_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` tinyint(1) NOT NULL COMMENT '1=全局 2=个人 3=点杀 4=放水',
  `target_id` int(11) DEFAULT 0 COMMENT '目标用户ID',
  `kill_rate` decimal(4,2) DEFAULT 0.60 COMMENT '杀率',
  `max_loss` decimal(12,2) DEFAULT 50000.00 COMMENT '单局最大亏损',
  `status` tinyint(1) DEFAULT 1 COMMENT '1=启用 0=关闭',
  `remark` varchar(128) DEFAULT '',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_target` (`target_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='杀率配置';

-- 上下分记录表
CREATE TABLE IF NOT EXISTS `score_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL COMMENT '目标用户ID',
  `admin_id` int(11) NOT NULL COMMENT '操作管理员ID',
  `type` tinyint(1) NOT NULL COMMENT '1=上分 2=下分',
  `amount` decimal(12,2) NOT NULL COMMENT '金额',
  `before_balance` decimal(12,2) NOT NULL COMMENT '操作前余额',
  `after_balance` decimal(12,2) NOT NULL COMMENT '操作后余额',
  `remark` varchar(256) DEFAULT '' COMMENT '备注',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_user` (`user_id`),
  KEY `idx_admin` (`admin_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='上下分记录';

-- 机器人表
CREATE TABLE IF NOT EXISTS `bots` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL COMMENT '机器人昵称',
  `avatar` varchar(256) DEFAULT '' COMMENT '头像URL',
  `balance` int(11) NOT NULL DEFAULT 10000 COMMENT '显示余额',
  `control` varchar(10) NOT NULL DEFAULT 'auto' COMMENT 'win/lose/auto',
  `status` tinyint(1) DEFAULT 1 COMMENT '1=启用 0=禁用',
  `sort_order` int(11) DEFAULT 0,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='机器人配置';

-- 插入默认机器人
INSERT INTO `bots` (`name`, `balance`, `control`, `status`, `sort_order`) VALUES
('逢赌必赢', 15000, 'auto', 1, 1),
('锦鲤附体', 22000, 'auto', 1, 2),
('富贵花开', 18000, 'auto', 1, 3),
('财运亨通', 25000, 'auto', 1, 4),
('鸿运当头', 12000, 'auto', 1, 5)
ON DUPLICATE KEY UPDATE `name` = VALUES(`name`);

-- 插入默认房间
INSERT INTO `room_config` (`name`, `min_bet`, `max_bet`, `min_enter`, `seats`, `bot_count`, `commission_rate`, `status`)
VALUES ('鱼虾蟹', 10, 10000, 100, 8, 3, 0.05, 1)
ON DUPLICATE KEY UPDATE `name` = VALUES(`name`);

-- 插入默认杀率配置
INSERT INTO `kill_config` (`type`, `kill_rate`, `max_loss`, `status`, `remark`)
VALUES (1, 0.60, 50000, 1, '全局杀率60%')
ON DUPLICATE KEY UPDATE `kill_rate` = VALUES(`kill_rate`);

-- 插入默认系统配置
INSERT INTO `system_config` (`key`, `value`, `remark`) VALUES
('gonggao', '欢迎来到鱼虾蟹！', '公告内容'),
('agent_commission', '0.03', '代理佣金比例'),
('maintenance', '0', '维护开关 0=正常 1=维护')
ON DUPLICATE KEY UPDATE `value` = VALUES(`value`);
