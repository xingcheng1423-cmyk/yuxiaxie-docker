module.exports = {
  apps: [{
    name: 'yuxiaxie',
    script: 'app.js',
    interpreter: '/www/server/nvm/versions/node/v16.20.2/bin/node',
    instances: 1,
    autorestart: true,
    watch: false,
    max_memory_restart: '512M',
    env: {
      NODE_ENV: 'production'
    }
  }]
};
